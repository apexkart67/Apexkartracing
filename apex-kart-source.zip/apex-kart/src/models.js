import * as THREE from 'three';
import { RoundedBoxGeometry } from 'three/addons/geometries/RoundedBoxGeometry.js';
import { mergeGeometries } from 'three/addons/utils/BufferGeometryUtils.js';

// Every kart owns its geometry and materials. Static shapes are combined by
// material so a detailed model remains inexpensive when the grid is full.
const SPECS = {
  nova: { accent: '#ffeccb', light: '#72f0f2', number: '07' },
  milo: { accent: '#eaf8fb', light: '#fff5b7', number: '23' },
  jax: { accent: '#ffda6b', light: '#ffb1f4', number: '12' },
  rio: { accent: '#f9f0d3', light: '#a7ffda', number: '54' },
  pixel: { accent: '#17393d', light: '#75fff0', number: '08' },
  phantom: { accent: '#58627c', light: '#c5a5ff', number: '00' },
  ember: { accent: '#ffe58c', light: '#ff6a28', number: '88' },
  aurora: { accent: '#e9fcff', light: '#b0abff', number: '41' },
};
const SEGMENTS = { '0':'abcdef','1':'bc','2':'abged','3':'abgcd','4':'fgbc','5':'afgcd','6':'afgecd','7':'abc','8':'abcdefg','9':'abfgcd' };
const WHITE = '#edf6f7';

function builder(parent) {
  const batches = new Map();
  const matrix = new THREE.Matrix4(), quaternion = new THREE.Quaternion(), euler = new THREE.Euler();
  const vector = new THREE.Vector3(), scaleVector = new THREE.Vector3();
  return {
    add(geometry, material, position = [0,0,0], rotation = [0,0,0], scale = [1,1,1]) {
      const own = geometry.index ? geometry.toNonIndexed() : geometry;
      if (own !== geometry) geometry.dispose();
      vector.set(...position); euler.set(...rotation); quaternion.setFromEuler(euler); scaleVector.set(...scale);
      matrix.compose(vector,quaternion,scaleVector); own.applyMatrix4(matrix);
      if (!batches.has(material)) batches.set(material,[]);
      batches.get(material).push(own);
    },
    finish() {
      for (const [material, geometries] of batches) {
        const combined = mergeGeometries(geometries,false);
        geometries.forEach(g=>g.dispose());
        if (!combined) throw new Error('Kart geometry could not be assembled');
        const mesh = new THREE.Mesh(combined,material);
        mesh.castShadow = !material.transparent; mesh.receiveShadow = true;
        parent.add(mesh);
      }
    },
  };
}
const rounded = (w,h,d,r=.1) => new RoundedBoxGeometry(w,h,d,w*d>1?2:1,Math.min(r,w/2,h/2,d/2));
const sphere = (r=.5) => new THREE.SphereGeometry(r,16,10);
const cylinder = (radius,height,segments=16) => new THREE.CylinderGeometry(radius,radius,height,segments,1);
const torus = (radius,tube=.06,segments=18,arc=Math.PI*2) => new THREE.TorusGeometry(radius,tube,6,segments,arc);
const capsule = (radius,length) => new THREE.CapsuleGeometry(radius,length,3,8);

function radialShadow() {
  const size=32, pixels=new Uint8Array(size*size*4);
  for(let y=0;y<size;y++)for(let x=0;x<size;x++){
    const r=Math.hypot((x+0.5-size/2)/(size/2),(y+0.5-size/2)/(size/2));
    const i=(y*size+x)*4;pixels[i]=12;pixels[i+1]=23;pixels[i+2]=34;pixels[i+3]=Math.round(Math.max(0,1-r)*94);
  }
  const tex=new THREE.DataTexture(pixels,size,size,THREE.RGBAFormat);tex.needsUpdate=true;
  const material=new THREE.MeshBasicMaterial({map:tex,transparent:true,depthWrite:false,toneMapped:false});
  const mesh=new THREE.Mesh(new THREE.PlaneGeometry(4.7,6.4),material);mesh.rotation.x=-Math.PI/2;mesh.position.y=.025;
  mesh.userData.ownedTexture=tex;
  return mesh;
}

export function createKart(color = '#ee654c', characterId = 'nova') {
  const spec=SPECS[characterId]||SPECS.nova;
  const group=new THREE.Group();group.name=`kart-${characterId}`;
  const paint=new THREE.MeshStandardMaterial({color,roughness:.33,metalness:.2});
  const paintShade=new THREE.MeshStandardMaterial({color:new THREE.Color(color).multiplyScalar(.65),roughness:.45,metalness:.15});
  const cream=new THREE.MeshStandardMaterial({color:spec.accent,roughness:.4,metalness:.12});
  const graphite=new THREE.MeshStandardMaterial({color:'#1b2938',roughness:.72,metalness:.2});
  const black=new THREE.MeshStandardMaterial({color:'#0d1622',roughness:.95});
  const rubber=new THREE.MeshStandardMaterial({color:'#18212a',roughness:.94});
  const tread=new THREE.MeshStandardMaterial({color:'#29323c',roughness:.96});
  const metal=new THREE.MeshStandardMaterial({color:'#cad9de',roughness:.29,metalness:.76});
  const glow=new THREE.MeshStandardMaterial({color:spec.light,emissive:spec.light,emissiveIntensity:1.1,roughness:.24,metalness:.15});
  const tail=new THREE.MeshStandardMaterial({color:'#ff795c',emissive:'#ff3f22',emissiveIntensity:1.4,roughness:.3});
  const white=new THREE.MeshStandardMaterial({color:WHITE,roughness:.4});
  const glass=new THREE.MeshStandardMaterial({color:'#487285',roughness:.12,metalness:.58,transparent:true,opacity:.52,depthWrite:false});
  const eye=new THREE.MeshBasicMaterial({color:characterId==='pixel'?spec.light:'#e4fbff',toneMapped:false});
  const body=new THREE.Group();body.name='bodywork';group.add(body);
  const b=builder(body);
  // Swept chassis and low side pods give the body a kart silhouette from every angle.
  b.add(rounded(2.26,.28,3.7,.13),graphite,[0,.54,-.03]);
  b.add(rounded(1.62,.4,1.88,.18),paint,[0,.83,.95],[.065,0,0]);
  b.add(rounded(1.77,.33,1.03,.16),paint,[0,.88,1.67],[-.1,0,0]);
  b.add(rounded(1.19,.17,1.7,.07),paintShade,[0,1.065,.98],[-.04,0,0]);
  // Cream racing stripe and a crisp number badge on the front cowl.
  b.add(rounded(.22,.025,1.78,.01),cream,[0,1.16,1.04],[-.025,0,0]);
  b.add(rounded(.73,.036,.64,.09),cream,[0,1.198,1.45],[-.035,0,0]);
  for(let digit=0;digit<2;digit++){
    const x0=-.17+digit*.34,z0=1.45;
    const shapes={a:[0,-.18,.19,.034],b:[.1,-.09,.034,.16],c:[.1,.09,.034,.16],d:[0,.18,.19,.034],e:[-.1,.09,.034,.16],f:[-.1,-.09,.034,.16],g:[0,0,.19,.034]};
    for(const key of SEGMENTS[spec.number[digit]]){
      const [x,z,w,d]=shapes[key];b.add(new THREE.BoxGeometry(w,.013,d),graphite,[x0+x,1.225,z0+z]);
    }
  }
  for(const side of [-1,1]){
    b.add(rounded(.46,.54,2.27,.18),paint,[side*.99,.78,-.25],[0,side*-.035,0]);
    b.add(rounded(.48,.13,1.75,.06),cream,[side*1.015,1.045,-.15]);
    b.add(rounded(.23,.21,.76,.06),black,[side*1.18,.79,.1]);
    // Painted sidepod gills read as real openings, without extra draw calls.
    for(let k=0;k<3;k++)b.add(rounded(.03,.22,.055,.012),metal,[side*1.225,.82,-.18+k*.19],[0,side*.1,-side*.2]);
    b.add(rounded(.63,.15,.2,.06),glow,[side*.55,.91,2.12],[-.11,0,side*.05]);
    b.add(rounded(.37,.12,.11,.04),tail,[side*.68,.93,-1.9]);
    b.add(cylinder(.07,2.73,8),metal,[0,.54,side*1.26],[0,0,Math.PI/2]);
    b.add(rounded(.13,.38,.27,.04),graphite,[side*.88,.75,-1.5]);
    b.add(cylinder(.13,.58,10),metal,[side*.77,.74,-1.86],[Math.PI/2,0,0]);
    b.add(cylinder(.09,.025,10),black,[side*.77,.74,-2.16],[Math.PI/2,0,0]);
  }
  // Front impact bumper, rear diffuser and spoiler create a clean read in chase view.
  b.add(rounded(2.89,.23,.26,.11),graphite,[0,.49,2.13]);
  b.add(rounded(2.59,.045,.13,.02),metal,[0,.575,2.205]);
  b.add(rounded(2.57,.29,.3,.12),graphite,[0,.52,-1.94]);
  for(const side of [-1,1])b.add(rounded(.15,.64,.23,.04),metal,[side*.91,1.05,-1.68]);
  const wingHeight=characterId==='rio'?1.67:1.4;
  b.add(rounded(2.59,.15,.66,.07),paint,[0,wingHeight,-1.76],[.08,0,0]);
  b.add(rounded(2.35,.04,.16,.02),cream,[0,wingHeight+.08,-1.55]);
  for(const side of [-1,1])b.add(rounded(.07,.31,.77,.04),cream,[side*1.26,wingHeight+.05,-1.76]);
  b.add(rounded(1.26,.32,.63,.09),metal,[0,.84,-1.29]);
  for(let k=0;k<5;k++)b.add(rounded(1.16,.035,.04,.01),graphite,[0,1.015,-1.51+k*.11]);
  // Seat rim and cockpit floor around the driver's torso.
  b.add(rounded(1.3,.3,1.2,.13),graphite,[0,.78,-.43]);
  b.add(rounded(1.23,1.12,.33,.15),black,[0,1.27,-.77],[-.13,0,0]);
  b.add(rounded(.91,.82,.13,.06),paintShade,[0,1.4,-.98],[-.13,0,0]);
  for(const side of [-1,1])b.add(rounded(.18,.68,.23,.08),cream,[side*.63,1.26,-.74],[0,0,side*-.13]);
  if(characterId==='jax'||characterId==='ember')for(const side of [-1,1])b.add(new THREE.ConeGeometry(.27,.75,3),cream,[side*1.03,1.15,-1.14],[0,0,-side*.55]);
  if(characterId==='phantom'||characterId==='aurora')for(const side of [-1,1])b.add(rounded(.055,.065,2.1,.025),glow,[side*1.25,.63,-.05]);
  if(characterId==='pixel')for(const side of [-1,1])for(let n=0;n<3;n++)b.add(new THREE.BoxGeometry(.03,.11,.12),glow,[side*1.24,.94,-.55+n*.18]);
  b.finish();

  const wheels=[],frontWheels=[];
  for(const side of [-1,1])for(const front of [false,true]){
    const pivot=new THREE.Group();pivot.name=front?'front-steer':'rear-axle';pivot.position.set(side*1.39,.58,front?1.23:-1.24);group.add(pivot);
    const roll=new THREE.Group();roll.name='wheel-roll';pivot.add(roll);wheels.push(roll);if(front)frontWheels.push(pivot);
    const w=builder(roll);
    w.add(cylinder(.55,.45,20),rubber,[0,0,0],[0,0,Math.PI/2]);
    for(const x of [-.195,.195])w.add(torus(.455,.065,20),rubber,[x,0,0],[0,Math.PI/2,0]);
    w.add(cylinder(.335,.465,12),graphite,[0,0,0],[0,0,Math.PI/2]);
    w.add(cylinder(.265,.48,12),metal,[0,0,0],[0,0,Math.PI/2]);
    w.add(cylinder(.105,.5,8),cream,[0,0,0],[0,0,Math.PI/2]);
    // Chamfered spokes and alternating tread blocks remain legible at racing speed.
    for(let k=0;k<6;k++){
      const a=k*Math.PI/3;
      for(const face of [-1,1])w.add(rounded(.025,.06,.27,.015),paint,[face*.247,Math.sin(a)*.18,Math.cos(a)*.18],[a,0,0]);
    }
    for(let k=0;k<14;k++){
      const a=k*Math.PI/7;
      w.add(new THREE.BoxGeometry(.3,.014,.042),tread,[0,Math.sin(a)*.548,Math.cos(a)*.548],[Math.PI/2-a,0,.13]);
    }
    w.finish();
  }

  const driver=new THREE.Group();driver.name='driver';driver.position.set(0,1.27,-.3);body.add(driver);
  const d=builder(driver);
  d.add(capsule(.36,.38),paint,[0,.15,0],[0,0,0],[1,.9,.85]);
  d.add(rounded(.52,.09,.47,.04),graphite,[0,-.24,.17]);
  d.add(rounded(.49,.055,.025,.02),cream,[0,.26,.31]);
  // Harness straps, gloved hands and bent legs communicate a seated racer.
  for(const side of [-1,1]){
    d.add(rounded(.075,.49,.035,.02),cream,[side*.19,.18,.302],[0,0,-side*.12]);
    d.add(capsule(.12,.45),paint,[side*.32,.16,.31],[.9,0,-side*.3]);
    d.add(sphere(.15),white,[side*.37,-.04,.56],[0,0,0],[1,.8,.85]);
    d.add(capsule(.17,.49),graphite,[side*.24,-.33,.42],[Math.PI/2,0,0]);
    d.add(rounded(.26,.22,.41,.09),paint,[side*.25,-.35,.75]);
  }
  d.add(rounded(.17,.15,.04,.025),metal,[0,.12,.34]);
  d.finish();

  const steeringWheel=new THREE.Group();steeringWheel.name='steering-wheel';steeringWheel.position.set(0,1.32,.5);steeringWheel.rotation.x=.65;body.add(steeringWheel);
  const sw=builder(steeringWheel);
  sw.add(torus(.36,.055,16),graphite);
  sw.add(rounded(.57,.055,.045,.02),metal,[0,0,0]);
  sw.add(rounded(.05,.25,.045,.02),metal,[0,-.1,0]);
  sw.add(cylinder(.09,.065,10),paint,[0,0,.015],[Math.PI/2,0,0]);sw.finish();

  const helmet=new THREE.Group();helmet.name='helmet';helmet.position.set(0,.97,-.02);driver.add(helmet);
  const h=builder(helmet);
  if(characterId==='pixel'){
    h.add(rounded(1.14,1.05,1.02,.22),paint);
    h.add(rounded(1.03,.37,.11,.07),graphite,[0,.045,.527]);
    for(const side of [-1,1]){
      h.add(rounded(.23,.14,.035,.025),eye,[side*.24,.045,.594]);
      h.add(new THREE.BoxGeometry(.11,.055,.03),white,[side*.24,.1,.614]);
    }
    h.add(rounded(.12,.08,.035,.018),glow,[0,-.22,.548]);
    h.add(cylinder(.045,.43,8),metal,[0,.7,-.12]);
    h.add(new THREE.BoxGeometry(.19,.19,.19),glow,[0,.97,-.12],[0,.4,0]);
  } else {
    h.add(sphere(.63),paint,[0,0,0],[0,0,0],[1,1.04,1]);
    h.add(new THREE.SphereGeometry(.642,18,10,0,Math.PI,.31*Math.PI,.4*Math.PI),graphite);
    h.add(new THREE.SphereGeometry(.65,18,8,0,Math.PI,.365*Math.PI,.255*Math.PI),glass);
    h.add(rounded(.22,.07,1.04,.035),cream,[0,.587,-.08],[-.1,0,0]);
    h.add(rounded(.65,.13,.24,.06),paintShade,[0,-.38,.48],[-.2,0,0]);
    for(const side of [-1,1]){
      h.add(sphere(.085),eye,[side*.19,.025,.616],[0,0,0],[.75,1,.32]);
      h.add(cylinder(.13,.07,12),metal,[side*.61,-.02,.05],[0,0,Math.PI/2]);
      h.add(rounded(.11,.038,.025,.012),cream,[side*.22,-.4,.602],[0,0,side*.14]);
    }
    h.add(rounded(.27,.035,.025,.012),black,[0,-.31,.605]);
    h.add(new THREE.SphereGeometry(.66,10,4,.26*Math.PI,.2*Math.PI,.385*Math.PI,.035*Math.PI),white);
  }
  // Recognisable silhouettes for every member of the eight-racer crew.
  if(characterId==='nova'){
    for(const side of [-1,1])h.add(new THREE.ConeGeometry(.17,.5,3),cream,[side*.64,.24,-.12],[0,0,-side*.65]);
    h.add(cylinder(.11,.045,8),glow,[0,.17,-.634],[Math.PI/2,0,0]);
  } else if(characterId==='milo'){
    h.add(torus(.62,.065,18,Math.PI),graphite,[0,.04,-.03]);
    for(const side of [-1,1]){
      h.add(cylinder(.23,.18,12),graphite,[side*.62,.02,0],[0,0,Math.PI/2]);
      h.add(cylinder(.17,.2,12),cream,[side*.65,.02,0],[0,0,Math.PI/2]);
    }
    h.add(capsule(.035,.45),metal,[-.57,-.16,.26],[-.7,0,.55]);
    h.add(sphere(.07),black,[-.43,-.32,.45]);
  } else if(characterId==='jax'){
    for(const side of [-1,1]){
      h.add(new THREE.ConeGeometry(.23,.59,4),paint,[side*.37,.67,-.07],[0,0,-side*.27]);
      h.add(new THREE.ConeGeometry(.11,.33,3),cream,[side*.37,.7,.05],[0,0,-side*.27]);
    }
  } else if(characterId==='rio'){
    for(let k=0;k<3;k++)h.add(new THREE.ConeGeometry(.14,.46-k*.055,4),cream,[0,.72-k*.04,-.26+k*.2],[.32,0,0]);
    h.add(rounded(.35,.08,.21,.025),glow,[0,.09,-.64]);
  } else if(characterId==='phantom'){
    h.add(torus(.64,.055,24),glow,[0,.88,0],[Math.PI/2,0,0]);
    for(const side of [-1,1])h.add(rounded(.045,.3,.05,.02),glow,[side*.48,.01,-.45],[0,0,-side*.45]);
  } else if(characterId==='ember'){
    for(let k=0;k<3;k++){
      const x=(k-1)*.31;
      h.add(new THREE.ConeGeometry(.15,.55+(k===1?.2:0),3),glow,[x,.67,-.13],[0,0,-x*.4]);
      h.add(new THREE.ConeGeometry(.085,.28,3),cream,[x,.76,.015],[0,0,-x*.4]);
    }
  } else if(characterId==='aurora'){
    for(const side of [-1,1]){
      h.add(cylinder(.2,.15,12),cream,[side*.62,.02,-.04],[0,0,Math.PI/2]);
      h.add(cylinder(.13,.175,12),glow,[side*.65,.02,-.04],[0,0,Math.PI/2]);
    }
    h.add(rounded(.6,.08,.07,.03),glow,[0,.19,-.58],[0,0,.1]);
    for(const side of [-1,1])h.add(new THREE.ConeGeometry(.11,.36,4),cream,[side*.32,.66,-.18],[0,0,-side*.2]);
  }
  h.finish();

  const flame=new THREE.Group();flame.name='boost-exhaust';flame.position.set(0,.73,-2.12);flame.visible=false;group.add(flame);
  const fireOuter=new THREE.MeshBasicMaterial({color:spec.light,transparent:true,opacity:.8,depthWrite:false,toneMapped:false});
  const fireCore=new THREE.MeshBasicMaterial({color:'#f5ffff',transparent:true,opacity:.92,depthWrite:false,toneMapped:false});
  for(const side of [-1,1]){
    const outer=new THREE.Mesh(new THREE.ConeGeometry(.22,1.15,7),fireOuter);outer.rotation.x=-Math.PI/2;outer.position.set(side*.77,0,-.45);flame.add(outer);
    const core=new THREE.Mesh(new THREE.ConeGeometry(.12,.8,6),fireCore);core.rotation.x=-Math.PI/2;core.position.set(side*.77,0,-.27);flame.add(core);
  }
  group.add(radialShadow());
  group.userData={wheels,frontWheels,driver,helmet,flame,steeringWheel,body,characterId,number:spec.number,wheelRadius:.55};
  for(const movable of [body,driver,helmet,steeringWheel]){
    movable.userData.basePosition=movable.position.clone();movable.userData.baseRotation=movable.rotation.clone();
  }
  return group;
}
