import * as THREE from 'three';

export const TRACKS = [
  { id: 'coast', name: 'Sunshore Circuit', subtitle: 'Ocean air. Hairpin turns. Full send.', difficulty: 'ROOKIE', length: '1.0 KM', color: '#ff8655' },
  { id: 'canyon', name: 'Redrock Rally', subtitle: 'Ride the edge of the wild west.', difficulty: 'INTERMEDIATE', length: '1.1 KM', color: '#e8a354' },
  { id: 'neon', name: 'Neon Nights', subtitle: 'Own the streets after dark.', difficulty: 'EXPERT', length: '1.3 KM', color: '#b593ff' },
];

const palettes = {
  coast: { sky: 0xb9e6ed, fog: 0xb9e6ed, land: 0x74b65a, edge: 0xe4cc95, road: 0x424c5c, curb: 0xf37764, light: 0xfff0c7 },
  canyon: { sky: 0xf3d7b2, fog: 0xf3d7b2, land: 0xd9a564, edge: 0xb76b45, road: 0x4b4244, curb: 0xffcb73, light: 0xffdfb3 },
  neon: { sky: 0x12162e, fog: 0x19213c, land: 0x29374a, edge: 0x16253a, road: 0x243246, curb: 0x71eced, light: 0xd2d1ff },
};

const wrap = t => ((t % 1) + 1) % 1;
const Y = new THREE.Vector3(0, 1, 0);
const geometries = {
  box: new THREE.BoxGeometry(1, 1, 1),
  cylinder: new THREE.CylinderGeometry(1, 1, 1, 8),
  cone: new THREE.ConeGeometry(1, 1, 7),
  sphere: new THREE.SphereGeometry(1, 12, 8),
  ico: new THREE.IcosahedronGeometry(1, 0),
};

function labelTexture(text, bg = '#152d3c', fg = '#ffffff', small = '') {
  if (typeof document === 'undefined') return null;
  const c = document.createElement('canvas'); c.width = 1024; c.height = 256;
  const ctx = c.getContext('2d');
  ctx.fillStyle = bg; ctx.fillRect(0, 0, 1024, 256);
  ctx.fillStyle = fg; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
  ctx.font = '900 italic 112px Arial'; ctx.fillText(text, 512, small ? 100 : 132);
  if (small) { ctx.font = 'bold 35px Arial'; ctx.fillText(small, 512, 194); }
  const tex = new THREE.CanvasTexture(c); tex.colorSpace = THREE.SRGBColorSpace;
  return tex;
}

export function createWorld(scene, trackId = 'coast') {
  const id = palettes[trackId] ? trackId : 'coast';
  const palette = palettes[id];
  const root = new THREE.Group(); root.name = `track-${id}`; scene.add(root);
  scene.background = new THREE.Color(palette.sky);
  scene.fog = new THREE.Fog(palette.fog, 290, 1100);
  const halfWidth = 9;
  const shapes = {
    coast: [[0,1.3,150],[-97,2,137],[-162,3,50],[-130,5,-57],[-35,6,-98],[57,3,-146],[144,1.5,-91],[166,1.4,23],[94,1.2,128]],
    canyon: [[0,1.5,160],[-105,2,149],[-176,4,63],[-165,7,-44],[-82,8,-81],[-44,6,-159],[61,4,-171],[153,2,-108],[171,1.5,-17],[98,1.5,52],[130,1.5,130]],
    neon: [[0,1.5,165],[-128,1.5,155],[-180,1.5,57],[-130,1.5,0],[-164,1.5,-117],[-55,1.5,-168],[69,1.5,-142],[164,1.5,-167],[192,1.5,-45],[115,1.5,13],[167,1.5,123],[70,1.5,160]],
  };
  const curve = new THREE.CatmullRomCurve3(shapes[id].map(p => new THREE.Vector3(...p)), true, 'catmullrom', 0.38);
  curve.arcLengthDivisions = 1800;
  const length = curve.getLength();
  const getPoint = t => curve.getPointAt(wrap(t));
  const getTangent = t => curve.getTangentAt(wrap(t));
  const batches = new Map();
  const matrix = new THREE.Matrix4(); const quaternion = new THREE.Quaternion(); const euler = new THREE.Euler();
  function add(kind, color, p, scale = [1,1,1], rot = [0,0,0], emissive = false) {
    const key = `${kind}-${color}-${emissive}`;
    if (!batches.has(key)) batches.set(key, { kind, color, emissive, matrices: [] });
    euler.set(...rot); quaternion.setFromEuler(euler);
    matrix.compose(new THREE.Vector3(...p), quaternion, new THREE.Vector3(...scale));
    batches.get(key).matrices.push(matrix.clone());
  }
  function flush() {
    for (const batch of batches.values()) {
      const mat = new THREE.MeshStandardMaterial({ color: batch.color, roughness: 0.84,
        ...(batch.emissive ? { emissive: batch.color, emissiveIntensity: 1.3 } : {}) });
      const mesh = new THREE.InstancedMesh(geometries[batch.kind], mat, batch.matrices.length);
      batch.matrices.forEach((m, i) => mesh.setMatrixAt(i, m));
      mesh.castShadow = true; mesh.receiveShadow = true; root.add(mesh);
    }
  }
  function mesh(geometry, material, pos) {
    const m = new THREE.Mesh(geometry, material); if (pos) m.position.set(...pos);
    m.receiveShadow = true; root.add(m); return m;
  }
  function roadStrip(left, right, height, color, segments = 560, material) {
    const vertices = [], indices = [], uvs = [];
    for (let i = 0; i <= segments; i++) {
      const t = i / segments; const p = getPoint(t), tangent = getTangent(t);
      const normal = new THREE.Vector3(-tangent.z, 0, tangent.x).normalize();
      for (const side of [left, right]) {
        const v = p.clone().addScaledVector(normal, side);
        v.y += typeof height === 'function' ? height(side, p) : height;
        vertices.push(v.x, v.y, v.z); uvs.push(side === left ? 0 : 1, t * 80);
      }
      if (i < segments) { const j = i * 2; indices.push(j,j+2,j+1,j+1,j+2,j+3); }
    }
    const geo = new THREE.BufferGeometry(); geo.setAttribute('position', new THREE.Float32BufferAttribute(vertices,3));
    geo.setAttribute('uv', new THREE.Float32BufferAttribute(uvs,2)); geo.setIndex(indices); geo.computeVertexNormals();
    return mesh(geo, material || new THREE.MeshStandardMaterial({ color, roughness: .94, side: THREE.DoubleSide }));
  }
  function at(t, offset = 0, lift = 0) {
    const p = getPoint(t); const d = getTangent(t); p.addScaledVector(new THREE.Vector3(-d.z,0,d.x).normalize(), offset); p.y += lift;
    return { p, yaw: Math.atan2(d.x,d.z), d };
  }
  // The island and its soft, shallow shelf make the circuit feel like a place.
  if (id === 'coast') {
    mesh(new THREE.PlaneGeometry(3000,3000), new THREE.MeshStandardMaterial({color:0x58bbc7,roughness:.35,metalness:.12}), [0,-3,0]).rotation.x = -Math.PI / 2;
    add('cylinder', 0x87d4ce, [0,-3.4,0], [275,1,247]);
    add('cylinder', palette.edge, [0,-12,0], [237,22,215]);
    // Keep the flat infield below every road sample; scenery is grounded near y=0.
    add('cylinder', palette.land, [0,-3.4,0], [222,7,200]);
    for (let i=0;i<38;i++) {
      const angle = i*2.399; const radius=270+(i%5)*22;
      add('box',0x8dd6d7,[Math.cos(angle)*radius,-2.92,Math.sin(angle)*radius],[8+(i%4)*5,.05,.65],[0,angle,0]);
    }
    for (let i=0;i<7;i++) {
      add('cone',0x91b8a2,[-350+i*92,20+(i%3)*7,-400],[80,100+(i%3)*30,70],[0,i,0]);
    }
  } else {
    mesh(new THREE.PlaneGeometry(2500,2500), new THREE.MeshStandardMaterial({color:palette.land,roughness:1}), [0,-.5,0]).rotation.x = -Math.PI / 2;
    if(id==='neon') {
      for(let i=-6;i<=6;i++) { add('box',0x394557,[i*45,.02,0],[.18,.02,600]); add('box',0x394557,[0,.02,i*45],[600,.02,.18]); }
    }
  }
  roadStrip(-15, -9.8, (side,p) => side < -14 ? -p.y+.35 : -.18, palette.land);
  roadStrip(9.8,15,(side,p) => side > 14 ? -p.y+.35 : -.18,palette.land);
  roadStrip(-10,10,-.22,id==='neon'?0x182538:0x8e9685);
  roadStrip(-9,9,0,palette.road);
  roadStrip(-8.9,-8.64,.025,id==='neon'?0x58edec:0xf2e9d3);
  roadStrip(8.64,8.9,.025,id==='neon'?0x58edec:0xf2e9d3);
  // Raised rumble strips, dashed lines and chevrons give each turn a clear line.
  for (let i=0;i<250;i++) {
    const t=i/250;
    for (const off of [-9.55,9.55]) {
      const {p,yaw}=at(t,off,.08);
      add('box',i%2?0xf8f0db:palette.curb,[p.x,p.y,p.z],[1.2,.18,length/250+.12],[0,yaw,0],id==='neon'&&i%2===0);
    }
    if(i%4===0) {
      const {p,yaw}=at(t,0,.035);add('box',0xd6dbd2,[p.x,p.y,p.z],[.22,.025,3.5],[0,yaw,0]);
    }
    if(i%5===0 && (i<30 || i>110&&i<190)) {
      for(const off of [-12,12]) {
        const {p,yaw}=at(t,off,0);
        add('box',id==='neon'?0x87c4e4:0xcbd5c7,[p.x,p.y+.9,p.z],[.25,1.8,.3],[0,yaw,0]);
        add('box',id==='neon'?0x64b9d0:0xe4e5d6,[p.x,p.y+1.5,p.z],[.3,.45,length/50+1],[0,yaw,0],id==='neon');
      }
    }
  }
  // Race gantry and chequered starting grid.
  const start=at(0); const gate=new THREE.Group(); gate.position.copy(start.p);gate.rotation.y=start.yaw;root.add(gate);
  const dark=new THREE.MeshStandardMaterial({color:0x243746,roughness:.6});
  for(const side of [-1,1]) {const post=new THREE.Mesh(new THREE.BoxGeometry(1.1,10,1.1),dark);post.position.set(side*11,5,0);gate.add(post);}
  const top=new THREE.Mesh(new THREE.BoxGeometry(24,3.6,1.1),new THREE.MeshStandardMaterial({color:id==='neon'?0x8168df:0xf9f2d5}));top.position.y=10;gate.add(top);
  const label=labelTexture('APEX KART',id==='neon'?'#6851bf':'#fff4d6',id==='neon'?'#ffffff':'#243746',TRACKS.find(track=>track.id===id).name.toUpperCase());
  if(label) {const board=new THREE.Mesh(new THREE.PlaneGeometry(22,5.5),new THREE.MeshBasicMaterial({map:label,side:THREE.DoubleSide}));board.position.set(0,10,.58);gate.add(board);}
  for(let row=0;row<2;row++) for(let col=0;col<12;col++) {
    const square=new THREE.Mesh(new THREE.BoxGeometry(1.5,.035,1.5),new THREE.MeshStandardMaterial({color:(row+col)%2?0x293641:0xfff8e8}));square.position.set(-8.25+col*1.5,.04,row*1.5);gate.add(square);
  }
  for(let j=0;j<8;j++) {
    const {p,yaw}=at(.99-j*.006,(j%2?3.8:-3.8),.04);
    add('box',0xf7f1d9,[p.x,p.y,p.z],[3,.035,.18],[0,yaw,0]);
  }
  // Decorative race signs sit safely outside the racing surface.
  for(let i=0;i<6;i++) {
    const {p,yaw}=at(.095+i*.154,16,0);
    add('box',0x243746,[p.x,p.y+1.7,p.z],[.3,3.4,.3]);
    add('box',i%2?0xf8ce67:0xf58b68,[p.x,p.y+3.5,p.z],[5,1.8,.3],[0,yaw,0]);
    for(let k=-1;k<2;k++) add('box',0xffffff,[p.x+k*1.1*Math.cos(yaw),p.y+3.5,p.z-k*1.1*Math.sin(yaw)],[.22,.75,.34],[0,yaw,Math.PI/4]);
  }
  // Scatter only away from asphalt, using a deterministic sequence.
  function clear(x,z,distance=25) {
    for(let t=0;t<1;t+=.009) {const p=getPoint(t);if((x-p.x)**2+(z-p.z)**2<distance**2)return false;}
    return true;
  }
  function palm(x,z,size=1,angle=0) {
    const h=11*size;
    add('cylinder',0xb68d62,[x,h*.5,z],[.5*size,h,.5*size],[.08,0,-.12]);
    add('sphere',0x42a169,[x-.7,h,z],[1.4*size,1.1*size,1.4*size]);
    for(let n=0;n<6;n++) {
      const a=n*Math.PI/3+angle;
      add('ico',n%2?0x3f9860:0x72bb63,[x+Math.sin(a)*3.2*size,h-.7*size,z+Math.cos(a)*3.2*size],[1.2*size,.32*size,4.5*size],[.22,a,0]);
    }
  }
  function pine(x,z,size=1) {
    add('cylinder',0x7e6d4f,[x,2*size,z],[.5*size,4*size,.5*size]);
    add('cone',0x497f59,[x,5.8*size,z],[3.5*size,8*size,3.5*size]);
    add('cone',0x659658,[x,8*size,z],[2.6*size,6*size,2.6*size]);
  }
  function cactus(x,z,size=1) {
    add('cylinder',0x6d8c56,[x,3.5*size,z],[.7*size,7*size,.7*size]);add('sphere',0x6d8c56,[x,7*size,z],[.7*size,.7*size,.7*size]);
    for(const s of [-1,1]) {add('box',0x6d8c56,[x+s*1.3*size,3.5*size,z],[2.5*size,.9*size,.9*size]);add('cylinder',0x6d8c56,[x+s*2.3*size,4.5*size,z],[.5*size,2.8*size,.5*size]);add('sphere',0x6d8c56,[x+s*2.3*size,5.9*size,z],[.5*size,.5*size,.5*size]);}
  }
  for(let i=0;i<145;i++) {
    const a=i*2.399963; const radius=25+Math.sqrt(i/145)*193;
    const x=Math.cos(a)*radius, z=Math.sin(a)*radius;
    if(!clear(x,z))continue;
    const size=.72+(i%6)*.13;
    if(id==='coast') {
      if(i%5===0) { add('ico',0x9caa86,[x,1.5,z],[3.7*size,3*size,3*size],[0,a,0]); }
      else if(i%3===0)pine(x,z,size);else palm(x,z,size,a);
      if(i%7===0) for(let k=0;k<4;k++)add('sphere',[0xffd169,0xff9586,0xf8f4cb][k%3],[x+k*.8,1,z+2],[.6,.8,.6]);
    } else if(id==='canyon') {
      if(i%3)cactus(x,z,size);else{
        add('ico',i%2?0xb97a51:0xcf9360,[x,4*size,z],[7*size,9*size,6*size],[0,a,0]);
        add('ico',0xdca56f,[x+2,10*size,z],[5*size,6*size,4.5*size],[0,a+.4,0]);
      }
    }
  }
  if(id==='coast') {
    // A little harbour village with warm plaster walls and terracotta roofs.
    const houses=[[-45,-10,0xffe4b0],[-14,-24,0xf2ac94],[19,-17,0xe8e8bb],[51,-35,0x9dcbd1],[11,22,0xe7bc8c],[-27,35,0xe6d0a4]];
    houses.forEach(([x,z,color],i)=>{
      const h=10+(i%3)*3, yaw=(i%2?-.15:.1);
      add('box',color,[x,h/2,z],[16,h,13],[0,yaw,0]);
      add('cone',0xc77453,[x,h+3.4,z],[12,7,10],[0,Math.PI/4+yaw,0]);
      add('box',0x476879,[x-3,h*.56,z+6.6],[3,4,.2],[0,yaw,0]);
      add('box',0x476879,[x+4,h*.56,z+6.6],[3,4,.2],[0,yaw,0]);
      add('box',0x8c7056,[x,2.5,z+6.7],[2.7,5,.25],[0,yaw,0]);
    });
    // Lighthouse on the headland, white bands and a glowing glass lantern.
    const lx=191,lz=-117;
    add('cylinder',0xece8d4,[lx,2,lz],[16,5,14]);
    for(let i=0;i<5;i++)add('cylinder',i%2?0xf18b72:0xfff4db,[lx,5+i*5,lz],[5.6-i*.4,5,5.6-i*.4]);
    add('cylinder',0x364c59,[lx,29,lz],[5.4,1,5.4]);add('cylinder',0xfad382,[lx,32,lz],[3.3,5,3.3]);
    add('cone',0xd87662,[lx,36,lz],[5.5,4,5.5]);
    for(let i=0;i<4;i++)add('box',0x374d5a,[lx+Math.sin(i*Math.PI/2)*3.5,32,lz+Math.cos(i*Math.PI/2)*3.5],[.3,5,.3]);
    // Beach umbrellas and deckchairs.
    for(let i=0;i<8;i++) {
      const x=-188+i*13,z=123+(i%2)*12;
      if(!clear(x,z,19))continue;
      add('cylinder',0xeee0b2,[x,2.7,z],[.15,5.4,.15]);
      add('cone',i%2?0xf4d670:0xef917b,[x,5.8,z],[4,1.6,4]);
      add('box',0xf8f1d6,[x+3,.6,z+2],[2,.5,4],[0,-.3,0]);
    }
    for(let i=0;i<4;i++) {
      const x=280+i*38,z=50-i*70;
      add('box',0xf3f1df,[x,-.8,z],[7,2,17],[0,-.6,0]);
      add('cylinder',0x8b8d79,[x,8,z],[.12,18,.12]);
      add('cone',i%2?0xf4b366:0xf7f3df,[x+3,9,z],[5,12,.2],[0,0,-.25]);
    }
  } else if(id==='canyon') {
    for(let i=0;i<16;i++) {
      const a=i*Math.PI*2/16, r=270+(i%3)*17;
      const x=Math.cos(a)*r,z=Math.sin(a)*r;
      add('cylinder',i%2?0xb97950:0xc58c5b,[x,20,z],[34,60+(i%4)*13,30],[0,a,0]);
      add('cylinder',0xdfa876,[x,50+(i%4)*6.5,z],[36,8,31],[0,a,0]);
    }
    // Timber mine bridge scenery and old prospectors' cabins.
    for(let i=0;i<5;i++) {
      const x=-50+i*22,z=10+(i%2)*24;
      add('box',0x9f7049,[x,5,z],[14,10,12]); add('cone',0x6e5549,[x,12,z],[11,5,9],[0,Math.PI/4,0]);
      add('box',0x493b38,[x,3,z+6.1],[3,6,.2]);
    }
    for(let i=0;i<8;i++) {const x=40+i*9;add('box',0x896449,[x,1,83],[1,2,.4]);add('box',0xaf8256,[x,1.5,83],[9,.25,.3]);}
  } else {
    // The night circuit winds through a skyline of luminous, varied towers.
    for(let i=0;i<76;i++) {
      const a=i*2.399963,r=i<22?35+Math.sqrt(i/22)*87:245+(i%6)*21;
      const x=Math.cos(a)*r,z=Math.sin(a)*r;
      if(!clear(x,z,30))continue;
      const h=18+(i*23%82),w=10+(i%4)*5;
      const body=[0x27364e,0x314059,0x253047,0x38435d][i%4];
      const glow=[0x88e8f3,0xb68dff,0xf18dd7,0xf9c975][i%4];
      add('box',body,[x,h/2,z],[w,h,w],[0,a*.05,0]);
      add('box',glow,[x,h+.3,z],[w+.5,.45,w+.5],[0,a*.05,0],true);
      for(let floor=5;floor<h-2;floor+=6) {
        add('box',glow,[x,floor,z+w/2+.04],[w*.7,.55,.08],undefined,true);
        add('box',glow,[x+w/2+.04,floor,z],[.08,.55,w*.7],undefined,true);
      }
      if(i%3===0)add('cylinder',glow,[x,h+5,z],[.2,10,.2],undefined,true);
    }
    for(let i=0;i<22;i++) {
      const {p,yaw}=at(i/22,15);
      add('cylinder',0x4e6277,[p.x,p.y+5,p.z],[.22,10,.22]);
      add('box',0x84eaf4,[p.x,p.y+10,p.z],[3.5,.3,1],[0,yaw,0],true);
    }
    roadStrip(-10.3,-10.1,.05,0x64ffff,560,new THREE.MeshBasicMaterial({color:0x64ffff,side:THREE.DoubleSide}));
    roadStrip(10.1,10.3,.05,0xc49aff,560,new THREE.MeshBasicMaterial({color:0xc49aff,side:THREE.DoubleSide}));
  }
  flush();
  // Balloons mark the infield and add movement without touching race geometry.
  const balloons=[];
  if(id==='coast')for(let i=0;i<3;i++) {
    const balloon=new THREE.Group(); balloon.position.set(-75+i*75,45+i*13,-30+i*28);
    const shell=new THREE.Mesh(new THREE.SphereGeometry(8,12,8),new THREE.MeshStandardMaterial({color:[0xf4a078,0xf4ce74,0x88bdb5][i],roughness:.8}));shell.scale.y=1.25;balloon.add(shell);
    const basket=new THREE.Mesh(new THREE.BoxGeometry(3,2,3),new THREE.MeshStandardMaterial({color:0xb68a60}));basket.position.y=-13;balloon.add(basket);
    root.add(balloon);balloons.push({mesh:balloon,base:balloon.position.y});
  }
  return {
    curve, length, halfWidth, getPoint, getTangent, root,
    update(time) { balloons.forEach((b,i)=>b.mesh.position.y=b.base+Math.sin(time*.5+i)*1.8); },
    dispose() {
      root.removeFromParent();
      const disposed=new Set();root.traverse(obj=>{
        // Instance buffers belong to this world; primitive geometry is shared across worlds.
        if(obj.isInstancedMesh)obj.dispose();
        if(obj.geometry&&!Object.values(geometries).includes(obj.geometry)&&!disposed.has(obj.geometry)){obj.geometry.dispose();disposed.add(obj.geometry);}
        for(const mat of obj.material?(Array.isArray(obj.material)?obj.material:[obj.material]):[]) {
          if(disposed.has(mat))continue;if(mat.map)mat.map.dispose();mat.dispose();disposed.add(mat);
        }
      });
    },
  };
}

export function createKart(color = '#fb7756', characterId = 'nova') {
  const group = new THREE.Group(); group.name = 'kart';
  const paint = new THREE.MeshStandardMaterial({color,roughness:.42,metalness:.15});
  const dark = new THREE.MeshStandardMaterial({color:0x293443,roughness:.82});
  const tire = new THREE.MeshStandardMaterial({color:0x1e2731,roughness:1});
  const silver = new THREE.MeshStandardMaterial({color:0xb8c5ca,roughness:.45,metalness:.5});
  const visor = new THREE.MeshStandardMaterial({color:0x263e51,roughness:.2,metalness:.4});
  const white = new THREE.MeshStandardMaterial({color:0xfff2da,roughness:.65});
  function part(geometry,material,p,rotation) {
    const m=new THREE.Mesh(geometry,material);m.position.set(...p);if(rotation)m.rotation.set(...rotation);m.castShadow=true;m.receiveShadow=true;group.add(m);return m;
  }
  part(new THREE.BoxGeometry(2.7,.55,3.8),dark,[0,.6,0]);
  part(new THREE.BoxGeometry(2.7,.55,2.1),paint,[0,.95,.8]);
  const nose=part(new THREE.BoxGeometry(2.45,.48,1.5),paint,[0,1.06,1.7]);nose.rotation.x=-.12;
  part(new THREE.BoxGeometry(.45,.04,2.6),white,[0,1.36,1.1]);
  part(new THREE.BoxGeometry(3.15,.35,.35),dark,[0,.55,2.45]);
  part(new THREE.BoxGeometry(3,.28,.65),paint,[0,1.6,-1.85]);
  part(new THREE.BoxGeometry(.15,.65,.15),silver,[-.9,1.25,-1.85]);part(new THREE.BoxGeometry(.15,.65,.15),silver,[.9,1.25,-1.85]);
  part(new THREE.BoxGeometry(1.2,1.25,.45),dark,[0,1.2,-.8]);
  const wheels=[];
  for(const x of [-1.5,1.5])for(const z of [-1.25,1.35]) {
    const wheel=part(new THREE.CylinderGeometry(.62,.62,.55,12),tire,[x,.6,z],[0,0,Math.PI/2]);wheels.push(wheel);
    part(new THREE.CylinderGeometry(.3,.3,.57,8),silver,[x,.6,z],[0,0,Math.PI/2]);
  }
  const suit = new THREE.MeshStandardMaterial({color,roughness:.75});
  part(new THREE.CapsuleGeometry(.5,.5,3,8),suit,[0,1.7,-.2]);
  const head=part(new THREE.SphereGeometry(.72,16,10),white,[0,2.65,-.18]);
  const helmet=part(new THREE.SphereGeometry(.75,16,10,0,Math.PI*2,0,Math.PI*.63),paint,[0,2.68,-.18]);
  part(new THREE.SphereGeometry(.65,12,8,0,Math.PI,0,Math.PI),visor,[0,2.69,.12]).scale.set(1,.45,.7);
  part(new THREE.BoxGeometry(.18,.06,1.05),white,[0,3.34,-.18]);
  // Hands on the steering wheel and characteristic ear fins on special racers.
  for(const s of [-1,1]) {
    part(new THREE.CapsuleGeometry(.18,.65,2,6),suit,[s*.55,1.92,.4],[.8,0,s*.4]);
    part(new THREE.SphereGeometry(.23,8,6),white,[s*.55,1.72,.72]);
  }
  part(new THREE.TorusGeometry(.45,.08,6,14),dark,[0,1.65,.72],[.65,0,0]);
  // Original silhouettes keep racers recognisable even from the chase camera.
  if(characterId==='nova') {
    for(const s of [-1,1])part(new THREE.ConeGeometry(.23,.7,3),white,[s*.7,2.95,-.28],[0,0,-s*.65]);
  } else if(characterId==='milo') {
    const band=part(new THREE.TorusGeometry(.79,.12,6,12,Math.PI),dark,[0,2.73,-.18]);
    for(const s of [-1,1]) {
      part(new THREE.CylinderGeometry(.32,.32,.24,10),dark,[s*.76,2.76,-.18],[0,0,Math.PI/2]);
      part(new THREE.CylinderGeometry(.23,.23,.27,10),white,[s*.79,2.76,-.18],[0,0,Math.PI/2]);
    }
  } else if(characterId==='jax') {
    for(const s of [-1,1]) {
      part(new THREE.ConeGeometry(.29,.79,4),paint,[s*.43,3.38,-.2],[0,0,-s*.25]);
      part(new THREE.ConeGeometry(.14,.42,3),white,[s*.43,3.43,-.04],[0,0,-s*.25]);
    }
  } else if(characterId==='rio') {
    part(new THREE.BoxGeometry(3.6,.18,.85),white,[0,2.17,-1.93],[.09,0,0]);
    for(const s of [-1,1])part(new THREE.BoxGeometry(.13,.75,.4),paint,[s*1.12,1.8,-1.93]);
    part(new THREE.BoxGeometry(.15,.55,.8),paint,[0,3.45,-.35],[.2,0,0]);
  } else if(characterId==='pixel') {
    const digital=new THREE.MeshStandardMaterial({color:0x76f8ef,emissive:0x50eadf,emissiveIntensity:1,roughness:.3});
    part(new THREE.BoxGeometry(.14,.55,.14),silver,[0,3.53,-.18]);
    part(new THREE.BoxGeometry(.3,.3,.3),digital,[0,3.88,-.18]);
    for(const s of [-1,1])part(new THREE.BoxGeometry(.37,.18,.08),digital,[s*.29,2.78,.58]);
  } else if(characterId==='phantom') {
    const spectral=new THREE.MeshStandardMaterial({color:0xd3b9ff,emissive:0xa584ff,emissiveIntensity:1.5,roughness:.24});
    part(new THREE.TorusGeometry(.7,.08,6,18),spectral,[0,3.68,-.18],[Math.PI/2,0,0]);
    for(const s of [-1,1])part(new THREE.BoxGeometry(.09,.13,3),spectral,[s*1.38,.97,.25]);
    part(new THREE.BoxGeometry(2.8,.1,.08),spectral,[0,1.8,-2.14]);
  }
  // Soft ground contact, independent of a realtime shadow map.
  const shadow=new THREE.Mesh(new THREE.CircleGeometry(2.7,20),new THREE.MeshBasicMaterial({color:0x122230,transparent:true,opacity:.16,depthWrite:false}));shadow.rotation.x=-Math.PI/2;shadow.position.y=.025;shadow.scale.set(.8,1.2,1);group.add(shadow);
  const flame = new THREE.Mesh(new THREE.ConeGeometry(.5,2,7),new THREE.MeshBasicMaterial({color:0x67e5ff,transparent:true,opacity:.85}));flame.rotation.x=-Math.PI/2;flame.position.set(0,.7,-2.5);flame.visible=false;group.add(flame);
  group.userData={wheels,driver:head,helmet,flame};
  return group;
}
