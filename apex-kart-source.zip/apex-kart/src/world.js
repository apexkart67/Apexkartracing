import * as THREE from 'three';

export const TRACKS = [
  { id: 'coast', name: 'Sunshore Circuit', subtitle: 'Ocean air. Hairpin turns. Full send.', theme: 'COASTAL', difficulty: 'ROOKIE', length: '1.0 KM', color: '#ff8655' },
  { id: 'canyon', name: 'Redrock Rally', subtitle: 'Ride the edge of the wild west.', theme: 'DESERT', difficulty: 'INTERMEDIATE', length: '1.1 KM', color: '#e8a354' },
  { id: 'neon', name: 'Neon Nights', subtitle: 'Own the streets after dark.', theme: 'CITY', difficulty: 'EXPERT', length: '1.3 KM', color: '#b593ff' },
  { id: 'alpine', name: 'Frostpeak Pass', subtitle: 'Chase the summit. Carve the snowline.', theme: 'ALPINE', difficulty: 'INTERMEDIATE', length: '1.3 KM', color: '#a9d9ef' },
  { id: 'volcano', name: 'Ember Caldera', subtitle: 'Hot tarmac. Colossal volcanic turns.', theme: 'VOLCANIC', difficulty: 'EXPERT', length: '1.2 KM', color: '#ff8059' },
  { id: 'forest', name: 'Wildwood Run', subtitle: 'Ancient ruins beneath the emerald canopy.', theme: 'WOODLAND', difficulty: 'INTERMEDIATE', length: '1.4 KM', color: '#9aca7b' },
];

const palettes = {
  coast: { sky: 0xb9e6ed, fog: 0xb9e6ed, land: 0x74b65a, edge: 0xe4cc95, road: 0x424c5c, curb: 0xf37764, light: 0xfff0c7 },
  canyon: { sky: 0xf3d7b2, fog: 0xf3d7b2, land: 0xd9a564, edge: 0xb76b45, road: 0x4b4244, curb: 0xffcb73, light: 0xffdfb3 },
  neon: { sky: 0x12162e, fog: 0x19213c, land: 0x29374a, edge: 0x16253a, road: 0x243246, curb: 0x71eced, light: 0xd2d1ff },
  alpine: { sky: 0xc1deed, fog: 0xd7e7ee, land: 0xe7f0ee, edge: 0x8cabb7, road: 0x445362, curb: 0x75b2ca, light: 0xf5f4e3 },
  volcano: { sky: 0x573b45, fog: 0x7b4b48, land: 0x514b4e, edge: 0x302d35, road: 0x373940, curb: 0xf2a069, light: 0xffc19a },
  forest: { sky: 0xb1d7ba, fog: 0xc0d9b8, land: 0x5b8c50, edge: 0x6c7755, road: 0x48504b, curb: 0xd8c48a, light: 0xfff1bd },
};

const wrap = t => ((t % 1) + 1) % 1;
export const BARRIER_LIMIT = 8.65;
const geometries = {
  box: new THREE.BoxGeometry(1, 1, 1),
  cylinder: new THREE.CylinderGeometry(1, 1, 1, 8),
  cone: new THREE.ConeGeometry(1, 1, 7),
  sphere: new THREE.SphereGeometry(1, 12, 8),
  ico: new THREE.IcosahedronGeometry(1, 0),
  frustum: new THREE.CylinderGeometry(.65, 1, 1, 12),
  torus: new THREE.TorusGeometry(1, .15, 6, 20),
};

const layouts = {
    coast: [[0,1.3,150],[-97,2,137],[-162,3,50],[-130,5,-57],[-35,6,-98],[57,3,-146],[144,1.5,-91],[166,1.4,23],[94,1.2,128]],
    canyon: [[0,1.5,160],[-105,2,149],[-176,4,63],[-165,7,-44],[-82,8,-81],[-44,6,-159],[61,4,-171],[153,2,-108],[171,1.5,-17],[125,1.5,52],[130,1.5,130]],
    neon: [[0,1.5,165],[-128,1.5,155],[-180,1.5,57],[-130,1.5,0],[-164,1.5,-117],[-55,1.5,-168],[69,1.5,-142],[164,1.5,-167],[192,1.5,-45],[115,1.5,13],[167,1.5,123],[70,1.5,160]],
    alpine: [[0,2,180],[-130,3,175],[-205,6,100],[-185,10,-10],[-90,17,-30],[-45,20,-130],[45,17,-185],[145,9,-140],[200,4,-40],[150,3,50],[190,2,140],[80,2,185]],
    volcano: [[0,2,180],[-100,2,170],[-180,3,100],[-190,5,-5],[-130,9,-100],[-25,12,-190],[90,10,-150],[185,6,-75],[180,3,50],[95,2,80],[75,2,165]],
    forest: [[0,2,185],[-120,3,165],[-190,6,65],[-155,8,-45],[-185,6,-145],[-65,5,-190],[35,3,-130],[130,4,-180],[195,2,-75],[140,2,20],[180,3,135],[75,2,170]],
  };


function makeTrackCurve(trackId) {
  const curve = new THREE.CatmullRomCurve3((layouts[trackId] || layouts.coast).map(p => new THREE.Vector3(...p)), true, 'catmullrom', .65);
  curve.arcLengthDivisions = 2400;
  return curve;
}

// UI maps use the very same spline as the road and physics, without constructing a world.
export function getTrackMap(trackId) {
  const curve = makeTrackCurve(trackId);
  const points = Array.from({length:97},(_,i)=>curve.getPointAt(i/96));
  const minX=Math.min(...points.map(p=>p.x)),maxX=Math.max(...points.map(p=>p.x));
  const minZ=Math.min(...points.map(p=>p.z)),maxZ=Math.max(...points.map(p=>p.z));
  const size=Math.max(maxX-minX,maxZ-minZ);
  return points.map(p=>({x:.5+(p.x-(minX+maxX)/2)/size,y:.5+(p.z-(minZ+maxZ)/2)/size}));
}

function labelTexture(text, bg = '#152d3c', fg = '#ffffff', small = '') {
  if (typeof document === 'undefined') return null;
  const c = document.createElement('canvas'); c.width = 1024; c.height = 256;
  const ctx = c.getContext('2d');
  ctx.fillStyle = bg; ctx.fillRect(0, 0, 1024, 256);
  ctx.fillStyle = fg; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
  ctx.font = '900 italic 112px Arial'; ctx.fillText(text, 512, small ? 100 : 132);
  if (small) { ctx.font = 'bold 35px Arial'; ctx.fillText(small, 512, 194); }
  const tex = new THREE.CanvasTexture(c); tex.colorSpace = THREE.SRGBColorSpace;
  return tex;
}

export function createWorld(scene, trackId = 'coast') {
  const id = palettes[trackId] ? trackId : 'coast';
  const palette = palettes[id];
  const root = new THREE.Group(); root.name = `track-${id}`; scene.add(root);
  scene.background = new THREE.Color(palette.sky);
  scene.fog = new THREE.Fog(palette.fog, 290, 1100);
  const halfWidth = 9;
  const barrierLimit = BARRIER_LIMIT;
  const terrainHeight = id === 'coast' ? .1 : -.5;
  const lighting = { sky: palette.sky, fog: palette.fog, ground: palette.land, sun: palette.light, ambientIntensity: id === 'neon' ? 1.5 : id === 'volcano' ? 1.65 : 2.1, sunIntensity: id === 'neon' ? 1.2 : 2.6 };
  const curve = makeTrackCurve(id);
  const length = curve.getLength();
  const getPoint = t => curve.getPointAt(wrap(t));
  const getTangent = t => curve.getTangentAt(wrap(t));
  const batches = new Map();
  const matrix = new THREE.Matrix4(); const quaternion = new THREE.Quaternion(); const euler = new THREE.Euler();
  function add(kind, color, p, scale = [1,1,1], rot = [0,0,0], emissive = false) {
    const key = `${kind}-${color}-${emissive}`;
    if (!batches.has(key)) batches.set(key, { kind, color, emissive, matrices: [] });
    euler.set(...rot); quaternion.setFromEuler(euler);
    matrix.compose(new THREE.Vector3(...p), quaternion, new THREE.Vector3(...scale));
    batches.get(key).matrices.push(matrix.clone());
  }
  function flush() {
    for (const batch of batches.values()) {
      const mat = new THREE.MeshStandardMaterial({ color: batch.color, roughness: 0.84,
        ...(batch.emissive ? { emissive: batch.color, emissiveIntensity: 1.3 } : {}) });
      const mesh = new THREE.InstancedMesh(geometries[batch.kind], mat, batch.matrices.length);
      batch.matrices.forEach((m, i) => mesh.setMatrixAt(i, m));
      mesh.castShadow = true; mesh.receiveShadow = true; root.add(mesh);
    }
  }
  function mesh(geometry, material, pos) {
    const m = new THREE.Mesh(geometry, material); if (pos) m.position.set(...pos);
    m.receiveShadow = true; root.add(m); return m;
  }
  function roadStrip(left, right, height, color, segments = 560, material) {
    const vertices = [], indices = [], uvs = [];
    for (let i = 0; i <= segments; i++) {
      const t = i / segments; const p = getPoint(t), tangent = getTangent(t);
      const normal = new THREE.Vector3(-tangent.z, 0, tangent.x).normalize();
      for (const side of [left, right]) {
        const v = p.clone().addScaledVector(normal, side);
        v.y += typeof height === 'function' ? height(side, p) : height;
        vertices.push(v.x, v.y, v.z); uvs.push(side === left ? 0 : 1, t * 80);
      }
      if (i < segments) { const j = i * 2; indices.push(j,j+2,j+1,j+1,j+2,j+3); }
    }
    const geo = new THREE.BufferGeometry(); geo.setAttribute('position', new THREE.Float32BufferAttribute(vertices,3));
    geo.setAttribute('uv', new THREE.Float32BufferAttribute(uvs,2)); geo.setIndex(indices); geo.computeVertexNormals();
    return mesh(geo, material || new THREE.MeshStandardMaterial({ color, roughness: .94, side: THREE.DoubleSide }));
  }
  function at(t, offset = 0, lift = 0) {
    const p = getPoint(t); const d = getTangent(t); p.addScaledVector(new THREE.Vector3(-d.z,0,d.x).normalize(), offset); p.y += lift;
    return { p, yaw: Math.atan2(d.x,d.z), d };
  }
  // The island and its soft, shallow shelf make the circuit feel like a place.
  if (id === 'coast') {
    mesh(new THREE.PlaneGeometry(3000,3000), new THREE.MeshStandardMaterial({color:0x58bbc7,roughness:.35,metalness:.12}), [0,-3,0]).rotation.x = -Math.PI / 2;
    add('cylinder', 0x87d4ce, [0,-3.4,0], [275,1,247]);
    add('cylinder', palette.edge, [0,-12,0], [237,22,215]);
    // Keep the flat infield below every road sample; scenery is grounded near y=0.
    add('cylinder', palette.land, [0,-3.4,0], [222,7,200]);
    for (let i=0;i<38;i++) {
      const angle = i*2.399; const radius=270+(i%5)*22;
      add('box',0x8dd6d7,[Math.cos(angle)*radius,-2.92,Math.sin(angle)*radius],[8+(i%4)*5,.05,.65],[0,angle,0]);
    }
    for (let i=0;i<7;i++) {
      add('cone',0x91b8a2,[-350+i*92,20+(i%3)*7,-400],[80,100+(i%3)*30,70],[0,i,0]);
    }
  } else {
    mesh(new THREE.PlaneGeometry(2500,2500), new THREE.MeshStandardMaterial({color:palette.land,roughness:1}), [0,-.5,0]).rotation.x = -Math.PI / 2;
    if(id==='neon') {
      for(let i=-6;i<=6;i++) { add('box',0x394557,[i*45,.02,0],[.18,.02,600]); add('box',0x394557,[0,.02,i*45],[600,.02,.18]); }
    }
  }
  roadStrip(-15, -9.8, (side,p) => side < -14 ? -p.y+.35 : -.18, palette.land);
  roadStrip(9.8,15,(side,p) => side > 14 ? -p.y+.35 : -.18,palette.land);
  roadStrip(-10,10,-.22,id==='neon'?0x182538:0x8e9685);
  roadStrip(-9,9,0,palette.road);
  roadStrip(-8.9,-8.64,.025,id==='neon'?0x58edec:0xf2e9d3);
  roadStrip(8.64,8.9,.025,id==='neon'?0x58edec:0xf2e9d3);
  // Raised rumble strips, dashed lines and chevrons give each turn a clear line.
  for (let i=0;i<250;i++) {
    const t=i/250;
    for (const off of [-9.55,9.55]) {
      const {p,yaw}=at(t,off,.08);
      add('box',i%2?0xf8f0db:palette.curb,[p.x,p.y,p.z],[1.2,.18,length/250+.12],[0,yaw,0],id==='neon'&&i%2===0);
    }
    if(i%4===0) {
      const {p,yaw}=at(t,0,.035);add('box',0xd6dbd2,[p.x,p.y,p.z],[.22,.025,3.5],[0,yaw,0]);
    }
  }
  // The visible barriers exactly match collision geometry: inner rail face 10.30m,
  // minus the kart's 1.65m footprint gives an 8.65m maximum centre offset.
  const railSegments = Math.ceil(length / 2.6);
  const railColor = id === 'neon' ? 0x4c6684 : id === 'forest' ? 0x8b795e : id === 'volcano' ? 0x66616a : 0xd6ddd6;
  for(let i=0;i<railSegments;i++) {
    for(const side of [-1,1]) {
      const {p,yaw}=at((i+.5)/railSegments,side*10.6,.9);
      add('box',railColor,[p.x,p.y,p.z],[.6,1.6,length/railSegments+.18],[0,yaw,0]);
      add('box',i%6<3?palette.curb:0xf1eddf,[p.x,p.y+.82,p.z],[.64,.12,length/railSegments+.2],[0,yaw,0],id==='neon');
    }
  }
  // Race gantry and chequered starting grid.
  const start=at(0); const gate=new THREE.Group(); gate.position.copy(start.p);gate.rotation.y=start.yaw;root.add(gate);
  const dark=new THREE.MeshStandardMaterial({color:0x243746,roughness:.6});
  for(const side of [-1,1]) {const post=new THREE.Mesh(new THREE.BoxGeometry(1.1,10,1.1),dark);post.position.set(side*11,5,0);gate.add(post);}
  const top=new THREE.Mesh(new THREE.BoxGeometry(24,3.6,1.1),new THREE.MeshStandardMaterial({color:id==='neon'?0x8168df:0xf9f2d5}));top.position.y=10;gate.add(top);
  const label=labelTexture('APEX KART',id==='neon'?'#6851bf':'#fff4d6',id==='neon'?'#ffffff':'#243746',TRACKS.find(track=>track.id===id).name.toUpperCase());
  if(label) {const board=new THREE.Mesh(new THREE.PlaneGeometry(22,5.5),new THREE.MeshBasicMaterial({map:label,side:THREE.DoubleSide}));board.position.set(0,10,.58);gate.add(board);}
  for(let row=0;row<2;row++) for(let col=0;col<12;col++) {
    const square=new THREE.Mesh(new THREE.BoxGeometry(1.5,.035,1.5),new THREE.MeshStandardMaterial({color:(row+col)%2?0x293641:0xfff8e8}));square.position.set(-8.25+col*1.5,.04,row*1.5);gate.add(square);
  }
  for(let j=0;j<8;j++) {
    const {p,yaw}=at(.99-j*.006,(j%2?3.8:-3.8),.04);
    add('box',0xf7f1d9,[p.x,p.y,p.z],[3,.035,.18],[0,yaw,0]);
  }
  // Decorative race signs sit safely outside the racing surface.
  for(let i=0;i<6;i++) {
    const {p,yaw}=at(.095+i*.154,16,0);
    add('box',0x243746,[p.x,p.y+1.7,p.z],[.3,3.4,.3]);
    add('box',i%2?0xf8ce67:0xf58b68,[p.x,p.y+3.5,p.z],[5,1.8,.3],[0,yaw,0]);
    for(let k=-1;k<2;k++) add('box',0xffffff,[p.x+k*1.1*Math.cos(yaw),p.y+3.5,p.z-k*1.1*Math.sin(yaw)],[.22,.75,.34],[0,yaw,Math.PI/4]);
  }
  // Scatter only away from asphalt, using a deterministic sequence.
  function clear(x,z,distance=25) {
    for(let t=0;t<1;t+=.009) {const p=getPoint(t);if((x-p.x)**2+(z-p.z)**2<distance**2)return false;}
    return true;
  }
  function palm(x,z,size=1,angle=0) {
    const h=11*size;
    add('cylinder',0xb68d62,[x,h*.5,z],[.5*size,h,.5*size],[.08,0,-.12]);
    add('sphere',0x42a169,[x-.7,h,z],[1.4*size,1.1*size,1.4*size]);
    for(let n=0;n<6;n++) {
      const a=n*Math.PI/3+angle;
      add('ico',n%2?0x3f9860:0x72bb63,[x+Math.sin(a)*3.2*size,h-.7*size,z+Math.cos(a)*3.2*size],[1.2*size,.32*size,4.5*size],[.22,a,0]);
    }
  }
  function pine(x,z,size=1) {
    add('cylinder',0x7e6d4f,[x,2*size,z],[.5*size,4*size,.5*size]);
    add('cone',0x497f59,[x,5.8*size,z],[3.5*size,8*size,3.5*size]);
    add('cone',0x659658,[x,8*size,z],[2.6*size,6*size,2.6*size]);
  }
  function cactus(x,z,size=1) {
    add('cylinder',0x6d8c56,[x,3.5*size,z],[.7*size,7*size,.7*size]);add('sphere',0x6d8c56,[x,7*size,z],[.7*size,.7*size,.7*size]);
    for(const s of [-1,1]) {add('box',0x6d8c56,[x+s*1.3*size,3.5*size,z],[2.5*size,.9*size,.9*size]);add('cylinder',0x6d8c56,[x+s*2.3*size,4.5*size,z],[.5*size,2.8*size,.5*size]);add('sphere',0x6d8c56,[x+s*2.3*size,5.9*size,z],[.5*size,.5*size,.5*size]);}
  }
  for(let i=0;i<145;i++) {
    const a=i*2.399963; const radius=25+Math.sqrt(i/145)*193;
    const x=Math.cos(a)*radius, z=Math.sin(a)*radius;
    if(!clear(x,z))continue;
    const size=.72+(i%6)*.13;
    if(id==='coast') {
      if(i%5===0) { add('ico',0x9caa86,[x,1.5,z],[3.7*size,3*size,3*size],[0,a,0]); }
      else if(i%3===0)pine(x,z,size);else palm(x,z,size,a);
      if(i%7===0) for(let k=0;k<4;k++)add('sphere',[0xffd169,0xff9586,0xf8f4cb][k%3],[x+k*.8,1,z+2],[.6,.8,.6]);
    } else if(id==='canyon') {
      if(i%3)cactus(x,z,size);else{
        add('ico',i%2?0xb97a51:0xcf9360,[x,4*size,z],[7*size,9*size,6*size],[0,a,0]);
        add('ico',0xdca56f,[x+2,10*size,z],[5*size,6*size,4.5*size],[0,a+.4,0]);
      }
    }
  }
  if(id==='coast') {
    // A little harbour village with warm plaster walls and terracotta roofs.
    const houses=[[-45,-10,0xffe4b0],[-14,-24,0xf2ac94],[19,-17,0xe8e8bb],[51,-35,0x9dcbd1],[11,22,0xe7bc8c],[-27,35,0xe6d0a4]];
    houses.forEach(([x,z,color],i)=>{
      const h=10+(i%3)*3, yaw=(i%2?-.15:.1);
      add('box',color,[x,h/2,z],[16,h,13],[0,yaw,0]);
      add('cone',0xc77453,[x,h+3.4,z],[12,7,10],[0,Math.PI/4+yaw,0]);
      add('box',0x476879,[x-3,h*.56,z+6.6],[3,4,.2],[0,yaw,0]);
      add('box',0x476879,[x+4,h*.56,z+6.6],[3,4,.2],[0,yaw,0]);
      add('box',0x8c7056,[x,2.5,z+6.7],[2.7,5,.25],[0,yaw,0]);
    });
    // Lighthouse on the headland, white bands and a glowing glass lantern.
    const lx=191,lz=-117;
    add('cylinder',0xece8d4,[lx,2,lz],[16,5,14]);
    for(let i=0;i<5;i++)add('cylinder',i%2?0xf18b72:0xfff4db,[lx,5+i*5,lz],[5.6-i*.4,5,5.6-i*.4]);
    add('cylinder',0x364c59,[lx,29,lz],[5.4,1,5.4]);add('cylinder',0xfad382,[lx,32,lz],[3.3,5,3.3]);
    add('cone',0xd87662,[lx,36,lz],[5.5,4,5.5]);
    for(let i=0;i<4;i++)add('box',0x374d5a,[lx+Math.sin(i*Math.PI/2)*3.5,32,lz+Math.cos(i*Math.PI/2)*3.5],[.3,5,.3]);
    // Beach umbrellas and deckchairs.
    for(let i=0;i<8;i++) {
      const x=-188+i*13,z=123+(i%2)*12;
      if(!clear(x,z,19))continue;
      add('cylinder',0xeee0b2,[x,2.7,z],[.15,5.4,.15]);
      add('cone',i%2?0xf4d670:0xef917b,[x,5.8,z],[4,1.6,4]);
      add('box',0xf8f1d6,[x+3,.6,z+2],[2,.5,4],[0,-.3,0]);
    }
    for(let i=0;i<4;i++) {
      const x=280+i*38,z=50-i*70;
      add('box',0xf3f1df,[x,-.8,z],[7,2,17],[0,-.6,0]);
      add('cylinder',0x8b8d79,[x,8,z],[.12,18,.12]);
      add('cone',i%2?0xf4b366:0xf7f3df,[x+3,9,z],[5,12,.2],[0,0,-.25]);
    }
  } else if(id==='canyon') {
    for(let i=0;i<16;i++) {
      const a=i*Math.PI*2/16, r=270+(i%3)*17;
      const x=Math.cos(a)*r,z=Math.sin(a)*r;
      add('cylinder',i%2?0xb97950:0xc58c5b,[x,20,z],[34,60+(i%4)*13,30],[0,a,0]);
      add('cylinder',0xdfa876,[x,50+(i%4)*6.5,z],[36,8,31],[0,a,0]);
    }
    // Timber mine bridge scenery and old prospectors' cabins.
    for(let i=0;i<5;i++) {
      const x=-50+i*22,z=10+(i%2)*24;
      add('box',0x9f7049,[x,5,z],[14,10,12]); add('cone',0x6e5549,[x,12,z],[11,5,9],[0,Math.PI/4,0]);
      add('box',0x493b38,[x,3,z+6.1],[3,6,.2]);
    }
    for(let i=0;i<8;i++) {const x=40+i*9;add('box',0x896449,[x,1,83],[1,2,.4]);add('box',0xaf8256,[x,1.5,83],[9,.25,.3]);}
  } else if(id==='neon') {
    // The night circuit winds through a skyline of luminous, varied towers.
    for(let i=0;i<76;i++) {
      const a=i*2.399963,r=i<22?35+Math.sqrt(i/22)*87:245+(i%6)*21;
      const x=Math.cos(a)*r,z=Math.sin(a)*r;
      if(!clear(x,z,30))continue;
      const h=18+(i*23%82),w=10+(i%4)*5;
      const body=[0x27364e,0x314059,0x253047,0x38435d][i%4];
      const glow=[0x88e8f3,0xb68dff,0xf18dd7,0xf9c975][i%4];
      add('box',body,[x,h/2,z],[w,h,w],[0,a*.05,0]);
      add('box',glow,[x,h+.3,z],[w+.5,.45,w+.5],[0,a*.05,0],true);
      for(let floor=5;floor<h-2;floor+=6) {
        add('box',glow,[x,floor,z+w/2+.04],[w*.7,.55,.08],undefined,true);
        add('box',glow,[x+w/2+.04,floor,z],[.08,.55,w*.7],undefined,true);
      }
      if(i%3===0)add('cylinder',glow,[x,h+5,z],[.2,10,.2],undefined,true);
    }
    for(let i=0;i<22;i++) {
      const {p,yaw}=at(i/22,15);
      add('cylinder',0x4e6277,[p.x,p.y+5,p.z],[.22,10,.22]);
      add('box',0x84eaf4,[p.x,p.y+10,p.z],[3.5,.3,1],[0,yaw,0],true);
    }
    roadStrip(-10.3,-10.1,.05,0x64ffff,560,new THREE.MeshBasicMaterial({color:0x64ffff,side:THREE.DoubleSide}));
    roadStrip(10.1,10.3,.05,0xc49aff,560,new THREE.MeshBasicMaterial({color:0xc49aff,side:THREE.DoubleSide}));
  }
  // Landmarks have a driveable opening wider than the barriers and a clear roof.
  function portal(t, materialColor, roofColor, depth=9, lit=false) {
    const {p,yaw}=at(t);
    const position=(x,y,z)=>[p.x+Math.cos(yaw)*x+Math.sin(yaw)*z,p.y+y,p.z-Math.sin(yaw)*x+Math.cos(yaw)*z];
    for(const side of [-1,1]) {
      add('box',materialColor,position(side*14,6,0),[3.4,12,depth],[0,yaw,0]);
      add('box',roofColor,position(side*14,1,0),[4.1,2,depth+1],[0,yaw,0]);
    }
    add('box',roofColor,position(0,12.2,0),[32,3.2,depth+1],[0,yaw,0]);
    if(lit) {
      add('box',palette.curb,position(0,10.5,0),[25,.22,depth*.8],[0,yaw,0],true);
      for(const side of [-1,1])add('box',palette.curb,position(side*12.15,5.3,0),[.16,10,depth*.8],[0,yaw,0],true);
    }
  }
  if(id==='coast') {
    // A white coastal viaduct frames the north hairpin.
    portal(.32,0xf0e6c8,0xe7c997,12);
    const {p,yaw}=at(.32);
    for(let i=-3;i<=3;i++)add('box',0xfff4db,[p.x+Math.cos(yaw)*i*4,p.y+15,p.z-Math.sin(yaw)*i*4],[.45,3,.45],[0,yaw,0]);
    // Cheerful bunting stretches over the promenade without obstructing the road.
    for(const t of [.13,.71]) {
      const {p,yaw}=at(t);
      for(const side of [-1,1])add('cylinder',0xc9b58c,[p.x+Math.cos(yaw)*side*14,p.y+6,p.z-Math.sin(yaw)*side*14],[.2,12,.2]);
      for(let i=-5;i<=5;i++)add('cone',i%2?0xf3b767:0xea8b77,[p.x+Math.cos(yaw)*i*2.4,p.y+10.5-Math.cos(i/6)*.6,p.z-Math.sin(yaw)*i*2.4],[.65,1.4,.15],[0,yaw,Math.PI]);
    }
  } else if(id==='canyon') {
    // Layered sandstone tunnel, cut wide enough for the full racing line.
    for(let i=0;i<4;i++)portal(.43+i*.011,0xa87855,i%2?0xc68c5b:0xd39c68,4);
    for(const t of [.22,.73]) {
      const {p,yaw}=at(t,24);
      add('frustum',0xb9875c,[p.x,p.y+11,p.z],[8,22,8],[0,yaw,0]);
      add('ico',0xe1ac75,[p.x,p.y+24,p.z],[10,6,8],[0,yaw,0]);
    }
    // Prospectors' water tower, railway and abandoned carts in the infield.
    add('cylinder',0x8b7056,[27,16,-22],[8,11,8]);
    add('cone',0x6e5750,[27,23,-22],[9,4,9]);
    for(const x of [-1,1])for(const z of [-1,1])add('box',0x745b49,[27+x*5,6,-22+z*5],[.7,12,.7],[.08*z,0,.08*x]);
    for(let i=0;i<28;i++) {
      const z=-60+i*4;
      if(!clear(55,z,28))continue;
      add('box',0x7b5f4c,[55,.25,z],[7,.5,.8]);
      for(const side of [-1,1])add('box',0x67717a,[55+side*2,.6,z],[.22,.22,4.1]);
    }
  } else if(id==='neon') {
    for(let i=0;i<7;i++)portal(.5+i*.008,0x303b53,0x465471,2.7,true);
    // Animated billboard-style geometry and a central communications tower.
    add('frustum',0x4a5372,[0,45,5],[18,90,18]);
    add('torus',0xb094ee,[0,85,5],[22,22,22],[Math.PI/2,0,0],true);
    add('cylinder',0x9bebec,[0,111,5],[.7,45,.7],undefined,true);
    for(let i=0;i<3;i++) {
      const {p,yaw}=at(.08+i*.28,27);
      add('box',0x2c3850,[p.x,p.y+13,p.z],[.8,26,.8]);
      add('box',i%2?0x9f86dd:0x67c9d1,[p.x,p.y+23,p.z],[20,8,1],[0,yaw,0],true);
      add('box',0x25304a,[p.x,p.y+23,p.z+.55],[17,5,.15],[0,yaw,0]);
    }
  } else if(id==='alpine') {
    // Snow-covered foothills and a distant, faceted alpine skyline.
    for(let i=0;i<16;i++) {
      const a=i*Math.PI*2/16,r=340+(i%3)*28,x=Math.cos(a)*r,z=Math.sin(a)*r,h=85+(i%5)*24;
      add('cone',i%2?0x8ba6b4:0x9bb5bf,[x,h/2-3,z],[73,h,70],[0,a,0]);
      add('cone',0xf2f4ed,[x,h*.8-3,z],[30,h*.4,29],[0,a,0]);
    }
    for(let i=0;i<125;i++) {
      const a=i*2.399963,r=30+Math.sqrt(i/125)*237,x=Math.cos(a)*r,z=Math.sin(a)*r;
      if(!clear(x,z,25))continue;
      const h=8+(i%6)*1.3;
      add('cylinder',0x8c7969,[x,h*.16,z],[.5,h*.32,.5]);
      for(let tier=0;tier<3;tier++) {
        add('cone',0x648f8e,[x,h*(.45+tier*.21),z],[h*(.3-tier*.055),h*.58,h*(.3-tier*.055)]);
        add('cone',0xf1f4ed,[x,h*(.51+tier*.21),z],[h*(.26-tier*.05),h*.49,h*(.26-tier*.05)]);
      }
      if(i%9===0)add('ico',0xb3cbd0,[x+4,2,z+2],[5,3,4],[0,a,0]);
    }
    // A timber snow shed follows the road through the high pass.
    for(let i=0;i<7;i++)portal(.3+i*.007,0x8d8175,0xe8eeeb,2.8);
    // Ski lodges with red roofs, chimneys and warm lit windows.
    for(let i=0;i<5;i++) {
      const x=-34+i*23,z=55+(i%2)*22;
      if(!clear(x,z,27))continue;
      add('box',0xb99778,[x,7,z],[17,14,14]);
      add('cone',0x9a6c65,[x,17,z],[14,8,12],[0,Math.PI/4,0]);
      add('cone',0xf0f3ec,[x,18.1,z],[13.5,7,11.5],[0,Math.PI/4,0]);
      add('box',0x8d817a,[x+4,19,z-3],[2,9,2]);
      for(const side of [-1,1])add('box',0xffda96,[x+side*4,8,z+7.1],[3.5,4,.2],undefined,true);
    }
    // Cable cars cross overhead; supports remain outside the entire track footprint.
    const cableStart=new THREE.Vector3(-120,44,55),cableEnd=new THREE.Vector3(142,57,-78);
    const cableDir=cableEnd.clone().sub(cableStart),cableMid=cableStart.clone().add(cableEnd).multiplyScalar(.5);
    const cableRot=new THREE.Euler().setFromQuaternion(new THREE.Quaternion().setFromUnitVectors(new THREE.Vector3(0,1,0),cableDir.clone().normalize()));
    for(const side of [-1,1])add('cylinder',0x5c6977,[cableMid.x,cableMid.y,cableMid.z+side*2],[.12,cableDir.length(),.12],[cableRot.x,cableRot.y,cableRot.z]);
    for(const point of [cableStart,cableEnd])if(clear(point.x,point.z,23)) {
      add('cylinder',0x7b8a94,[point.x,point.y/2,point.z],[1.1,point.y,1.1]);
      add('box',0x71818e,[point.x,point.y,point.z],[9,1.2,1.2]);
    }
    for(let i=1;i<5;i++) {
      const p=cableStart.clone().lerp(cableEnd,i/5);
      add('box',0x606d77,[p.x,p.y-2,p.z],[.35,4,.35]);
      add('box',i%2?0xd57e6e:0x75a8b8,[p.x,p.y-6,p.z],[5,5,5]);
      add('box',0x375568,[p.x,p.y-5.3,p.z+2.53],[4,2.4,.1]);
      add('box',0xe5edeb,[p.x,p.y-3.45,p.z],[5.2,.35,5.2]);
    }
    // Frozen lake safely inside the high valley.
    add('cylinder',0x9dcdd6,[10,-.35,-10],[54,.18,32]);
    for(let i=0;i<7;i++)add('box',0xc5e4e5,[-25+i*10,-.23,-10+(i%2)*4],[12,.03,.22],[0,.25,0]);
  } else if(id==='volcano') {
    // The central caldera is a tiered basalt mountain with an open, glowing crater.
    add('frustum',0x39363f,[0,34,-15],[76,69,76]);
    add('frustum',0x4b4248,[0,83,-15],[50,30,50]);
    add('torus',0x24242c,[0,99,-15],[34,34,34],[Math.PI/2,0,0]);
    add('cylinder',0xf6a044,[0,98,-15],[29,1,29],undefined,true);
    add('cylinder',0xf5ce6d,[0,98.6,-15],[21,.2,21],undefined,true);
    for(let i=0;i<17;i++) {
      const a=i*2.399963,r=235+(i%4)*18,x=Math.cos(a)*r,z=Math.sin(a)*r;
      add('frustum',i%2?0x3c3943:0x59515a,[x,10+(i%4)*6,z],[11,23+(i%4)*12,12],[0,a,0]);
      add('ico',0x6a5d60,[x,23+(i%4)*12,z],[9,5,9],[0,a,0]);
    }
    for(let i=0;i<85;i++) {
      const a=i*2.399963,r=82+Math.sqrt(i/85)*188,x=Math.cos(a)*r,z=Math.sin(a)*r;
      if(!clear(x,z,28))continue;
      const size=2+(i%5)*1.5;
      add('ico',i%2?0x6e5b59:0x49464f,[x,size*.6,z],[size,size*1.8,size],[0,a,0]);
      if(i%3===0) {
        add('cylinder',0x2e2c34,[x,.2,z+5],[5,.5,4]);
        add('cylinder',0xf38e45,[x,.5,z+5],[3.3,.2,2.7],undefined,true);
        add('cone',0xeab579,[x,1.3,z+5],[.5,2,.5],undefined,true);
      }
    }
    // Lava pools lie below the road, separated by dark rock shores.
    for(const [x,z,r] of [[-75,10,18],[70,-50,16],[16,93,21],[-230,-80,27],[225,-150,31]]) {
      if(!clear(x,z,r+20))continue;
      add('cylinder',0x25252e,[x,-.1,z],[r+4,.7,r*.8+4]);
      add('cylinder',0xec773b,[x,.28,z],[r,.12,r*.8],undefined,true);
      add('torus',0xffbd55,[x,.4,z],[r*.7,r*.7,r*.7],[Math.PI/2,0,0],true);
    }
    for(let i=0;i<3;i++)portal(.55+i*.009,0x37353e,0x5f5053,4,true);
    // Orange warning beacons and reactor-like monitoring stations.
    for(const t of [.12,.36,.8])for(const off of [-15,15]) {
      const {p}=at(t,off);
      add('cylinder',0x77717a,[p.x,p.y+3,p.z],[.3,6,.3]);
      add('sphere',0xffbd65,[p.x,p.y+6.5,p.z],[.7,.7,.7],undefined,true);
    }
  } else if(id==='forest') {
    // Giant redwoods, spreading roots and layered canopy silhouettes.
    for(let i=0;i<135;i++) {
      const a=i*2.399963,r=30+Math.sqrt(i/135)*262,x=Math.cos(a)*r,z=Math.sin(a)*r;
      if(!clear(x,z,30))continue;
      const h=23+(i%7)*3,size=.75+(i%5)*.12;
      add('frustum',i%2?0x776b4d:0x89704e,[x,h*.44,z],[2.4*size,h*.88,2.4*size]);
      for(let j=0;j<3;j++) {
        const ra=j*Math.PI*2/3+a;
        add('ico',j%2?0x467c4c:0x74a35c,[x+Math.sin(ra)*5*size,h+j*1.6,z+Math.cos(ra)*5*size],[9*size,7*size,8*size],[0,ra,0]);
        add('box',0x81704d,[x+Math.sin(ra)*2,.55,z+Math.cos(ra)*2],[1.2,1.1,6*size],[0,ra,.1]);
      }
      if(i%4===0) {
        const mx=x+7,mz=z+5;
        add('cylinder',0xe9d4b2,[mx,1.6,mz],[.6,3.2,.6]);
        add('sphere',i%2?0xd28b62:0xe0ae70,[mx,3,mz],[2.5,.85,2.5]);
        for(let j=0;j<3;j++)add('sphere',0xf5e7c8,[mx-1+j,3.75,mz+(j%2)*.8],[.35,.1,.35]);
      }
    }
    // Mossy ancient structures and roofless temples nestle in the infield.
    for(const [x,z] of [[-30,-20],[45,45],[35,-65]]) {
      if(!clear(x,z,35))continue;
      add('box',0x8b9476,[x,1,z],[26,2,23]);
      for(const side of [-1,1])for(const depth of [-1,1]) {
        add('cylinder',0xb0ad8d,[x+side*9,8,z+depth*8],[2,14,2]);
        add('box',0x7a8b66,[x+side*9,15,z+depth*8],[5,1.7,5]);
      }
      add('box',0xa6ab87,[x,16.5,z-8],[24,2.6,5]);
      for(let j=0;j<4;j++)add('ico',0x628b4f,[x-9+j*6,18,z-8],[3,1.1,3]);
    }
    for(const t of [.27,.7]) {
      portal(t,0x9eaa87,0xc1bd94,5);
      const {p,yaw}=at(t);
      for(let i=-2;i<=2;i++)add('ico',0x5e9158,[p.x+Math.cos(yaw)*i*5,p.y+14.5,p.z-Math.sin(yaw)*i*5],[3.4,1.1,2.7]);
    }
    // Small fern clusters, flowers, logs and standing stones complete the forest floor.
    for(let i=0;i<65;i++) {
      const a=i*2.399963,r=30+Math.sqrt(i/65)*200,x=Math.cos(a)*r,z=Math.sin(a)*r;
      if(!clear(x,z,19))continue;
      for(let j=0;j<3;j++)add('ico',j%2?0x8eae63:0x6e9c59,[x+Math.sin(j*2.1)*1.3,1,z+Math.cos(j*2.1)*1.3],[1,1.6,.45],[.3,j*2.1,0]);
      if(i%4===0)add('cylinder',0x7d6c52,[x+4,1,z+3],[1.1,7,1.1],[Math.PI/2,a,0]);
      if(i%7===0)add('ico',0x99a080,[x-4,3,z+4],[2.4,5,2],[0,a,0]);
    }
  }

  // High cloud banks establish scale above the course without hiding the racing line.
  if(['coast','alpine','forest'].includes(id))for(let i=0;i<13;i++) {
    const angle=i*2.399963,radius=260+(i%4)*29;
    const x=Math.cos(angle)*radius,z=Math.sin(angle)*radius,h=90+(i%4)*12;
    for(let j=-1;j<=1;j++)add('sphere',id==='forest'?0xd5e3ce:0xeff3eb,[x+j*11,h+(j===0?3:0),z],[18,6+j*1.2,10]);
  }
  // Basalt smoke rises far above the caldera and the driveable surface.
  if(id==='volcano')for(let i=0;i<6;i++)add('ico',i%2?0x7c6261:0x806c6a,[i*5,122+i*12,-15-i*3],[12+i*2,11+i*1.6,10+i*2],[0,i,0]);
  flush();
  // Balloons mark the infield and add movement without touching race geometry.
  const balloons=[];
  if(id==='coast')for(let i=0;i<3;i++) {
    const balloon=new THREE.Group(); balloon.position.set(-75+i*75,45+i*13,-30+i*28);
    const shell=new THREE.Mesh(new THREE.SphereGeometry(8,12,8),new THREE.MeshStandardMaterial({color:[0xf4a078,0xf4ce74,0x88bdb5][i],roughness:.8}));shell.scale.y=1.25;balloon.add(shell);
    const basket=new THREE.Mesh(new THREE.BoxGeometry(3,2,3),new THREE.MeshStandardMaterial({color:0xb68a60}));basket.position.y=-13;balloon.add(basket);
    root.add(balloon);balloons.push({mesh:balloon,base:balloon.position.y});
  }
  return {
    curve, length, halfWidth, barrierLimit, barrier: {center:10.6,width:.6,height:1.6,kartRadius:1.65,segmentsPerSide:railSegments}, terrainHeight, lighting, getPoint, getTangent, root,
    update(time) { balloons.forEach((b,i)=>b.mesh.position.y=b.base+Math.sin(time*.5+i)*1.8); },
    dispose() {
      root.removeFromParent();
      const disposed=new Set();root.traverse(obj=>{
        // Instance buffers belong to this world; primitive geometry is shared across worlds.
        if(obj.isInstancedMesh)obj.dispose();
        if(obj.geometry&&!Object.values(geometries).includes(obj.geometry)&&!disposed.has(obj.geometry)){obj.geometry.dispose();disposed.add(obj.geometry);}
        for(const mat of obj.material?(Array.isArray(obj.material)?obj.material:[obj.material]):[]) {
          if(disposed.has(mat))continue;if(mat.map)mat.map.dispose();mat.dispose();disposed.add(mat);
        }
      });
    },
  };
}


export { createKart } from './models.js';
