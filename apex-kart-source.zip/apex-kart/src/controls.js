export const DEFAULT_KEYBINDS = Object.freeze({
  accelerate: Object.freeze(['KeyW', 'ArrowUp']),
  brake: Object.freeze(['KeyS', 'ArrowDown']),
  left: Object.freeze(['KeyA', 'ArrowLeft']),
  right: Object.freeze(['KeyD', 'ArrowRight']),
  drift: Object.freeze(['Space']),
  item: Object.freeze(['KeyE']),
  recover: Object.freeze(['KeyR']),
  pause: Object.freeze(['Escape']),
});

export const ACTION_LABELS = Object.freeze({
  accelerate: 'Accelerate', brake: 'Brake', left: 'Steer left', right: 'Steer right',
  drift: 'Drift', item: 'Use power-up', recover: 'Recover kart', pause: 'Pause',
});

const ACTIONS = Object.keys(DEFAULT_KEYBINDS);
const ALLOWED_CODE = /^(?:Key[A-Z]|Digit[0-9]|Arrow(?:Up|Down|Left|Right)|Space|Escape|Shift(?:Left|Right)|Enter|Backspace|Delete|Minus|Equal|Bracket(?:Left|Right)|Backslash|Semicolon|Quote|Comma|Period|Slash|Backquote)$/;
const FALLBACK_CODES = [...new Set([
  ...Object.values(DEFAULT_KEYBINDS).flat(),
  ...'IJKLOUPTYZXCVBNM'.split('').map(letter => `Key${letter}`), 'Enter',
])];

export function isAllowedKeyCode(code) {
  return typeof code === 'string' && ALLOWED_CODE.test(code);
}

// Persisted settings may be partial or corrupt. Keep valid user choices in
// action order, discard duplicate claims, then fill only empty actions with an
// available default. Capture-time edits use rebindKey to report conflicts.
export function normalizeKeybinds(value) {
  const source = value && typeof value === 'object' ? value : {};
  const result = {}, claimed = new Set();
  for (const action of ACTIONS) {
    const candidate = Array.isArray(source[action]) ? source[action] : DEFAULT_KEYBINDS[action];
    const valid = [...new Set(candidate.filter(isAllowedKeyCode))].slice(0, 2);
    result[action] = valid.filter(code => !claimed.has(code));
    if (!result[action].length) {
      result[action] = DEFAULT_KEYBINDS[action].filter(code => !claimed.has(code));
      if (!result[action].length) result[action] = [FALLBACK_CODES.find(code => !claimed.has(code))];
    }
    result[action].forEach(code => claimed.add(code));
  }
  return result;
}

export function keyLabel(code) {
  if (!code) return 'Unbound';
  if (/^Key[A-Z]$/.test(code)) return code.slice(3);
  if (/^Digit[0-9]$/.test(code)) return code.slice(5);
  return {
    ArrowUp: '↑', ArrowDown: '↓', ArrowLeft: '←', ArrowRight: '→', Space: 'Space', Escape: 'Esc',
    ShiftLeft: 'L Shift', ShiftRight: 'R Shift', Enter: 'Enter', Backspace: 'Backspace', Delete: 'Delete',
    Minus: '−', Equal: '=', BracketLeft: '[', BracketRight: ']', Backslash: '\\',
    Semicolon: ';', Quote: "'", Comma: ',', Period: '.', Slash: '/', Backquote: '`',
  }[code] || String(code);
}

export function rebindKey(value, action, slot, code) {
  const bindings = normalizeKeybinds(value);
  if (!Object.hasOwn(DEFAULT_KEYBINDS, action)) return { bindings, error: 'Unknown control action.' };
  const index = Number(slot);
  if (!Number.isInteger(index) || index < 0 || index > 1) return { bindings, error: 'Choose the first or second key slot.' };
  if (code == null || code === '') {
    if (index >= bindings[action].length) return { bindings, error: null };
    if (bindings[action].length === 1) return { bindings, error: 'Keep at least one key for this action.' };
    bindings[action].splice(index, 1);
    return { bindings, error: null };
  }
  if (!isAllowedKeyCode(code)) return { bindings, error: 'That key is reserved. Choose a letter, number, arrow, Space, Shift, Enter, or punctuation.' };
  for (const otherAction of ACTIONS) {
    const otherSlot = bindings[otherAction].indexOf(code);
    if (otherSlot !== -1 && (otherAction !== action || otherSlot !== index)) {
      return { bindings, error: `${keyLabel(code)} is already assigned to ${ACTION_LABELS[otherAction]}.` };
    }
  }
  bindings[action][index] = code;
  return { bindings, error: null };
}
