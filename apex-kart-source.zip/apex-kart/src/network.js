import Peer from 'peerjs';

const PROTOCOL_VERSION = 2;
const PREFIX = 'apex-kart-v2-';
const ALPHABET = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
const TRACKS = new Set(['coast', 'canyon', 'neon', 'alpine', 'volcano', 'forest']);
const ITEMS = new Set(['turbo', 'rocket', 'shield', 'banana', 'emp', 'nitro']);
const MAX_PLAYERS = 8;
const WAIT_MS = 14000;
const STATE_INTERVAL = 20;
const ITEM_INTERVAL = 150;
const now = () => performance.now();

const cleanName = value => String(value || 'Racer').replace(/[\u0000-\u001f\u007f]/g, '').trim().slice(0, 18) || 'Racer';
const cleanCharacter = value => String(value || 'rookie').replace(/[^a-zA-Z0-9_-]/g, '').slice(0, 32) || 'rookie';
const cleanColor = value => typeof value === 'string' && /^#[0-9a-f]{6}$/i.test(value) ? value.toLowerCase() : undefined;
const makeCode = () => Array.from(crypto.getRandomValues(new Uint8Array(6)), n => ALPHABET[n % ALPHABET.length]).join('');

// Keep relay messages small and reject invalid JSON values without constraining
// the renderer to one particular set of physics fields.
function cleanPayload(value, depth = 0) {
  if (depth > 3 || value == null) return null;
  if (typeof value === 'number') return Number.isFinite(value) ? Math.max(-1e9, Math.min(1e9, value)) : null;
  if (typeof value === 'boolean') return value;
  if (typeof value === 'string') return value.slice(0, 80);
  if (Array.isArray(value)) return value.slice(0, 16).map(v => cleanPayload(v, depth + 1));
  if (typeof value === 'object') {
    const out = {};
    for (const [key, item] of Object.entries(value).slice(0, 24)) {
      if (/^[a-zA-Z][a-zA-Z0-9_]{0,31}$/.test(key)) out[key] = cleanPayload(item, depth + 1);
    }
    return out;
  }
  return null;
}

function cleanItem(value, players) {
  if (!value || typeof value !== 'object' || Array.isArray(value) || !ITEMS.has(value.type)) return null;
  if (!Number.isFinite(value.progress) || value.progress < -.1 || value.progress > 3.5) return null;
  if (!Number.isFinite(value.lateral) || Math.abs(value.lateral) > 50) return null;
  if (value.target != null && (typeof value.target !== 'string' || !players.some(p => p.id === value.target))) return null;
  return { type: value.type, target: value.target ?? null, progress: value.progress, lateral: value.lateral };
}

export function createNetwork(callback = () => {}) {
  let peer = null;
  let hostConnection = null;
  let hosting = false;
  let code = '';
  let self = null;
  let players = [];
  let racing = false;
  let generation = 0;
  let clockOffset = 0;
  let bestPing = Infinity;
  let pending = null;
  let pingTimer = null;
  let lastOwnState = -Infinity;
  let lastOwnItem = -Infinity;
  const connections = new Map();
  const receivedTimes = new Map();

  const emit = event => callback(event);
  const lobby = () => emit({ type: 'lobby', players: players.map(p => ({ ...p })), code, isHost: hosting });
  const send = (connection, data) => {
    if (!connection?.open) return;
    try { connection.send(data); } catch { /* The close event removes this peer. */ }
  };
  const relay = (data, except = null) => {
    for (const [id, connection] of connections) if (id !== except) send(connection, data);
  };
  const broadcastLobby = () => {
    relay({ type: 'lobby', players, code });
    lobby();
  };
  function clearSession(notify = false, message) {
    generation++;
    if (pending) {
      clearTimeout(pending.timer);
      pending.reject(new Error(message || 'Connection cancelled.'));
      pending = null;
    }
    clearInterval(pingTimer);
    pingTimer = null;
    for (const connection of connections.values()) connection.close();
    connections.clear();
    receivedTimes.clear();
    hostConnection?.close();
    hostConnection = null;
    peer?.destroy();
    peer = null;
    self = null;
    players = [];
    hosting = false;
    racing = false;
    code = '';
    clockOffset = 0;
    bestPing = Infinity;
    lastOwnState = -Infinity;
    lastOwnItem = -Infinity;
    if (notify) emit({ type: 'closed', message });
  }
  function fail(message) {
    const wasPending = !!pending;
    if (pending) {
      clearTimeout(pending.timer);
      const reject = pending.reject;
      pending = null;
      reject(new Error(message));
    }
    clearSession(false);
    emit({ type: 'error', message });
    if (!wasPending) emit({ type: 'closed', message });
  }
  function connected() {
    if (!pending) return;
    clearTimeout(pending.timer);
    const resolve = pending.resolve;
    pending = null;
    resolve(code);
  }
  function begin(name, character, isHost, room, color) {
    clearSession(false);
    hosting = isHost;
    code = room;
    const token = generation;
    return new Promise((resolve, reject) => {
      pending = { resolve, reject, timer: setTimeout(() => {
        if (token === generation) fail('Connection timed out. Check your connection or try another network.');
      }, WAIT_MS) };
      peer = new Peer(isHost ? PREFIX + room : undefined, {
        debug: 0,
        config: { iceServers: [{ urls: 'stun:stun.l.google.com:19302' }, { urls: 'stun:stun1.l.google.com:19302' }] },
      });
      peer.on('open', id => {
        if (token !== generation) return;
        self = { id, name: cleanName(name), character: cleanCharacter(character), color: cleanColor(color) };
        if (isHost) {
          players = [self];
          connected();
          lobby();
        } else {
          hostConnection = peer.connect(PREFIX + room, {
            reliable: true,
            serialization: 'json',
            metadata: { version: PROTOCOL_VERSION, name: self.name, character: self.character, color: self.color },
          });
          wireClient(hostConnection, token);
        }
      });
      peer.on('connection', connection => {
        if (token !== generation || !hosting) { connection.close(); return; }
        wireGuest(connection, token);
      });
      peer.on('error', error => {
        if (token !== generation) return;
        const messages = {
          'peer-unavailable': 'Room not found. Check the code and make sure the host is online.',
          'unavailable-id': 'That room code is already in use. Create a new room.',
          'browser-incompatible': 'Your browser does not support WebRTC. Try current Chrome, Edge, or Firefox.',
          'network': 'The signaling service could not be reached. Check your connection and try again.',
          'server-error': 'The signaling service is unavailable. Try again shortly.',
          'webrtc': 'A direct connection could not be made. Try another network.',
        };
        const message = messages[error.type] || 'The online connection failed. Please try again.';
        // Signaling interruptions do not end already established WebRTC races.
        if (!pending && (hostConnection?.open || connections.size) && ['network', 'server-error', 'socket-error'].includes(error.type)) {
          emit({ type: 'warning', message: 'Signaling disconnected. Existing racers remain connected; new racers may need to wait.' });
          return;
        }
        fail(message);
      });
      peer.on('disconnected', () => {
        if (token !== generation || peer?.destroyed) return;
        try { peer.reconnect(); } catch { /* Peer error supplies the useful error. */ }
      });
    });
  }
  function wireGuest(connection, token) {
    let accepted = false;
    const timer = setTimeout(() => { if (!accepted) connection.close(); }, 8000);
    connection.on('open', () => {
      clearTimeout(timer);
      if (token !== generation) { connection.close(); return; }
      let reason = '';
      if (connection.metadata?.version !== PROTOCOL_VERSION) reason = 'This room uses a different game version. Refresh the game.';
      else if (racing) reason = 'This race has already started. Join the next race.';
      else if (players.length >= MAX_PLAYERS) reason = 'This room is full (8 racers).';
      else if (connections.has(connection.peer)) reason = 'You are already connected to this room.';
      if (reason) {
        send(connection, { type: 'reject', message: reason });
        setTimeout(() => connection.close(), 250);
        return;
      }
      accepted = true;
      connections.set(connection.peer, connection);
      players.push({ id: connection.peer, name: cleanName(connection.metadata.name), character: cleanCharacter(connection.metadata.character), color: cleanColor(connection.metadata.color) });
      broadcastLobby();
    });
    let lastState = -Infinity;
    let lastItem = -Infinity;
    let lastPing = -Infinity;
    connection.on('data', data => {
      if (token !== generation || !accepted || !data || typeof data !== 'object') return;
      const time = now();
      if (data.type === 'ping' && Number.isFinite(data.sent) && time - lastPing >= 500) {
        lastPing = time;
        send(connection, { type: 'pong', sent: data.sent, now: Date.now() });
      } else if (data.type === 'state' && racing && time - lastState >= STATE_INTERVAL) {
        lastState = time;
        const state = cleanPayload(data.state);
        if (!state || Array.isArray(state) || typeof state !== 'object') return;
        const event = { type: 'state', id: connection.peer, state };
        relay(event, connection.peer);
        emit(event);
      } else if (data.type === 'item' && racing && time - lastItem >= ITEM_INTERVAL) {
        lastItem = time;
        const item = cleanItem(data.item, players);
        if (!item) return;
        const event = { type: 'item', id: connection.peer, item };
        relay(event, connection.peer);
        emit(event);
      }
    });
    const remove = () => {
      clearTimeout(timer);
      if (token !== generation || !accepted || !connections.has(connection.peer)) return;
      connections.delete(connection.peer);
      receivedTimes.delete(connection.peer);
      players = players.filter(p => p.id !== connection.peer);
      const event = { type: 'left', id: connection.peer, players };
      relay(event);
      emit(event);
      broadcastLobby();
    };
    connection.on('close', remove);
    connection.on('error', () => { connection.close(); remove(); });
  }
  function wireClient(connection, token) {
    connection.on('open', () => {
      if (token !== generation) return;
      const ping = () => send(connection, { type: 'ping', sent: Date.now() });
      ping();
      pingTimer = setInterval(ping, 1800);
    });
    connection.on('data', data => {
      if (token !== generation || !data || typeof data !== 'object') return;
      if (data.type === 'reject') {
        fail(String(data.message || 'The room could not be joined.').slice(0, 180));
      } else if (data.type === 'lobby' && Array.isArray(data.players)) {
        players = data.players.slice(0, MAX_PLAYERS).filter(p => p && typeof p.id === 'string').map(p => ({ id: p.id.slice(0, 100), name: cleanName(p.name), character: cleanCharacter(p.character), color: cleanColor(p.color) }));
        connected();
        lobby();
      } else if (data.type === 'pong' && Number.isFinite(data.sent) && Number.isFinite(data.now)) {
        const roundtrip = Date.now() - data.sent;
        if (roundtrip >= 0 && roundtrip < bestPing) {
          bestPing = roundtrip;
          clockOffset = data.now - (data.sent + roundtrip / 2);
        }
      } else if (data.type === 'start' && TRACKS.has(data.trackId) && Number.isFinite(data.startAt)) {
        racing = true;
        emit({ type: 'start', trackId: data.trackId, players: players.map(p => ({ ...p })), startAt: data.startAt - clockOffset });
      } else if ((data.type === 'state' || data.type === 'item') && racing && players.some(p => p.id === data.id)) {
        const time = now();
        const previous = receivedTimes.get(data.id) || { state: -Infinity, item: -Infinity };
        if (time - previous[data.type] < (data.type === 'state' ? STATE_INTERVAL : ITEM_INTERVAL)) return;
        previous[data.type] = time;
        receivedTimes.set(data.id, previous);
        const value = data.type === 'item' ? cleanItem(data.item, players) : cleanPayload(data.state);
        if (value && typeof value === 'object' && !Array.isArray(value)) emit({ type: data.type, id: data.id, [data.type]: value });
      } else if (data.type === 'left' && typeof data.id === 'string') {
        players = players.filter(p => p.id !== data.id);
        receivedTimes.delete(data.id);
        emit({ type: 'left', id: data.id, players: players.map(p => ({ ...p })) });
      }
    });
    connection.on('close', () => {
      if (token === generation) fail('The host left the room or the connection was lost.');
    });
    connection.on('error', () => {
      if (token === generation) fail('A direct connection could not be made. Try another network.');
    });
  }

  return {
    host(name, character, color) { return begin(name, character, true, makeCode(), color); },
    join(room, name, character, color) {
      const normalized = String(room || '').trim().toUpperCase();
      if (!/^[A-HJ-NP-Z2-9]{6}$/.test(normalized)) return Promise.reject(new Error('Enter a valid 6-character room code.'));
      return begin(name, character, false, normalized, color);
    },
    start(trackId) {
      if (!hosting || !self) throw new Error('Only the host can start a race.');
      if (racing) throw new Error('A race is already in progress.');
      if (!TRACKS.has(trackId)) throw new Error('Choose a valid track.');
      racing = true;
      const event = { type: 'start', trackId, players: players.map(p => ({ ...p })), startAt: Date.now() + 4500 };
      relay(event);
      emit(event);
    },
    broadcastState(state) {
      if (!racing || !self || now() - lastOwnState < STATE_INTERVAL) return;
      const safe = cleanPayload(state);
      if (!safe || typeof safe !== 'object' || Array.isArray(safe)) return;
      lastOwnState = now();
      const event = { type: 'state', id: self.id, state: safe };
      if (hosting) relay(event); else send(hostConnection, event);
    },
    sendItem(item) {
      if (!racing || !self || now() - lastOwnItem < ITEM_INTERVAL) return;
      const safe = cleanItem(item, players);
      if (!safe) return;
      lastOwnItem = now();
      const event = { type: 'item', id: self.id, item: safe };
      if (hosting) relay(event); else send(hostConnection, event);
    },
    leave() { clearSession(true); },
    get isHost() { return hosting; },
    get peers() { return players.map(p => ({ ...p })); },
    get id() { return self?.id || null; },
    get roomCode() { return code; },
    get connected() { return !!self && (hosting || !!hostConnection?.open); },
  };
}
