import * as THREE from 'three';
import { createWorld, createKart, TRACKS } from './world.js';

const clamp = THREE.MathUtils.clamp;
const wrap = n => ((n % 1) + 1) % 1;
const colors = ['#ff713f', '#48c6c1', '#ad83eb', '#ffd05b', '#8cd26b', '#f77eac', '#7ba7ff', '#f1f0d9'];
const botNames = ['Coco', 'Bolt', 'Mochi', 'Dash', 'Orbit', 'Sunny', 'Rocco'];
const itemNames = { turbo: 'TURBO', rocket: 'ROCKET', shield: 'SHIELD', banana: 'BANANA', emp: 'EMP PULSE', nitro: 'MEGA NITRO' };
const defaultDev = () => ({ infiniteBoost: false, invincible: false, speedMultiplier: 1, freezeAI: false, infiniteItems: false, timeScale: 1 });
const finite = (value, fallback = 0) => Number.isFinite(Number(value)) ? Number(value) : fallback;

export class KartGame {
  constructor(canvas, callbacks = {}) {
    this.canvas = canvas;
    this.callbacks = callbacks;
    this.scene = new THREE.Scene();
    this.scene.background = new THREE.Color('#abdfe9');
    this.camera = new THREE.PerspectiveCamera(55, 1, .2, 1600);
    this.renderer = new THREE.WebGLRenderer({ canvas, antialias: true, alpha: false, powerPreference: 'high-performance' });
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 1.7));
    this.renderer.shadowMap.enabled = true;
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    this.renderer.outputColorSpace = THREE.SRGBColorSpace;
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 1.12;
    this.ambient = new THREE.HemisphereLight(0xe1f7ff, 0x56734d, 2.1);
    this.sun = new THREE.DirectionalLight(0xffedd2, 3.2);
    this.sun.position.set(100, 180, 60);
    this.sun.castShadow = true;
    this.sun.shadow.mapSize.set(2048, 2048);
    Object.assign(this.sun.shadow.camera, { left: -150, right: 150, top: 150, bottom: -150, far: 500 });
    this.sun.shadow.bias = -.001;
    this.scene.add(this.ambient, this.sun, this.sun.target);
    this.dynamic = new THREE.Group();
    this.scene.add(this.dynamic);
    this.keys = new Set();
    this.racers = [];
    this.pickups = [];
    this.hazards = []; this.coins = []; this.effects = [];
    this.mode = 'preview'; this.cameraMode = 'chase'; this.quality = 'high'; this.cameraShake = 0;
    this.dev = defaultDev();
    this.lastFrame = performance.now();
    this.clock = 0;
    this.keyDown = event => {
      if (/^(INPUT|TEXTAREA|SELECT)$/.test(event.target.tagName)) return;
      if (['ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight', 'Space'].includes(event.code)) event.preventDefault();
      if (event.repeat) return;
      this.keys.add(event.code);
      if ((event.code === 'KeyW' || event.code === 'ArrowUp') && this.countdownRemaining > 0) this.lastThrottleDown = Date.now();
      if (event.code === 'KeyE') this.useItem();
      if (event.code === 'KeyR') this.resetKart();
      if (event.code === 'Escape' && this.mode === 'race') this.callbacks.onPause?.();
      this.activateAudio();
    };
    this.keyUp = event => this.keys.delete(event.code);
    this.blur = () => { this.keys.clear(); if (this.mode === 'race' && !this.paused && !this.raceFinished) this.callbacks.onPause?.(); };
    window.addEventListener('keydown', this.keyDown);
    window.addEventListener('keyup', this.keyUp);
    window.addEventListener('blur', this.blur);
    this.resizeObserver = new ResizeObserver(() => this.resize());
    this.resizeObserver.observe(canvas.parentElement || canvas);
    this.resize();
    this.frame = this.frame.bind(this);
    this.animation = requestAnimationFrame(this.frame);
  }

  resize() {
    const { width, height } = this.canvas.getBoundingClientRect();
    const w = Math.max(1, width), h = Math.max(1, height);
    this.renderer.setSize(w, h, false);
    this.camera.aspect = w / h;
    this.viewportWidth = w; this.viewportHeight = h;
    this.applyCameraOffset();
    this.camera.updateProjectionMatrix();
  }

  applyCameraOffset() {
    const w = this.viewportWidth || 1, h = this.viewportHeight || 1;
    if (this.mode === 'preview' && w > 650) this.camera.setViewOffset(w, h, -w * .2, 0, w, h);
    else this.camera.clearViewOffset();
  }

  clearDynamic() {
    for (const child of [...this.dynamic.children]) {
      child.traverse(o => { if (o.geometry || o.material) { o.geometry?.dispose(); o.userData?.ownedTexture?.dispose(); if (Array.isArray(o.material)) o.material.forEach(m => m.dispose()); else o.material?.dispose(); } });
      this.dynamic.remove(child);
    }
    this.racers = []; this.pickups = []; this.hazards = []; this.coins = []; this.effects = [];
  }

  loadTrack(trackId) {
    if (this.world && this.trackId === trackId) return;
    this.world?.dispose();
    this.trackId = TRACKS.some(t => t.id === trackId) ? trackId : TRACKS[0].id;
    this.world = createWorld(this.scene, this.trackId);
    this.world.length ||= this.world.curve.getLength();
    this.world.halfWidth ||= 9;
    this.world.barrierLimit ||= this.world.halfWidth - .35;
    if (this.world.lighting) {
      const l = this.world.lighting;
      this.ambient?.color.set(l.sky); this.ambient?.groundColor.set(l.ground);
      if (this.ambient) this.ambient.intensity = l.ambientIntensity;
      this.sun?.color.set(l.sun); if (this.sun) this.sun.intensity = l.sunIntensity;
    }
    this.pathPoints = Array.from({ length: 100 }, (_, i) => this.point(i / 99));
    const xs = this.pathPoints.map(p => p.x), zs = this.pathPoints.map(p => p.z);
    this.mapBounds = { minX: Math.min(...xs), maxX: Math.max(...xs), minZ: Math.min(...zs), maxZ: Math.max(...zs) };
    this.trackPath = this.pathPoints.map(p => this.mapPoint(p));
  }

  point(t) { return this.world.getPoint ? this.world.getPoint(wrap(t)) : this.world.curve.getPointAt(wrap(t)); }
  tangent(t) { return this.world.getTangent ? this.world.getTangent(wrap(t)) : this.world.curve.getTangentAt(wrap(t)); }
  mapPoint(p) { const b = this.mapBounds; return { x: .08 + .84 * (p.x - b.minX) / (b.maxX - b.minX || 1), y: .08 + .84 * (p.z - b.minZ) / (b.maxZ - b.minZ || 1) }; }
  locate(t, lateral = 0, height = .28) {
    const p = this.point(t), direction = this.tangent(t);
    const right = new THREE.Vector3(direction.z, 0, -direction.x).normalize();
    return p.clone().addScaledVector(right, lateral).add(new THREE.Vector3(0, height, 0));
  }

  addRacer({ id, name, character, color, local = false, ai = false }, index) {
    const char = typeof character === 'string' ? { id: character } : character || {};
    const tint = color || char.color || colors[index % colors.length];
    const mesh = createKart(tint, char.id || 'rookie');
    this.dynamic.add(mesh);
    const r = { id: id || `bot-${index}`, name: name || botNames[index % botNames.length], character: char, mesh, color: tint, local, ai,
      distance: -.008 - Math.floor(index / 2) * .005, lateral: index % 2 ? 2.4 : -2.4, heading: 0, speed: 0,
      drift: 0, wasDrifting: false, steering: 0, boost: 0, nitro: 0, shield: 0, stun: 0, item: null, itemCooldown: 0, finished: false, finishTime: null, padCooldown: 0, aiSkill: .89 + Math.random() * .11, lastHit: 0, wallCooldown: 0, wallToast: 0, collisionSpark: 0, coins: 0, completedLaps: 0, lapStartedAt: 0, lapSplits: [], bestLap: null, lastLap: null };
    this.racers.push(r);
    this.placeKart(r, 0);
    if (local) this.player = r;
    return r;
  }

  preview(trackId = 'coast', character = {}) {
    this.mode = 'preview'; this.paused = false; this.keys.clear(); this.player = null;
    this.applyCameraOffset();
    this.clearDynamic(); this.loadTrack(trackId);
    const r = this.addRacer({ name: 'You', character, local: true }, 0);
    r.distance = .075; r.lateral = 0;
    this.placeKart(r, 0);
    this.previewStarted = this.clock;
    this.audioGain?.gain.setTargetAtTime(0, this.audioContext.currentTime, .1);
    this.callbacks.onCountdown?.(null);
    this.cameraReady = false;
  }

  start(options = {}) {
    this.clearDynamic(); this.loadTrack(options.trackId || 'coast');
    this.options = options; this.mode = 'race'; this.paused = false; this.keys.clear();
    this.applyCameraOffset();
    if (options.mode === 'online') this.dev = defaultDev();
    this.raceElapsed = 0; this.raceFinished = false; this.raceAssisted = this.hasDevAssistance(); this.lastHUD = 0; this.lastNetwork = 0; this.lastCountdown = null;
    this.lastThrottleDown = 0; this.cameraShake = 0;
    this.startAt = options.startAt || Date.now() + 3200;
    this.countdownRemaining = Math.max(0, (this.startAt - Date.now()) / 1000);
    this.difficulty = options.difficulty || 'rookie';
    if (options.mode === 'online') {
      const players = options.players || [];
      if (!players.length) players.push({ id: options.localId || 'local', name: options.name || 'Racer', character: options.character });
      for (const [i, p] of players.entries()) this.addRacer({ ...p, local: p.id === options.localId }, i);
      if (!this.racers.some(r => r.local)) this.racers[0].local = true;
      this.player = this.racers.find(r => r.local);
    } else {
      this.addRacer({ id: 'local', name: options.name || 'Racer', character: options.character, local: true }, 0);
      if (options.mode !== 'time') for (let i = 1; i < 8; i++) this.addRacer({ id: `bot-${i}`, name: botNames[i - 1], color: colors[i], ai: true }, i);
    }
    this.spawnPickups();
    this.cameraReady = false;
    this.activateAudio();
    this.sendHUD();
  }

  spawnPickups() {
    const cube = new THREE.BoxGeometry(1.25, 1.25, 1.25);
    for (const t of [.13, .36, .59, .81]) {
      for (const lateral of [-4.5, 0, 4.5]) {
        const material = new THREE.MeshStandardMaterial({ color: 0x6af3e3, emissive: 0x259b99, emissiveIntensity: .45, metalness: .25, roughness: .2 });
        const mesh = new THREE.Mesh(cube.clone(), material);
        mesh.position.copy(this.locate(t, lateral, 1.8));
        mesh.castShadow = true;
        const edge = new THREE.LineSegments(new THREE.EdgesGeometry(mesh.geometry), new THREE.LineBasicMaterial({ color: 0xffffff }));
        mesh.add(edge);
        const mark = new THREE.Mesh(new THREE.OctahedronGeometry(.32), new THREE.MeshStandardMaterial({ color: 0xffffff, emissive: 0xffffff, emissiveIntensity: .3 }));
        mesh.add(mark);
        this.dynamic.add(mesh); this.pickups.push({ t, lateral, mesh, cooldown: 0 });
      }
    }
    cube.dispose();
    this.boostPads = [.23, .49, .73, .93];
    for (const t of this.boostPads) {
      const mesh = new THREE.Mesh(new THREE.PlaneGeometry(5, 7), new THREE.MeshBasicMaterial({ color: this.trackId === 'neon' ? 0xff4eba : 0xffc65a, side: THREE.DoubleSide }));
      mesh.rotation.x = -Math.PI / 2;
      const tangent = this.tangent(t); mesh.rotation.z = -Math.atan2(tangent.x, tangent.z);
      mesh.position.copy(this.locate(t, 0, .1));
      this.dynamic.add(mesh);
      // Light stripes read clearly as a turbo lane from the chase camera.
      for (let i = 0; i < 3; i++) {
        const stripe = new THREE.Mesh(new THREE.PlaneGeometry(3.6, .36), new THREE.MeshBasicMaterial({ color: 0xfff4bc, side: THREE.DoubleSide }));
        stripe.position.set(0, -2 + i * 1.8, .02); mesh.add(stripe);
      }
    }
    this.spawnCoins();
  }

  spawnCoins() {
    this.coins = [];
    for (let i = 0; i < 12; i++) for (const lateral of [-4, 0, 4]) {
      const t = .055 + i * .075;
      const mesh = new THREE.Mesh(new THREE.CylinderGeometry(.65, .65, .18, 12), new THREE.MeshStandardMaterial({ color: 0xffcf48, emissive: 0xc47b00, emissiveIntensity: .3, metalness: .72, roughness: .27 }));
      mesh.position.copy(this.locate(t, lateral, 1.3)); mesh.rotation.x = Math.PI / 2;
      const inset = new THREE.Mesh(new THREE.TorusGeometry(.43, .055, 4, 12), new THREE.MeshBasicMaterial({ color: 0xfff2a1 }));
      inset.rotation.x = Math.PI / 2; inset.position.y = .1; mesh.add(inset);
      this.dynamic.add(mesh); this.coins.push({ t, lateral, mesh, collectedBy: new Set() });
    }
  }

  pause(value = true) {
    if (this.options?.mode === 'online') return false;
    if (value && !this.paused) this.pausedAt = Date.now();
    if (!value && this.paused && this.countdownRemaining > 0) this.startAt += Date.now() - this.pausedAt;
    this.paused = value; this.keys.clear(); return true;
  }
  hasDevAssistance() {
    const d = { ...defaultDev(), ...this.dev };
    return !!(d.infiniteBoost || d.invincible || d.freezeAI || d.infiniteItems || d.speedMultiplier !== 1 || d.timeScale !== 1);
  }

  setDev(settings = {}) {
    if (!settings || typeof settings !== 'object') return false;
    if (this.options?.mode === 'online') return false;
    const next = { ...defaultDev(), ...this.dev };
    for (const key of ['infiniteBoost', 'invincible', 'freezeAI', 'infiniteItems']) if (key in settings) next[key] = settings[key] === true;
    if ('speedMultiplier' in settings) next.speedMultiplier = clamp(finite(settings.speedMultiplier, 1), .5, 3);
    if ('timeScale' in settings) next.timeScale = clamp(finite(settings.timeScale, 1), .25, 2);
    this.dev = next;
    if (this.mode === 'race' && this.hasDevAssistance()) this.raceAssisted = true;
    return true;
  }

  devCommand(command, value) {
    if (this.options?.mode === 'online' || this.mode !== 'race' || !this.player || this.player.finished) return false;
    const p = this.player;
    if (command === 'grantItem' && Object.hasOwn(itemNames, value)) p.item = value;
    else if (command === 'recover') this.resetKart();
    else if (command === 'teleportCheckpoint' && Number.isInteger(Number(value)) && Number(value) >= 0 && Number(value) <= 3) {
      p.distance = Math.min(2.98, Math.floor(Math.max(0, p.distance)) + Number(value) * .25 + .02);
      Object.assign(p, { lateral: 0, heading: 0, steering: 0, speed: Math.min(p.speed, 15), drift: 0, wasDrifting: false });
      this.placeKart(p, 0); this.cameraReady = false;
    } else if (command === 'skipCountdown' && this.countdownRemaining > 0) {
      this.startAt = Date.now(); this.countdownRemaining = 0; this.goUntil = this.clock + .8;
      this.callbacks.onCountdown?.('GO!');
    } else if (command === 'finishRace') {
      this.raceAssisted = true; p.distance = 3; this.recordLapSplits(p); this.placeKart(p, 0); this.finishRacer(p);
    } else return false;
    this.raceAssisted = true; this.sendHUD(); return true;
  }

  setCamera(mode = 'chase') {
    if (!['chase', 'close', 'wide'].includes(mode)) return false;
    this.cameraMode = mode; this.cameraReady = false; return true;
  }

  setQuality(quality = 'high') {
    if (!['low', 'high'].includes(quality)) return false;
    this.quality = quality;
    if (this.renderer) {
      this.renderer.setPixelRatio(quality === 'low' ? 1 : Math.min(globalThis.devicePixelRatio || 1, 1.7));
      this.renderer.shadowMap.enabled = quality === 'high';
      this.resize();
    }
    return true;
  }

  setMuted(muted) { this.muted = muted; if (this.audioGain && muted) this.audioGain.gain.setTargetAtTime(0, this.audioContext.currentTime, .04); }
  resetKart() {
    if (this.mode !== 'race' || !this.player || this.player.finished) return;
    Object.assign(this.player, { lateral: 0, heading: 0, steering: 0, speed: Math.min(this.player.speed, 15), drift: 0, wasDrifting: false });
    this.enforceBarriers(this.player, false); this.placeKart(this.player, 0);
    this.callbacks.onToast?.('Back on track');
  }
  stop() { this.mode = 'preview'; this.keys.clear(); this.paused = false; this.audioGain?.gain.setTargetAtTime(0, this.audioContext.currentTime, .1); }

  useItem() {
    const p = this.player;
    if (this.mode !== 'race' || this.paused || this.countdownRemaining > 0 || !p?.item || p.finished || p.itemCooldown > 0) return;
    const type = p.item; if (!this.dev.infiniteItems) p.item = null; p.itemCooldown = .22;
    this.applyItem(p, type);
    this.callbacks.onItem?.({ type, target: p.lastTarget || null, progress: p.distance - (type === 'banana' ? .007 : 0), lateral: p.lateral });
    this.beep(type === 'nitro' ? 950 : type === 'turbo' ? 650 : 350, .12);
    this.sendHUD();
  }

  applyItem(racer, type, targetId, payload) {
    racer.lastTarget = null;
    if (type === 'turbo') { racer.boost = Math.max(racer.boost, 2.4); if (racer.local) this.callbacks.onToast?.('Turbo boost!'); }
    if (type === 'nitro') { racer.boost = Math.max(racer.boost, 4.2); racer.nitro = 4.2; if (racer.local) this.callbacks.onToast?.('MEGA NITRO · full power!'); }
    if (type === 'emp') {
      const progress = Number.isFinite(payload?.progress) ? payload.progress : racer.distance;
      this.addPulse(progress, racer.lateral);
      for (const target of this.racers) {
        if (target === racer || (!target.local && !target.ai) || target.finished) continue;
        const delta = Math.abs(wrap(target.distance) - wrap(progress));
        if (Math.min(delta, 1 - delta) * this.world.length < 65) this.hit(target, 'EMP pulse!');
      }
      if (racer.local) this.callbacks.onToast?.('EMP pulse · nearby rivals slowed');
    }
    if (type === 'shield') { racer.shield = 8; if (racer.local) this.callbacks.onToast?.('Shield active · 8 seconds'); }
    if (type === 'rocket') {
      const ahead = this.racers.filter(r => r !== racer && !r.finished && r.distance > racer.distance).sort((a, b) => a.distance - b.distance)[0];
      const target = targetId ? this.racers.find(r => r.id === targetId) : ahead;
      if (target) { racer.lastTarget = target.id; this.hit(target, 'Rocket hit!'); if (racer.local) this.callbacks.onToast?.(`Rocket → ${target.name}`); }
      else if (racer.local) this.callbacks.onToast?.('No target ahead');
    }
    if (type === 'banana') this.addHazard(racer.distance - .007, racer.lateral, racer.id);
  }

  addHazard(distance, lateral, ownerId) {
    const mesh = new THREE.Mesh(new THREE.TorusGeometry(.7, .22, 6, 8, Math.PI * 1.5), new THREE.MeshStandardMaterial({ color: 0xffdf3e, roughness: .8 }));
    mesh.rotation.x = -Math.PI / 2; mesh.position.copy(this.locate(distance, lateral, .4));
    this.dynamic.add(mesh); this.hazards.push({ distance, lateral, ownerId, mesh, life: 25 });
  }

  hit(racer, text) {
    if (racer.shield > 0) { racer.shield = 0; if (racer.local) this.callbacks.onToast?.('Shield blocked the hit'); return; }
    if (racer.local && this.dev.invincible) return;
    racer.stun = 1.4; racer.speed *= .35;
    if (racer.local) { this.cameraShake = .25; this.callbacks.onToast?.(text); }
  }

  setRemoteState(id, state) {
    const r = this.racers.find(r => r.id === id && !r.local);
    if (!r || !state || !Number.isFinite(state.progress)) return;
    r.targetDistance = clamp(state.progress, -.1, 3.2);
    r.targetLateral = clamp(finite(state.lateral), -this.barrierLimit(), this.barrierLimit());
    this.enforceBarriers(r, false);
    r.speed = clamp(Number(state.speed) || 0, 0, 90);
    r.heading = clamp(Number(state.heading) || 0, -1.1, 1.1);
    r.targetLateral = clamp(r.targetLateral, -this.barrierLimit(r), this.barrierLimit(r));
    this.enforceBarriers(r, false);
    r.boost = state.boost ? .15 : 0; r.nitro = state.nitro ? .15 : 0; r.shield = state.shield ? .15 : 0;
    if (state.finished && !r.finished) { r.finished = true; r.finishTime = Number(state.time) || this.raceElapsed; }
    r.lastNetworkAt = this.clock;
  }

  removeRemote(id) {
    const racer = this.racers.find(r => r.id === id && !r.local);
    if (!racer) return;
    this.racers = this.racers.filter(r => r !== racer);
    this.dynamic.remove(racer.mesh);
    racer.mesh.traverse(o => { o.geometry?.dispose(); o.userData?.ownedTexture?.dispose(); if (Array.isArray(o.material)) o.material.forEach(m => m.dispose()); else o.material?.dispose(); });
    this.sendHUD();
  }

  receiveItem(id, item) {
    const source = this.racers.find(r => r.id === id);
    if (!source || !item || !Object.hasOwn(itemNames, item.type)) return;
    if (item.type === 'rocket') {
      if (item.target === this.player?.id) this.hit(this.player, `Rocket from ${source.name}!`);
    } else if (item.type === 'banana') this.addHazard(Number(item.progress) || source.distance, clamp(Number(item.lateral) || 0, -this.barrierLimit(), this.barrierLimit()), id);
    else this.applyItem(source, item.type, undefined, item);
  }

  barrierLimit(racer) {
    const base = Math.max(2, finite(this.world?.barrierLimit, finite(this.world?.halfWidth, 9) - .35));
    if (!racer) return base;
    // A sideways kart needs more room than a straight kart. Reserve its rotated
    // nose, front-wheel steering, body roll, and slope pitch inside the rail.
    const heading = finite(racer.heading) + (racer.stun > 0 ? Math.sin(racer.stun * 13) * .24 : 0);
    const tangent = this.tangent(finite(racer.distance));
    const pitch = Math.atan2(tangent.y, Math.hypot(tangent.x, tangent.z));
    const halfLength = 2.35 + Math.abs(Math.sin(pitch)) * 3.6;
    const lateralSupport = Math.abs(Math.cos(heading)) * 1.65 + Math.abs(Math.sin(heading)) * halfLength
      + Math.abs(finite(racer.steering)) * .22 + Math.abs(finite(racer.heading)) * .12;
    return Math.max(2, base - Math.max(0, lateralSupport - 1.65));
  }

  enforceBarriers(r, feedback = true) {
    r.lateral = finite(r.lateral);
    r.heading = clamp(finite(r.heading), -1.1, 1.1);
    const limit = this.barrierLimit(r);
    if (Math.abs(r.lateral) < limit) return false;
    const side = Math.sign(r.lateral) || 1;
    const outward = r.heading * side > 0;
    const penetrated = Math.abs(r.lateral) > limit;
    const impact = outward ? Math.abs(Math.sin(r.heading)) : 0;
    r.lateral = side * limit;
    if (Number.isFinite(r.targetLateral)) r.targetLateral = clamp(r.targetLateral, -limit, limit);
    if (outward) r.heading = -side * .035;
    if (feedback && (penetrated || outward) && (!r.wallCooldown || r.wallCooldown <= 0)) {
      // Barriers remain physical even with invincibility and unlimited turbo.
      r.speed = Math.max(0, finite(r.speed) * (1 - clamp(.07 + impact * .62, .07, .68)));
      r.wallCooldown = .22; r.collisionSpark = .3; r.drift = 0; r.wasDrifting = false;
      if (r.local) {
        this.cameraShake = Math.max(this.cameraShake || 0, .12 + impact * .35);
        this.beep(105 + impact * 60, .09);
        if (!r.wallToast || r.wallToast <= 0) { this.callbacks.onToast?.('Barrier hit · ease into the corner'); r.wallToast = 2.2; }
      }
    }
    return penetrated || outward;
  }

  addPulse(progress, lateral) {
    const mesh = new THREE.Mesh(new THREE.RingGeometry(.91, 1, 40), new THREE.MeshBasicMaterial({ color: 0xa7a0ff, transparent: true, opacity: .65, side: THREE.DoubleSide, depthWrite: false }));
    mesh.rotation.x = -Math.PI / 2; mesh.position.copy(this.locate(progress, lateral, 1));
    this.dynamic.add(mesh); this.effects ||= []; this.effects.push({ mesh, age: 0, life: .7, radius: 65 });
  }

  recordLapSplits(r) {
    r.lapSplits ||= []; r.completedLaps ||= 0; r.lapStartedAt ||= 0;
    const completed = Math.min(3, Math.floor(Math.max(0, r.distance)));
    while (r.completedLaps < completed) {
      const split = Math.max(.001, this.raceElapsed - r.lapStartedAt);
      r.lapSplits.push(split); r.lastLap = split;
      r.bestLap = r.bestLap == null ? split : Math.min(r.bestLap, split);
      r.lapStartedAt = this.raceElapsed; r.completedLaps++;
      if (r.local && r.completedLaps < 3) {
        this.callbacks.onToast?.(`${r.completedLaps === 2 ? 'Final lap!' : 'Lap 2!'} · split ${split.toFixed(2)}s`);
        this.beep(r.completedLaps === 2 ? 950 : 750, .12);
      }
    }
  }

  updateCountdown(now = Date.now()) {
    if (this.countdownRemaining <= 0) return;
    this.countdownRemaining = Math.max(0, (this.startAt - now) / 1000);
    const value = this.countdownRemaining > 0 ? String(Math.min(3, Math.ceil(this.countdownRemaining))) : 'GO!';
    if (value !== this.lastCountdown) { this.callbacks.onCountdown?.(value); this.beep(value === 'GO!' ? 1000 : 500, .13); this.lastCountdown = value; }
    if (this.countdownRemaining === 0) {
      this.goUntil = this.clock + .8;
      const throttle = this.keys.has('KeyW') || this.keys.has('ArrowUp');
      if (throttle && this.lastThrottleDown >= this.startAt - 650 && this.lastThrottleDown <= this.startAt + 80) {
        this.player.boost = 1.8; this.player.speed = 13;
        this.callbacks.onToast?.('Perfect launch! + turbo');
      }
    }
  }

  tickRacer(r, dt) {
    // Bound the integrator as well as world positions, including debug speeds.
    dt = clamp(finite(dt), 0, .1);
    for (const key of ['boost', 'nitro', 'shield', 'stun', 'padCooldown', 'itemCooldown', 'wallCooldown', 'wallToast', 'collisionSpark']) r[key] = Math.max(0, finite(r[key]) - dt);
    this.enforceBarriers(r);
    if (r.finished) { r.speed *= Math.pow(.3, dt); this.placeKart(r, dt); return; }
    if (!r.local && !r.ai) {
      if (Number.isFinite(r.targetDistance)) {
        const extrapolate = this.clock - (r.lastNetworkAt ?? this.clock) < .35 ? r.speed * dt / this.world.length : 0;
        r.targetDistance = Math.min(3.2, r.targetDistance + extrapolate);
        r.distance = THREE.MathUtils.lerp(r.distance, r.targetDistance, 1 - Math.exp(-12 * dt));
        r.lateral = THREE.MathUtils.lerp(r.lateral, finite(r.targetLateral), 1 - Math.exp(-12 * dt));
      }
      this.enforceBarriers(r, false); this.placeKart(r, dt); return;
    }
    const oldDistance = r.distance;
    const current = this.tangent(r.distance), next = this.tangent(r.distance + .004);
    const angle = Math.atan2(next.x, next.z) - Math.atan2(current.x, current.z);
    const curveAngle = Math.atan2(Math.sin(angle), Math.cos(angle));
    if (r.ai) {
      if (this.dev.freezeAI && this.options?.mode !== 'online') { this.placeKart(r, dt); return; }
      const skill = this.difficulty === 'expert' ? 1.1 : this.difficulty === 'pro' ? 1 : .86;
      const cornerSpeed = 1 - Math.min(.26, Math.abs(curveAngle) * 1.3);
      const targetSpeed = (38 * skill * (r.aiSkill || .95) * cornerSpeed) + (r.boost > 0 ? (r.nitro > 0 ? 28 : 18) : 0);
      r.speed = THREE.MathUtils.lerp(r.speed, r.stun ? 10 : targetSpeed, 1 - Math.exp(-1.25 * dt));
      // Aim inside curves, move toward useful pickups, then offset around traffic.
      let lane = clamp(-curveAngle * 34, -3.4, 3.4) + Math.sin(r.distance * 16 + this.racers.indexOf(r) * 2.1) * 1.1;
      if (!r.item) {
        const upcoming = this.pickups.find(p => wrap(p.t - wrap(r.distance)) < .03 && p.cooldown <= 0);
        if (upcoming) lane = THREE.MathUtils.lerp(lane, upcoming.lateral, .65);
      }
      const traffic = this.racers.find(other => other !== r && other.distance > r.distance && (other.distance - r.distance) * this.world.length < 11 && Math.abs(other.lateral - lane) < 2.4);
      if (traffic) lane += lane > 0 ? -2.6 : 2.6;
      lane = clamp(lane, -this.barrierLimit() + 1, this.barrierLimit() - 1);
      const previousLateral = r.lateral;
      r.lateral = THREE.MathUtils.lerp(r.lateral, lane, 1 - Math.exp(-1.7 * dt));
      r.heading = clamp(Math.asin(clamp((r.lateral - previousLateral) / Math.max(.01, r.speed * dt), -.7, .7)), -.4, .4);
      r.steering = clamp(r.heading * 3, -1, 1);
      r.distance += r.speed * dt / this.world.length;
      if (Math.random() < dt * .035) r.boost = .85;
    } else {
      const throttle = this.keys.has('KeyW') || this.keys.has('ArrowUp');
      const brake = this.keys.has('KeyS') || this.keys.has('ArrowDown');
      // The forward-facing chase camera projects +yaw/+lateral to screen-left.
      const steer = (this.keys.has('KeyA') || this.keys.has('ArrowLeft') ? 1 : 0) + (this.keys.has('KeyD') || this.keys.has('ArrowRight') ? -1 : 0);
      r.steering = THREE.MathUtils.lerp(finite(r.steering), steer, 1 - Math.exp(-17 * dt));
      const drifting = this.keys.has('Space') && r.speed > 13 && steer !== 0 && !r.stun;
      const curbing = Math.abs(r.lateral) > this.world.halfWidth - .65;
      const boosted = r.boost > 0 || this.dev.infiniteBoost;
      const charSpeed = finite(r.character?.speed);
      const maxSpeed = (38 + (charSpeed > 10 ? charSpeed / 30 : charSpeed * .4) + (boosted ? (r.nitro > 0 ? 29 : 19) : 0)) * (this.dev.speedMultiplier || 1) * (curbing ? .88 : 1);
      const acceleration = throttle ? (boosted ? 30 : 17) : -7;
      r.speed = clamp(r.speed + (brake ? -31 : acceleration) * dt, 0, maxSpeed);
      if (r.stun) r.speed = Math.min(r.speed, 11);
      const curvatureRotation = curveAngle / .004 * r.speed / this.world.length * dt;
      const handling = finite(r.character?.handling, 3) / 20;
      r.heading += r.steering * (drifting ? 1.85 : 1.45 + handling) * Math.min(1, r.speed / 13) * dt;
      r.heading -= curvatureRotation * .63;
      r.heading *= Math.exp(-(steer ? (drifting ? .85 : 1.1) : 3.8) * dt);
      r.heading = clamp(r.heading, -1.03, 1.03);
      r.lateral += Math.sin(r.heading) * r.speed * dt * (drifting ? 1.11 : 1);
      r.distance += Math.max(0, Math.cos(r.heading)) * r.speed * dt / this.world.length;
      this.enforceBarriers(r);
      if (drifting && !curbing && !r.collisionSpark) r.drift = Math.min(1, r.drift + dt * .42);
      if (!drifting && r.wasDrifting) {
        if (r.drift > .2) {
          r.boost = Math.max(r.boost, .55 + r.drift * 2.4);
          this.callbacks.onToast?.(r.drift > .75 ? 'Perfect drift! + turbo' : 'Drift boost!');
          this.beep(400 + r.drift * 500, .15);
        }
        r.drift = 0;
      }
      r.wasDrifting = drifting && !r.collisionSpark;
      if (!drifting) r.drift = Math.max(0, r.drift - dt);
    }
    this.enforceBarriers(r);
    if (r.padCooldown <= 0 && Math.abs(r.lateral) < 3.4 && this.boostPads.some(t => this.crossed(oldDistance, r.distance, t))) {
      r.boost = Math.max(r.boost, 1.6); r.padCooldown = 1;
      if (r.local) this.callbacks.onToast?.('Boost pad!');
    }
    for (const p of this.pickups) {
      if (p.cooldown > 0 || r.item || Math.abs(r.lateral - p.lateral) > 2.1 || !this.crossed(oldDistance, r.distance, p.t)) continue;
      p.cooldown = 5;
      const items = ['turbo', 'turbo', 'rocket', 'shield', 'banana', 'emp', 'nitro'];
      r.item = items[Math.floor(Math.random() * items.length)];
      if (r.local) { this.callbacks.onToast?.(`${itemNames[r.item]} ready · Press E`); this.beep(900, .08); }
    }
    for (const coin of this.coins || []) {
      if (coin.collectedBy.has(r.id) || Math.abs(r.lateral - coin.lateral) > 1.65 || !this.crossed(oldDistance, r.distance, coin.t)) continue;
      coin.collectedBy.add(r.id); r.coins = finite(r.coins) + 1;
      if (r.local) { coin.mesh.visible = false; this.beep(1200 + (r.coins % 5) * 70, .045); }
    }
    for (const h of this.hazards) if (h.life > 0 && h.ownerId !== r.id && Math.abs(r.lateral - h.lateral) < 1.7 && this.crossed(oldDistance, r.distance, wrap(h.distance))) { this.hit(r, 'Banana spin!'); h.life = 0; }
    if (r.ai && r.item && Math.random() < dt * .3) { this.applyItem(r, r.item); r.item = null; }
    this.recordLapSplits(r);
    if (r.distance >= 3 && !r.finished) this.finishRacer(r);
    this.placeKart(r, dt);
  }

  crossed(from, to, t) { return Math.floor(to - t) > Math.floor(from - t); }

  placeKart(r, dt) {
    this.enforceBarriers(r, false);
    // Interpolate remote track coordinates, never world positions: interpolating
    // across a hairpin can cut through the outside rail even with a legal lane.
    const p = this.locate(r.distance, r.lateral, .25);
    r.mesh.position.copy(p);
    const dir = this.tangent(r.distance);
    r.mesh.rotation.order = 'YXZ';
    r.mesh.rotation.y = Math.atan2(dir.x, dir.z) + r.heading + (r.stun > 0 ? Math.sin(r.stun * 13) * .24 : 0);
    r.mesh.rotation.x = -Math.atan2(dir.y, Math.hypot(dir.x, dir.z));
    r.mesh.rotation.z = -r.heading * .065;
    const visual = r.mesh.userData || {};
    const steer = finite(r.steering, clamp(r.heading * 2, -1, 1));
    for (const wheel of visual.wheels || []) wheel.rotation.x += r.speed * dt / (visual.wheelRadius || .55);
    for (const pivot of visual.frontWheels || []) pivot.rotation.y = steer * .36;
    if (visual.steeringWheel) visual.steeringWheel.rotation.z = (visual.steeringWheel.userData.baseRotation?.z || 0) - steer * .52;
    if (visual.driver) visual.driver.rotation.z = (visual.driver.userData.baseRotation?.z || 0) - steer * .075;
    if (visual.helmet) visual.helmet.rotation.y = (visual.helmet.userData.baseRotation?.y || 0) + steer * .11;
    if (visual.body) {
      const base = visual.body.userData.basePosition;
      visual.body.position.y = (base?.y || 0) + Math.sin(this.clock * 21) * Math.min(r.speed / 850, .035);
      visual.body.rotation.z = (visual.body.userData.baseRotation?.z || 0) - steer * Math.min(r.speed / 650, .055);
    }
    if (r.shield > 0 && !r.shieldMesh) {
      r.shieldMesh = new THREE.Mesh(new THREE.SphereGeometry(2.1, 12, 8), new THREE.MeshBasicMaterial({ color: 0x5be5ff, transparent: true, opacity: .18, wireframe: true }));
      r.shieldMesh.position.y = 1; r.mesh.add(r.shieldMesh);
    }
    if (r.shieldMesh) { r.shieldMesh.visible = r.shield > 0; r.shieldMesh.rotation.y = this.clock; }
    if (!r.flame) {
      r.flame = visual.flame;
      if (!r.flame) {
        r.flame = new THREE.Mesh(new THREE.ConeGeometry(.45, 2.4, 5), new THREE.MeshBasicMaterial({ color: 0x56eaff }));
        r.flame.rotation.x = -Math.PI / 2; r.flame.position.set(0, .6, -2.2); r.mesh.add(r.flame);
      }
    }
    r.flame.visible = r.boost > 0 || (r.local && this.dev.infiniteBoost);
    r.flame.scale.setScalar((r.nitro > 0 ? 1.35 : 1) * (.85 + Math.sin(this.clock * 45) * .15));
    if (!r.sparks) {
      r.sparks = new THREE.Group();
      for (const x of [-1.5, 1.5]) { const s = new THREE.Mesh(new THREE.OctahedronGeometry(.3), new THREE.MeshBasicMaterial({ color: 0xffa43b })); s.position.set(x, .35, -.9); r.sparks.add(s); }
      r.mesh.add(r.sparks);
    }
    const impact = r.collisionSpark > 0;
    r.sparks.visible = impact || (r.wasDrifting && r.drift > .08);
    r.sparks.children.forEach(s => { s.rotation.x = this.clock * 15; s.material.color.set(impact ? '#fff1aa' : r.drift > .7 ? '#b88bff' : r.drift > .35 ? '#54ddff' : '#ffa43b'); s.scale.setScalar(impact ? 1.3 : .7 + r.drift); });
  }

  finishRacer(r) {
    this.recordLapSplits(r);
    r.finished = true; r.finishTime = this.raceElapsed;
    if (!r.local || this.raceFinished) return;
    this.raceFinished = true;
    const standings = this.standings();
    this.callbacks.onFinish?.({ position: standings.findIndex(s => s.isPlayer) + 1, totalRacers: this.racers.length, time: this.raceElapsed, trackId: this.trackId, mode: this.options.mode || 'solo', assisted: this.raceAssisted, coins: finite(r.coins), bestLap: r.bestLap, lastLap: r.lastLap, lapSplits: [...(r.lapSplits || [])], standings });
  }

  standings() {
    return [...this.racers].sort((a, b) => a.finished && b.finished ? a.finishTime - b.finishTime : a.finished ? -1 : b.finished ? 1 : b.distance - a.distance).map((r, i) => ({ id: r.id, name: r.name, position: i + 1, isPlayer: r.local, progress: r.distance, finished: r.finished, time: r.finishTime, color: r.color }));
  }

  sendHUD() {
    const p = this.player; if (!p || !this.world) return;
    const standings = this.standings();
    this.callbacks.onHUD?.({ speed: Math.round(p.speed * 3.6), lap: Math.min(3, Math.floor(Math.max(0, p.distance)) + 1), totalLaps: 3,
      position: standings.findIndex(r => r.isPlayer) + 1, totalRacers: this.racers.length, time: p.finishTime ?? this.raceElapsed ?? 0, item: p.item,
      drift: p.drift, boost: clamp(p.boost / 3, 0, 1), shield: p.shield, nitro: p.nitro > 0, standings, progress: p.distance, coins: finite(p.coins), bestLap: p.bestLap, lastLap: p.lastLap, currentLapTime: p.finished ? p.lastLap : (this.raceElapsed || 0) - (p.lapStartedAt || 0), lapSplits: [...(p.lapSplits || [])],
      telemetry: { lateral: p.lateral, heading: p.heading, x: p.mesh.position.x, y: p.mesh.position.y, z: p.mesh.position.z },
      minimap: this.racers.map(r => ({ ...this.mapPoint(this.point(r.distance)), isPlayer: r.local, color: r.color })), trackPath: this.trackPath });
  }

  updateCamera(dt) {
    if (!this.player || !this.world) return;
    const p = this.player;
    let desired, target;
    if (this.mode === 'preview') {
      const t = .075, pos = this.locate(t, 0, .4), dir = this.tangent(t);
      const right = new THREE.Vector3(dir.z, 0, -dir.x).normalize();
      const phase = Math.sin((this.clock - this.previewStarted) * .08) * .22;
      desired = pos.clone().addScaledVector(right, 26 + phase * 10).addScaledVector(dir, -34).add(new THREE.Vector3(0, 22, 0));
      target = pos.clone().addScaledVector(dir, 20).add(new THREE.Vector3(0, 1, 0));
      this.camera.fov = 52;
    } else {
      const dir = this.tangent(p.distance);
      const cameraStyle = { chase: { distance: 13, height: 7.5, fov: 57 }, close: { distance: 8.5, height: 5, fov: 62 }, wide: { distance: 18, height: 10, fov: 62 } }[this.cameraMode || 'chase'];
      desired = p.mesh.position.clone().addScaledVector(dir, -(cameraStyle.distance + p.speed * .1)).add(new THREE.Vector3(0, cameraStyle.height, 0));
      target = this.locate(p.distance + .013, p.lateral * .6, 2.1);
      this.camera.fov = THREE.MathUtils.lerp(this.camera.fov, cameraStyle.fov + (p.boost > 0 ? 9 : 0), 1 - Math.exp(-3 * dt));
    }
    if (!this.cameraReady) { this.camera.position.copy(desired); this.cameraTarget = target.clone(); this.cameraReady = true; }
    else { this.camera.position.lerp(desired, 1 - Math.exp(-5 * dt)); this.cameraTarget.lerp(target, 1 - Math.exp(-7 * dt)); }
    if (this.mode === 'race' && this.cameraShake > 0) {
      this.camera.position.x += Math.sin(this.clock * 76) * this.cameraShake * .4;
      this.camera.position.y += Math.cos(this.clock * 63) * this.cameraShake * .3;
      this.cameraShake = Math.max(0, this.cameraShake - dt * 1.7);
    }
    this.camera.lookAt(this.cameraTarget);
    this.camera.updateProjectionMatrix();
    this.sun.position.set(p.mesh.position.x + 80, p.mesh.position.y + 150, p.mesh.position.z + 55);
    this.sun.target.position.copy(p.mesh.position);
  }

  frame(now) {
    this.animation = requestAnimationFrame(this.frame);
    const dt = Math.min(.04, Math.max(0, (now - this.lastFrame) / 1000));
    this.lastFrame = now; this.clock += dt;
    this.world?.update?.(this.clock);
    if (this.mode === 'race' && !this.paused) {
      const simulationDt = dt * (this.options?.mode === 'online' ? 1 : (this.dev.timeScale || 1));
      if (this.countdownRemaining > 0) this.updateCountdown();
      else {
        if (this.goUntil && this.clock > this.goUntil) { this.callbacks.onCountdown?.(null); this.goUntil = 0; }
        this.raceElapsed += simulationDt;
        for (const r of this.racers) this.tickRacer(r, simulationDt);
        // Resolve contact inside the same barrier constraint as steering.
        for (const r of this.racers) if (r !== this.player && Math.abs(r.distance - this.player.distance) * this.world.length < 2.5 && Math.abs(r.lateral - this.player.lateral) < 1.8) {
          this.player.lateral += Math.sign(this.player.lateral - r.lateral || 1) * simulationDt * 3.5;
          this.player.speed *= Math.pow(.85, simulationDt);
        }
        this.enforceBarriers(this.player); this.placeKart(this.player, 0);
      }
      if (this.clock - this.lastHUD > .07) { this.sendHUD(); this.lastHUD = this.clock; }
      if (this.clock - this.lastNetwork > .065 && this.player) {
        const p = this.player;
        this.callbacks.onState?.({ progress: p.distance, lateral: p.lateral, speed: p.speed, heading: p.heading, boost: p.boost > 0, shield: p.shield > 0, nitro: p.nitro > 0, finished: p.finished, time: p.finishTime ?? this.raceElapsed });
        this.lastNetwork = this.clock;
      }
    }
    for (const p of this.pickups) { if (!this.paused) p.cooldown = Math.max(0, p.cooldown - dt); p.mesh.visible = p.cooldown === 0; p.mesh.rotation.set(this.clock * .6, this.clock, Math.PI / 4); p.mesh.material.color.setHSL((this.clock * .12 + p.t) % 1, .72, .66); }
    for (let i = this.hazards.length - 1; i >= 0; i--) { const h = this.hazards[i]; if (!this.paused) h.life -= dt; if (h.life <= 0) { this.dynamic.remove(h.mesh); h.mesh.geometry.dispose(); h.mesh.material.dispose(); this.hazards.splice(i, 1); } }
    for (const coin of this.coins) { coin.mesh.rotation.z = this.clock * 2; coin.mesh.position.y = this.point(coin.t).y + 1.35 + Math.sin(this.clock * 3 + coin.t * 20) * .16; }
    for (let i = this.effects.length - 1; i >= 0; i--) {
      const effect = this.effects[i]; effect.age += dt; const phase = Math.min(1, effect.age / effect.life);
      effect.mesh.scale.setScalar(1 + phase * effect.radius); effect.mesh.material.opacity = .65 * (1 - phase);
      if (phase >= 1) { effect.mesh.removeFromParent(); effect.mesh.geometry.dispose(); effect.mesh.material.dispose(); this.effects.splice(i, 1); }
    }
    this.updateCamera(dt);
    if (this.audioContext && this.engineOsc) {
      this.engineOsc.frequency.setTargetAtTime(45 + (this.player?.speed || 0) * 3, this.audioContext.currentTime, .08);
      this.audioGain.gain.setTargetAtTime(this.muted || this.mode !== 'race' || this.paused || this.countdownRemaining > 0 ? 0 : .018, this.audioContext.currentTime, .08);
    }
    this.renderer.render(this.scene, this.camera);
  }

  activateAudio() {
    if (!this.audioContext) {
      try {
        const Audio = window.AudioContext || window.webkitAudioContext;
        if (!Audio) return;
        this.audioContext = new Audio();
        this.audioGain = this.audioContext.createGain(); this.audioGain.gain.value = 0;
        this.engineOsc = this.audioContext.createOscillator(); this.engineOsc.type = 'sawtooth';
        const filter = this.audioContext.createBiquadFilter(); filter.type = 'lowpass'; filter.frequency.value = 350;
        this.engineOsc.connect(filter); filter.connect(this.audioGain); this.audioGain.connect(this.audioContext.destination); this.engineOsc.start();
      } catch { return; }
    }
    if (this.audioContext.state === 'suspended') this.audioContext.resume().catch(() => {});
  }

  beep(frequency, duration) {
    if (!this.audioContext || this.muted) return;
    const oscillator = this.audioContext.createOscillator(), gain = this.audioContext.createGain();
    oscillator.type = 'sine'; oscillator.frequency.value = frequency;
    gain.gain.setValueAtTime(.07, this.audioContext.currentTime); gain.gain.exponentialRampToValueAtTime(.001, this.audioContext.currentTime + duration);
    oscillator.connect(gain); gain.connect(this.audioContext.destination); oscillator.start(); oscillator.stop(this.audioContext.currentTime + duration);
  }

  dispose() {
    cancelAnimationFrame(this.animation);
    window.removeEventListener('keydown', this.keyDown); window.removeEventListener('keyup', this.keyUp); window.removeEventListener('blur', this.blur);
    this.resizeObserver.disconnect(); this.clearDynamic(); this.world?.dispose(); this.renderer.dispose();
    this.audioContext?.close();
  }
}
