import * as THREE from 'three';
import { createWorld, createKart, TRACKS } from './world.js';

const clamp = THREE.MathUtils.clamp;
const wrap = n => ((n % 1) + 1) % 1;
const colors = ['#ff713f', '#48c6c1', '#ad83eb', '#ffd05b', '#8cd26b', '#f77eac', '#7ba7ff', '#f1f0d9'];
const botNames = ['Coco', 'Bolt', 'Mochi', 'Dash', 'Orbit', 'Sunny', 'Rocco'];
const itemNames = { turbo: 'TURBO', rocket: 'ROCKET', shield: 'SHIELD', banana: 'BANANA' };

export class KartGame {
  constructor(canvas, callbacks = {}) {
    this.canvas = canvas;
    this.callbacks = callbacks;
    this.scene = new THREE.Scene();
    this.scene.background = new THREE.Color('#abdfe9');
    this.camera = new THREE.PerspectiveCamera(55, 1, .2, 1600);
    this.renderer = new THREE.WebGLRenderer({ canvas, antialias: true, alpha: false, powerPreference: 'high-performance' });
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 1.7));
    this.renderer.shadowMap.enabled = true;
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    this.renderer.outputColorSpace = THREE.SRGBColorSpace;
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 1.12;
    this.ambient = new THREE.HemisphereLight(0xe1f7ff, 0x56734d, 2.1);
    this.sun = new THREE.DirectionalLight(0xffedd2, 3.2);
    this.sun.position.set(100, 180, 60);
    this.sun.castShadow = true;
    this.sun.shadow.mapSize.set(2048, 2048);
    Object.assign(this.sun.shadow.camera, { left: -150, right: 150, top: 150, bottom: -150, far: 500 });
    this.sun.shadow.bias = -.001;
    this.scene.add(this.ambient, this.sun, this.sun.target);
    this.dynamic = new THREE.Group();
    this.scene.add(this.dynamic);
    this.keys = new Set();
    this.racers = [];
    this.pickups = [];
    this.hazards = [];
    this.mode = 'preview';
    this.dev = { infiniteBoost: false, invincible: false, speedMultiplier: 1 };
    this.lastFrame = performance.now();
    this.clock = 0;
    this.keyDown = event => {
      if (/^(INPUT|TEXTAREA|SELECT)$/.test(event.target.tagName)) return;
      if (['ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight', 'Space'].includes(event.code)) event.preventDefault();
      if (event.repeat) return;
      this.keys.add(event.code);
      if (event.code === 'KeyE') this.useItem();
      if (event.code === 'KeyR') this.resetKart();
      if (event.code === 'Escape' && this.mode === 'race') this.callbacks.onPause?.();
      this.activateAudio();
    };
    this.keyUp = event => this.keys.delete(event.code);
    this.blur = () => { this.keys.clear(); if (this.mode === 'race') this.callbacks.onPause?.(); };
    window.addEventListener('keydown', this.keyDown);
    window.addEventListener('keyup', this.keyUp);
    window.addEventListener('blur', this.blur);
    this.resizeObserver = new ResizeObserver(() => this.resize());
    this.resizeObserver.observe(canvas.parentElement || canvas);
    this.resize();
    this.frame = this.frame.bind(this);
    this.animation = requestAnimationFrame(this.frame);
  }

  resize() {
    const { width, height } = this.canvas.getBoundingClientRect();
    const w = Math.max(1, width), h = Math.max(1, height);
    this.renderer.setSize(w, h, false);
    this.camera.aspect = w / h;
    this.viewportWidth = w; this.viewportHeight = h;
    this.applyCameraOffset();
    this.camera.updateProjectionMatrix();
  }

  applyCameraOffset() {
    const w = this.viewportWidth || 1, h = this.viewportHeight || 1;
    if (this.mode === 'preview' && w > 650) this.camera.setViewOffset(w, h, -w * .2, 0, w, h);
    else this.camera.clearViewOffset();
  }

  clearDynamic() {
    for (const child of [...this.dynamic.children]) {
      child.traverse(o => { if (o.geometry || o.material) { o.geometry?.dispose(); if (Array.isArray(o.material)) o.material.forEach(m => m.dispose()); else o.material?.dispose(); } });
      this.dynamic.remove(child);
    }
    this.racers = []; this.pickups = []; this.hazards = [];
  }

  loadTrack(trackId) {
    if (this.world && this.trackId === trackId) return;
    this.world?.dispose();
    this.trackId = TRACKS.some(t => t.id === trackId) ? trackId : TRACKS[0].id;
    this.world = createWorld(this.scene, this.trackId);
    this.world.length ||= this.world.curve.getLength();
    this.world.halfWidth ||= 9;
    this.pathPoints = Array.from({ length: 100 }, (_, i) => this.point(i / 99));
    const xs = this.pathPoints.map(p => p.x), zs = this.pathPoints.map(p => p.z);
    this.mapBounds = { minX: Math.min(...xs), maxX: Math.max(...xs), minZ: Math.min(...zs), maxZ: Math.max(...zs) };
    this.trackPath = this.pathPoints.map(p => this.mapPoint(p));
  }

  point(t) { return this.world.getPoint ? this.world.getPoint(wrap(t)) : this.world.curve.getPointAt(wrap(t)); }
  tangent(t) { return this.world.getTangent ? this.world.getTangent(wrap(t)) : this.world.curve.getTangentAt(wrap(t)); }
  mapPoint(p) { const b = this.mapBounds; return { x: .08 + .84 * (p.x - b.minX) / (b.maxX - b.minX || 1), y: .08 + .84 * (p.z - b.minZ) / (b.maxZ - b.minZ || 1) }; }
  locate(t, lateral = 0, height = .28) {
    const p = this.point(t), direction = this.tangent(t);
    const right = new THREE.Vector3(direction.z, 0, -direction.x).normalize();
    return p.clone().addScaledVector(right, lateral).add(new THREE.Vector3(0, height, 0));
  }

  addRacer({ id, name, character, color, local = false, ai = false }, index) {
    const char = typeof character === 'string' ? { id: character } : character || {};
    const tint = color || char.color || colors[index % colors.length];
    const mesh = createKart(tint, char.id || 'rookie');
    this.dynamic.add(mesh);
    const r = { id: id || `bot-${index}`, name: name || botNames[index % botNames.length], character: char, mesh, color: tint, local, ai,
      distance: -.008 - Math.floor(index / 2) * .005, lateral: index % 2 ? 2.4 : -2.4, heading: 0, speed: 0,
      drift: 0, wasDrifting: false, boost: 0, shield: 0, stun: 0, item: null, finished: false, finishTime: null, padCooldown: 0, aiSkill: .89 + Math.random() * .11, lastHit: 0 };
    this.racers.push(r);
    this.placeKart(r, 0);
    if (local) this.player = r;
    return r;
  }

  preview(trackId = 'coast', character = {}) {
    this.mode = 'preview'; this.paused = false; this.keys.clear(); this.player = null;
    this.applyCameraOffset();
    this.clearDynamic(); this.loadTrack(trackId);
    const r = this.addRacer({ name: 'You', character, local: true }, 0);
    r.distance = .075; r.lateral = 0;
    this.placeKart(r, 0);
    this.previewStarted = this.clock;
    this.audioGain?.gain.setTargetAtTime(0, this.audioContext.currentTime, .1);
    this.callbacks.onCountdown?.(null);
    this.cameraReady = false;
  }

  start(options = {}) {
    this.clearDynamic(); this.loadTrack(options.trackId || 'coast');
    this.options = options; this.mode = 'race'; this.paused = false; this.keys.clear();
    this.applyCameraOffset();
    if (options.mode === 'online') this.dev = { infiniteBoost: false, invincible: false, speedMultiplier: 1 };
    this.raceElapsed = 0; this.raceFinished = false; this.raceAssisted = false; this.lastHUD = 0; this.lastNetwork = 0; this.lastCountdown = null;
    this.startAt = options.startAt || Date.now() + 3200;
    this.countdownRemaining = Math.max(0, (this.startAt - Date.now()) / 1000);
    this.difficulty = options.difficulty || 'rookie';
    if (options.mode === 'online') {
      const players = options.players || [];
      if (!players.length) players.push({ id: options.localId || 'local', name: options.name || 'Racer', character: options.character });
      for (const [i, p] of players.entries()) this.addRacer({ ...p, local: p.id === options.localId }, i);
      if (!this.racers.some(r => r.local)) this.racers[0].local = true;
      this.player = this.racers.find(r => r.local);
    } else {
      this.addRacer({ id: 'local', name: options.name || 'Racer', character: options.character, local: true }, 0);
      if (options.mode !== 'time') for (let i = 1; i < 8; i++) this.addRacer({ id: `bot-${i}`, name: botNames[i - 1], color: colors[i], ai: true }, i);
    }
    this.spawnPickups();
    this.cameraReady = false;
    this.activateAudio();
    this.sendHUD();
  }

  spawnPickups() {
    const cube = new THREE.BoxGeometry(1.25, 1.25, 1.25);
    for (const t of [.13, .36, .59, .81]) {
      for (const lateral of [-4.5, 0, 4.5]) {
        const material = new THREE.MeshStandardMaterial({ color: 0x6af3e3, emissive: 0x259b99, emissiveIntensity: .45, metalness: .25, roughness: .2 });
        const mesh = new THREE.Mesh(cube.clone(), material);
        mesh.position.copy(this.locate(t, lateral, 1.8));
        mesh.castShadow = true;
        const edge = new THREE.LineSegments(new THREE.EdgesGeometry(mesh.geometry), new THREE.LineBasicMaterial({ color: 0xffffff }));
        mesh.add(edge);
        const mark = new THREE.Mesh(new THREE.OctahedronGeometry(.32), new THREE.MeshStandardMaterial({ color: 0xffffff, emissive: 0xffffff, emissiveIntensity: .3 }));
        mesh.add(mark);
        this.dynamic.add(mesh); this.pickups.push({ t, lateral, mesh, cooldown: 0 });
      }
    }
    cube.dispose();
    this.boostPads = [.23, .49, .73, .93];
    for (const t of this.boostPads) {
      const mesh = new THREE.Mesh(new THREE.PlaneGeometry(5, 7), new THREE.MeshBasicMaterial({ color: this.trackId === 'neon' ? 0xff4eba : 0xffc65a, side: THREE.DoubleSide }));
      mesh.rotation.x = -Math.PI / 2;
      const tangent = this.tangent(t); mesh.rotation.z = -Math.atan2(tangent.x, tangent.z);
      mesh.position.copy(this.locate(t, 0, .1));
      this.dynamic.add(mesh);
      // Light stripes read clearly as a turbo lane from the chase camera.
      for (let i = 0; i < 3; i++) {
        const stripe = new THREE.Mesh(new THREE.PlaneGeometry(3.6, .36), new THREE.MeshBasicMaterial({ color: 0xfff4bc, side: THREE.DoubleSide }));
        stripe.position.set(0, -2 + i * 1.8, .02); mesh.add(stripe);
      }
    }
  }

  pause(value = true) {
    if (this.options?.mode === 'online') return false;
    if (value && !this.paused) this.pausedAt = Date.now();
    if (!value && this.paused && this.countdownRemaining > 0) this.startAt += Date.now() - this.pausedAt;
    this.paused = value; this.keys.clear(); return true;
  }
  setDev(settings) { if (this.options?.mode !== 'online') { Object.assign(this.dev, settings); if (this.mode === 'race' && (this.dev.infiniteBoost || this.dev.invincible || this.dev.speedMultiplier !== 1)) this.raceAssisted = true; } }
  setMuted(muted) { this.muted = muted; if (this.audioGain && muted) this.audioGain.gain.setTargetAtTime(0, this.audioContext.currentTime, .04); }
  resetKart() { if (this.mode !== 'race' || !this.player || this.player.finished) return; Object.assign(this.player, { lateral: 0, heading: 0, speed: Math.min(this.player.speed, 15), drift: 0 }); this.callbacks.onToast?.('Back on track'); }
  stop() { this.mode = 'preview'; this.keys.clear(); this.paused = false; this.audioGain?.gain.setTargetAtTime(0, this.audioContext.currentTime, .1); }

  useItem() {
    const p = this.player;
    if (this.mode !== 'race' || this.paused || this.countdownRemaining > 0 || !p?.item || p.finished) return;
    const type = p.item; p.item = null;
    this.applyItem(p, type);
    this.callbacks.onItem?.({ type, target: p.lastTarget || null, progress: p.distance - (type === 'banana' ? .007 : 0), lateral: p.lateral });
    this.beep(type === 'turbo' ? 650 : 350, .12);
    this.sendHUD();
  }

  applyItem(racer, type, targetId) {
    racer.lastTarget = null;
    if (type === 'turbo') { racer.boost = Math.max(racer.boost, 2.4); if (racer.local) this.callbacks.onToast?.('Turbo boost!'); }
    if (type === 'shield') { racer.shield = 8; if (racer.local) this.callbacks.onToast?.('Shield active · 8 seconds'); }
    if (type === 'rocket') {
      const ahead = this.racers.filter(r => r !== racer && !r.finished && r.distance > racer.distance).sort((a, b) => a.distance - b.distance)[0];
      const target = targetId ? this.racers.find(r => r.id === targetId) : ahead;
      if (target) { racer.lastTarget = target.id; this.hit(target, 'Rocket hit!'); if (racer.local) this.callbacks.onToast?.(`Rocket → ${target.name}`); }
      else if (racer.local) this.callbacks.onToast?.('No target ahead');
    }
    if (type === 'banana') this.addHazard(racer.distance - .007, racer.lateral, racer.id);
  }

  addHazard(distance, lateral, ownerId) {
    const mesh = new THREE.Mesh(new THREE.TorusGeometry(.7, .22, 6, 8, Math.PI * 1.5), new THREE.MeshStandardMaterial({ color: 0xffdf3e, roughness: .8 }));
    mesh.rotation.x = -Math.PI / 2; mesh.position.copy(this.locate(distance, lateral, .4));
    this.dynamic.add(mesh); this.hazards.push({ distance, lateral, ownerId, mesh, life: 25 });
  }

  hit(racer, text) {
    if (racer.shield > 0) { racer.shield = 0; if (racer.local) this.callbacks.onToast?.('Shield blocked the hit'); return; }
    if (racer.local && this.dev.invincible) return;
    racer.stun = 1.4; racer.speed *= .35;
    if (racer.local) this.callbacks.onToast?.(text);
  }

  setRemoteState(id, state) {
    const r = this.racers.find(r => r.id === id && !r.local);
    if (!r || !state || !Number.isFinite(state.progress)) return;
    r.targetDistance = clamp(state.progress, -.1, 3.2);
    r.targetLateral = clamp(Number(state.lateral) || 0, -this.world.halfWidth * 1.8, this.world.halfWidth * 1.8);
    r.speed = clamp(Number(state.speed) || 0, 0, 90);
    r.heading = clamp(Number(state.heading) || 0, -1.3, 1.3);
    r.boost = state.boost ? .15 : 0; r.shield = state.shield ? .15 : 0;
    if (state.finished && !r.finished) { r.finished = true; r.finishTime = Number(state.time) || this.raceElapsed; }
    r.lastNetworkAt = this.clock;
  }

  removeRemote(id) {
    const racer = this.racers.find(r => r.id === id && !r.local);
    if (!racer) return;
    this.racers = this.racers.filter(r => r !== racer);
    this.dynamic.remove(racer.mesh);
    racer.mesh.traverse(o => { o.geometry?.dispose(); if (Array.isArray(o.material)) o.material.forEach(m => m.dispose()); else o.material?.dispose(); });
    this.sendHUD();
  }

  receiveItem(id, item) {
    const source = this.racers.find(r => r.id === id);
    if (!source || !item || !itemNames[item.type]) return;
    if (item.type === 'rocket') {
      if (item.target === this.player?.id) this.hit(this.player, `Rocket from ${source.name}!`);
    } else if (item.type === 'banana') this.addHazard(Number(item.progress) || source.distance, clamp(Number(item.lateral) || 0, -12, 12), id);
    else this.applyItem(source, item.type);
  }

  tickRacer(r, dt) {
    r.boost = Math.max(0, r.boost - dt); r.shield = Math.max(0, r.shield - dt); r.stun = Math.max(0, r.stun - dt); r.padCooldown = Math.max(0, r.padCooldown - dt);
    if (r.finished) { r.speed *= Math.pow(.3, dt); this.placeKart(r, dt); return; }
    if (!r.local && !r.ai) {
      if (Number.isFinite(r.targetDistance)) {
        const extrapolate = this.clock - (r.lastNetworkAt || this.clock) < .35 ? r.speed * dt / this.world.length : 0;
        r.targetDistance += extrapolate;
        r.distance = THREE.MathUtils.lerp(r.distance, r.targetDistance, 1 - Math.exp(-12 * dt));
        r.lateral = THREE.MathUtils.lerp(r.lateral, r.targetLateral, 1 - Math.exp(-12 * dt));
      }
      this.placeKart(r, dt); return;
    }
    const oldDistance = r.distance;
    if (r.ai) {
      const skill = this.difficulty === 'expert' ? 1.09 : this.difficulty === 'pro' ? .98 : .85;
      const targetSpeed = (37 * skill * r.aiSkill) + (r.boost > 0 ? 17 : 0);
      r.speed = THREE.MathUtils.lerp(r.speed, r.stun ? 10 : targetSpeed, 1 - Math.exp(-.8 * dt));
      r.lateral = Math.sin(this.clock * .8 + this.racers.indexOf(r) * 2.1) * 3.5;
      r.heading = Math.sin(this.clock + this.racers.indexOf(r)) * .02;
      r.distance += r.speed * dt / this.world.length;
      if (Math.random() < dt * .05) { r.boost = .8; if (Math.random() > .5) this.applyItem(r, 'banana'); }
    } else {
      const throttle = this.keys.has('KeyW') || this.keys.has('ArrowUp');
      const brake = this.keys.has('KeyS') || this.keys.has('ArrowDown');
      const steer = (this.keys.has('KeyA') || this.keys.has('ArrowLeft') ? -1 : 0) + (this.keys.has('KeyD') || this.keys.has('ArrowRight') ? 1 : 0);
      const drifting = this.keys.has('Space') && r.speed > 13 && steer !== 0 && !r.stun;
      const offroad = Math.abs(r.lateral) > this.world.halfWidth - .5;
      const boosted = r.boost > 0 || this.dev.infiniteBoost;
      const charSpeed = Number(r.character.speed) || 0;
      const maxSpeed = (37 + (charSpeed > 10 ? charSpeed / 30 : charSpeed * .4) + (boosted ? 19 : 0)) * (this.dev.speedMultiplier || 1) * (offroad ? .53 : 1);
      const acceleration = throttle ? (boosted ? 27 : 16) : -7;
      r.speed = clamp(r.speed + (brake ? -29 : acceleration) * dt, 0, maxSpeed);
      if (r.stun) r.speed = Math.min(r.speed, 11);
      const current = this.tangent(r.distance), next = this.tangent(r.distance + .001);
      let curveAngle = Math.atan2(next.x, next.z) - Math.atan2(current.x, current.z);
      curveAngle = Math.atan2(Math.sin(curveAngle), Math.cos(curveAngle));
      const curvatureRotation = curveAngle / .001 * r.speed / this.world.length * dt;
      const handling = (Number(r.character.handling) || 3) / 20;
      r.heading += steer * (drifting ? 1.95 : 1.55 + handling) * Math.min(1, r.speed / 13) * dt;
      r.heading -= curvatureRotation * .68;
      r.heading *= Math.exp(-(steer ? .9 : 3.4) * dt);
      r.heading = clamp(r.heading, -1.03, 1.03);
      r.lateral += Math.sin(r.heading) * r.speed * dt * (drifting ? 1.13 : 1);
      r.distance += Math.max(0, Math.cos(r.heading)) * r.speed * dt / this.world.length;
      if (Math.abs(r.lateral) > this.world.halfWidth + 5) { r.lateral = Math.sign(r.lateral) * (this.world.halfWidth + 5); r.heading *= .65; r.speed *= Math.pow(.2, dt); }
      if (drifting && !offroad) { r.drift = Math.min(1, r.drift + dt * .37); }
      if (!drifting && r.wasDrifting) {
        if (r.drift > .22) {
          r.boost = Math.max(r.boost, .45 + r.drift * 2.4);
          this.callbacks.onToast?.(r.drift > .75 ? 'Perfect drift! + turbo' : 'Drift boost!');
          this.beep(400 + r.drift * 500, .15);
        }
        r.drift = 0;
      }
      r.wasDrifting = drifting;
      if (!drifting) r.drift = Math.max(0, r.drift - dt);
    }
    if (r.padCooldown <= 0 && Math.abs(r.lateral) < 3.4 && this.boostPads.some(t => this.crossed(oldDistance, r.distance, t))) {
      r.boost = Math.max(r.boost, 1.6); r.padCooldown = 1;
      if (r.local) this.callbacks.onToast?.('Boost pad!');
    }
    for (const p of this.pickups) {
      if (p.cooldown > 0 || r.item || Math.abs(r.lateral - p.lateral) > 2.1 || !this.crossed(oldDistance, r.distance, p.t)) continue;
      p.cooldown = 5;
      const items = ['turbo', 'turbo', 'rocket', 'shield', 'banana'];
      r.item = items[Math.floor(Math.random() * items.length)];
      if (r.local) { this.callbacks.onToast?.(`${itemNames[r.item]} ready · Press E`); this.beep(900, .08); }
    }
    for (const h of this.hazards) if (h.life > 0 && h.ownerId !== r.id && Math.abs(r.lateral - h.lateral) < 1.7 && this.crossed(oldDistance, r.distance, wrap(h.distance))) { this.hit(r, 'Banana spin!'); h.life = 0; }
    if (r.ai && r.item && Math.random() < dt * .3) { this.applyItem(r, r.item); r.item = null; }
    if (r.distance >= 3 && !r.finished) this.finishRacer(r);
    this.placeKart(r, dt);
  }

  crossed(from, to, t) { return Math.floor(to - t) > Math.floor(from - t); }

  placeKart(r, dt) {
    const p = this.locate(r.distance, r.lateral, .25);
    if (r.mesh.position.distanceToSquared(p) > 500 || dt === 0) r.mesh.position.copy(p);
    else r.mesh.position.lerp(p, 1 - Math.exp(-22 * dt));
    const dir = this.tangent(r.distance);
    r.mesh.rotation.y = Math.atan2(dir.x, dir.z) + r.heading + (r.stun > 0 ? r.stun * 14 : 0);
    r.mesh.rotation.z = -r.heading * .1;
    r.mesh.position.y += Math.sin(this.clock * 22) * Math.min(r.speed / 600, .05);
    if (r.shield > 0 && !r.shieldMesh) {
      r.shieldMesh = new THREE.Mesh(new THREE.SphereGeometry(2.1, 12, 8), new THREE.MeshBasicMaterial({ color: 0x5be5ff, transparent: true, opacity: .18, wireframe: true }));
      r.shieldMesh.position.y = 1; r.mesh.add(r.shieldMesh);
    }
    if (r.shieldMesh) { r.shieldMesh.visible = r.shield > 0; r.shieldMesh.rotation.y = this.clock; }
    if (!r.flame) {
      r.flame = new THREE.Mesh(new THREE.ConeGeometry(.45, 2.4, 5), new THREE.MeshBasicMaterial({ color: 0x56eaff }));
      r.flame.rotation.x = -Math.PI / 2; r.flame.position.set(0, .6, -2.2); r.mesh.add(r.flame);
    }
    r.flame.visible = r.boost > 0 || (r.local && this.dev.infiniteBoost);
    r.flame.scale.setScalar(.8 + Math.sin(this.clock * 45) * .2);
    if (!r.sparks) {
      r.sparks = new THREE.Group();
      for (const x of [-1.1, 1.1]) { const s = new THREE.Mesh(new THREE.OctahedronGeometry(.32), new THREE.MeshBasicMaterial({ color: 0xffa43b })); s.position.set(x, .25, -.9); r.sparks.add(s); }
      r.mesh.add(r.sparks);
    }
    r.sparks.visible = r.wasDrifting && r.drift > .08;
    r.sparks.children.forEach(s => { s.rotation.x = this.clock * 10; s.material.color.set(r.drift > .7 ? '#b88bff' : r.drift > .35 ? '#54ddff' : '#ffa43b'); s.scale.setScalar(.7 + r.drift); });
  }

  finishRacer(r) {
    r.finished = true; r.finishTime = this.raceElapsed;
    if (!r.local || this.raceFinished) return;
    this.raceFinished = true;
    const standings = this.standings();
    this.callbacks.onFinish?.({ position: standings.findIndex(s => s.isPlayer) + 1, totalRacers: this.racers.length, time: this.raceElapsed, trackId: this.trackId, mode: this.options.mode || 'solo', assisted: this.raceAssisted, standings });
  }

  standings() {
    return [...this.racers].sort((a, b) => a.finished && b.finished ? a.finishTime - b.finishTime : a.finished ? -1 : b.finished ? 1 : b.distance - a.distance).map((r, i) => ({ id: r.id, name: r.name, position: i + 1, isPlayer: r.local, progress: r.distance, finished: r.finished, time: r.finishTime, color: r.color }));
  }

  sendHUD() {
    const p = this.player; if (!p || !this.world) return;
    const standings = this.standings();
    this.callbacks.onHUD?.({ speed: Math.round(p.speed * 3.6), lap: Math.min(3, Math.floor(Math.max(0, p.distance)) + 1), totalLaps: 3,
      position: standings.findIndex(r => r.isPlayer) + 1, totalRacers: this.racers.length, time: this.raceElapsed || 0, item: p.item,
      drift: p.drift, boost: clamp(p.boost / 3, 0, 1), shield: p.shield, standings, progress: p.distance,
      minimap: this.racers.map(r => ({ ...this.mapPoint(this.point(r.distance)), isPlayer: r.local, color: r.color })), trackPath: this.trackPath });
  }

  updateCamera(dt) {
    if (!this.player || !this.world) return;
    const p = this.player;
    let desired, target;
    if (this.mode === 'preview') {
      const t = .075, pos = this.locate(t, 0, .4), dir = this.tangent(t);
      const right = new THREE.Vector3(dir.z, 0, -dir.x).normalize();
      const phase = Math.sin((this.clock - this.previewStarted) * .08) * .22;
      desired = pos.clone().addScaledVector(right, 26 + phase * 10).addScaledVector(dir, -34).add(new THREE.Vector3(0, 22, 0));
      target = pos.clone().addScaledVector(dir, 20).add(new THREE.Vector3(0, 1, 0));
      this.camera.fov = 52;
    } else {
      const dir = this.tangent(p.distance);
      desired = p.mesh.position.clone().addScaledVector(dir, -(13 + p.speed * .1)).add(new THREE.Vector3(0, 7.5, 0));
      target = this.locate(p.distance + .013, p.lateral * .6, 2.1);
      this.camera.fov = THREE.MathUtils.lerp(this.camera.fov, p.boost > 0 ? 66 : 57, 1 - Math.exp(-3 * dt));
    }
    if (!this.cameraReady) { this.camera.position.copy(desired); this.cameraTarget = target.clone(); this.cameraReady = true; }
    else { this.camera.position.lerp(desired, 1 - Math.exp(-5 * dt)); this.cameraTarget.lerp(target, 1 - Math.exp(-7 * dt)); }
    this.camera.lookAt(this.cameraTarget);
    this.camera.updateProjectionMatrix();
    this.sun.position.set(p.mesh.position.x + 80, 150, p.mesh.position.z + 55);
    this.sun.target.position.copy(p.mesh.position);
  }

  frame(now) {
    this.animation = requestAnimationFrame(this.frame);
    const dt = Math.min(.04, Math.max(0, (now - this.lastFrame) / 1000));
    this.lastFrame = now; this.clock += dt;
    this.world?.update?.(this.clock);
    if (this.mode === 'race' && !this.paused) {
      if (this.countdownRemaining > 0) {
        this.countdownRemaining = Math.max(0, (this.startAt - Date.now()) / 1000);
        const value = this.countdownRemaining > 0 ? String(Math.min(3, Math.ceil(this.countdownRemaining))) : 'GO!';
        if (value !== this.lastCountdown) { this.callbacks.onCountdown?.(value); this.beep(value === 'GO!' ? 1000 : 500, .13); this.lastCountdown = value; }
        if (this.countdownRemaining === 0) this.goUntil = this.clock + .8;
      } else {
        if (this.goUntil && this.clock > this.goUntil) { this.callbacks.onCountdown?.(null); this.goUntil = 0; }
        if (!this.raceFinished) this.raceElapsed += dt;
        for (const r of this.racers) this.tickRacer(r, dt);
        // Soft kart contact keeps tight packs lively without trapping the player.
        for (const r of this.racers) if (r !== this.player && Math.abs(r.distance - this.player.distance) * this.world.length < 2.5 && Math.abs(r.lateral - this.player.lateral) < 1.8) {
          this.player.lateral += Math.sign(this.player.lateral - r.lateral || 1) * dt * 3.5;
          this.player.speed *= Math.pow(.85, dt);
        }
      }
      if (this.clock - this.lastHUD > .07) { this.sendHUD(); this.lastHUD = this.clock; }
      if (this.clock - this.lastNetwork > .065 && this.player) {
        const p = this.player;
        this.callbacks.onState?.({ progress: p.distance, lateral: p.lateral, speed: p.speed, heading: p.heading, boost: p.boost > 0, shield: p.shield > 0, finished: p.finished, time: this.raceElapsed });
        this.lastNetwork = this.clock;
      }
    }
    for (const p of this.pickups) { if (!this.paused) p.cooldown = Math.max(0, p.cooldown - dt); p.mesh.visible = p.cooldown === 0; p.mesh.rotation.set(this.clock * .6, this.clock, Math.PI / 4); p.mesh.material.color.setHSL((this.clock * .12 + p.t) % 1, .72, .66); }
    for (let i = this.hazards.length - 1; i >= 0; i--) { const h = this.hazards[i]; if (!this.paused) h.life -= dt; if (h.life <= 0) { this.dynamic.remove(h.mesh); h.mesh.geometry.dispose(); h.mesh.material.dispose(); this.hazards.splice(i, 1); } }
    this.updateCamera(dt);
    if (this.audioContext && this.engineOsc) {
      this.engineOsc.frequency.setTargetAtTime(45 + (this.player?.speed || 0) * 3, this.audioContext.currentTime, .08);
      this.audioGain.gain.setTargetAtTime(this.muted || this.mode !== 'race' || this.paused || this.countdownRemaining > 0 ? 0 : .018, this.audioContext.currentTime, .08);
    }
    this.renderer.render(this.scene, this.camera);
  }

  activateAudio() {
    if (!this.audioContext) {
      try {
        const Audio = window.AudioContext || window.webkitAudioContext;
        if (!Audio) return;
        this.audioContext = new Audio();
        this.audioGain = this.audioContext.createGain(); this.audioGain.gain.value = 0;
        this.engineOsc = this.audioContext.createOscillator(); this.engineOsc.type = 'sawtooth';
        const filter = this.audioContext.createBiquadFilter(); filter.type = 'lowpass'; filter.frequency.value = 350;
        this.engineOsc.connect(filter); filter.connect(this.audioGain); this.audioGain.connect(this.audioContext.destination); this.engineOsc.start();
      } catch { return; }
    }
    if (this.audioContext.state === 'suspended') this.audioContext.resume().catch(() => {});
  }

  beep(frequency, duration) {
    if (!this.audioContext || this.muted) return;
    const oscillator = this.audioContext.createOscillator(), gain = this.audioContext.createGain();
    oscillator.type = 'sine'; oscillator.frequency.value = frequency;
    gain.gain.setValueAtTime(.07, this.audioContext.currentTime); gain.gain.exponentialRampToValueAtTime(.001, this.audioContext.currentTime + duration);
    oscillator.connect(gain); gain.connect(this.audioContext.destination); oscillator.start(); oscillator.stop(this.audioContext.currentTime + duration);
  }

  dispose() {
    cancelAnimationFrame(this.animation);
    window.removeEventListener('keydown', this.keyDown); window.removeEventListener('keyup', this.keyUp); window.removeEventListener('blur', this.blur);
    this.resizeObserver.disconnect(); this.clearDynamic(); this.world?.dispose(); this.renderer.dispose();
    this.audioContext?.close();
  }
}
