import assert from 'node:assert/strict';
import test from 'node:test';
import * as THREE from 'three';
import { KartGame } from '../src/game.js';
import { createWorld, TRACKS } from '../src/world.js';

const LATE_RACERS = [
  { id: 'phantom', speed: 5, handling: 5, expectedTopSpeed: 40 },
  { id: 'ember', speed: 6, handling: 6, expectedTopSpeed: 41.5 },
  { id: 'aurora', speed: 7, handling: 7, expectedTopSpeed: 43 },
];

// Run production integration/placement on real circuit geometry without WebGL.
function simulate(world, character, { progress = .01, speed = 0, keys = ['KeyW'], frames = 350 } = {}) {
  const game = Object.create(KartGame.prototype);
  Object.assign(game, {
    world, mode: 'race', options: { mode: 'solo' }, callbacks: {},
    dynamic: new THREE.Group(), racers: [], pickups: [], hazards: [], coins: [], effects: [], boostPads: [],
    keys: new Set(keys), dev: { speedMultiplier: 1 }, clock: 0, raceElapsed: 0,
  });
  const racer = {
    id: character.id || 'test', name: 'Test', local: true, ai: false,
    character, mesh: new THREE.Group(), distance: progress,
    lateral: 0, heading: 0, steering: 0, speed, drift: 0, item: null,
  };
  game.player = racer; game.racers = [racer]; game.dynamic.add(racer.mesh);
  let peakSpeed = racer.speed;
  try {
    for (let frame = 0; frame < frames; frame++) {
      game.clock += .02; game.raceElapsed += .02;
      game.tickRacer(racer, .02);
      peakSpeed = Math.max(peakSpeed, racer.speed);
    }
    assert.ok(Math.abs(racer.lateral) <= game.barrierLimit() + 1e-8, 'balance changes must preserve physical rails');
    return { peakSpeed, lateral: racer.lateral, heading: racer.heading };
  } finally { game.clearDynamic(); }
}

test('ratings zero through five preserve their existing actual top speeds', () => {
  const world = createWorld(new THREE.Scene(), 'coast');
  try {
    for (let rating = 0; rating <= 5; rating++) {
      const actual = simulate(world, { speed: rating, handling: rating });
      assert.equal(actual.peakSpeed, 38 + rating * .4, `rating ${rating} must preserve its established speed`);
    }
  } finally { world.dispose(); }
});

test('Ember and Aurora exceed Phantom with tangible actual top-speed gains', () => {
  const world = createWorld(new THREE.Scene(), 'coast');
  try {
    const speeds = LATE_RACERS.map(character => {
      const actual = simulate(world, character);
      assert.equal(actual.peakSpeed, character.expectedTopSpeed, `${character.id} actual top speed`);
      return actual.peakSpeed;
    });
    assert.ok(speeds[0] < speeds[1] && speeds[1] < speeds[2], 'Phantom < Ember < Aurora');
    assert.equal(speeds[1] - speeds[0], 1.5, 'Ember gains 1.5 m/s over Phantom');
    assert.equal(speeds[2] - speeds[0], 3, 'Aurora gains 3 m/s over Phantom');
  } finally { world.dispose(); }
});

for (const { id } of TRACKS) {
  test(`${id}: later racers produce stronger actual lateral steering response at the same speed`, () => {
    const world = createWorld(new THREE.Scene(), id);
    try {
      for (const progress of [.04, .17, .31, .52, .72, .89]) {
        for (const [key, sign] of [['KeyA', 1], ['ArrowLeft', 1], ['KeyD', -1], ['ArrowRight', -1]]) {
          const responses = LATE_RACERS.map(character => {
            // A short equal-speed input isolates handling from the increased
            // top-speed cap; every racer remains below that cap throughout.
            const options = { progress, speed: 28, frames: 6 };
            const baseline = simulate(world, character, options);
            const steered = simulate(world, character, { ...options, keys: ['KeyW', key] });
            const response = (steered.lateral - baseline.lateral) * sign;
            assert.ok(response > 0, `${character.id} ${key} at ${progress}: steering direction must remain correct`);
            return response;
          });
          assert.ok(responses[0] < responses[1] && responses[1] < responses[2],
            `${id}, ${key}, progress ${progress}: actual handling must rank Phantom < Ember < Aurora`);
        }
      }
    } finally { world.dispose(); }
  });
}
