import assert from 'node:assert/strict';
import test from 'node:test';
import * as THREE from 'three';
import { createKart } from '../src/models.js';
import { KartGame } from '../src/game.js';

const RACERS = ['nova','milo','jax','rio','pixel','phantom','ember','aurora'];
const ANIMATED = ['body','driver','helmet','steeringWheel','flame'];

function release(kart) {
  const materials = new Set();
  kart.traverse(object => {
    object.geometry?.dispose();
    object.userData.ownedTexture?.dispose();
    const owned = object.material ? (Array.isArray(object.material) ? object.material : [object.material]) : [];
    owned.forEach(material => materials.add(material));
  });
  materials.forEach(material => material.dispose());
}

for (const id of RACERS) {
  test(`${id}: detailed model is finite, articulated, and fits the barrier footprint`, () => {
    const kart = createKart('#76bad3',id);
    try {
      kart.updateMatrixWorld(true);
      assert.equal(kart.userData.characterId,id);
      const {wheels,frontWheels} = kart.userData;
      assert.equal(wheels.length,4,'four independently rolling wheels');
      assert.equal(new Set(wheels).size,4);
      assert.equal(frontWheels.length,2,'two independently steering front pivots');
      assert.equal(new Set(frontWheels).size,2);
      for(const pivot of frontWheels) {
        assert.equal(pivot.parent,kart);
        assert.ok(pivot.children.some(child=>wheels.includes(child)), 'front steering owns a rolling wheel');
      }
      for(const node of ANIMATED) {
        assert.ok(kart.userData[node]?.isObject3D,`animation hook ${node}`);
        let ancestor=kart.userData[node];
        while(ancestor && ancestor!==kart)ancestor=ancestor.parent;
        assert.equal(ancestor,kart,`${node} must be attached to the kart`);
      }
      assert.equal(kart.userData.helmet.parent,kart.userData.driver);
      assert.equal(kart.userData.driver.parent,kart.userData.body);
      assert.equal(kart.userData.flame.visible,false);
      assert.ok(kart.userData.wheelRadius>0 && Number.isFinite(kart.userData.wheelRadius));

      let meshes=0, vertices=0, maxPhysicalX=0, shadows=0;
      const vertex = new THREE.Vector3();
      kart.traverse(object => {
        if(!object.isMesh)return;
        meshes++;
        const position=object.geometry.getAttribute('position');
        assert.ok(position?.count>0,'visible mesh must contain geometry');
        for(const attribute of ['position','normal']) {
          const values=object.geometry.getAttribute(attribute)?.array;
          assert.ok(values,`${object.name||object.type} has ${attribute}`);
          for(const value of values)assert.ok(Number.isFinite(value),`${id} has finite ${attribute}`);
        }
        vertices+=position.count;
        const materials=Array.isArray(object.material)?object.material:[object.material];
        for(const material of materials) {
          for(const colorName of ['color','emissive'])if(material[colorName]) {
            for(const channel of ['r','g','b'])assert.ok(Number.isFinite(material[colorName][channel]));
          }
          for(const property of ['opacity','roughness','metalness'])if(property in material)assert.ok(Number.isFinite(material[property]));
        }
        if(object.userData.ownedTexture) {
          shadows++;
          assert.ok(object.userData.ownedTexture.isDataTexture,'soft shadow owns a disposable texture');
          return; // A soft translucent shadow is not physical collision geometry.
        }
        for(let i=0;i<position.count;i++) {
          vertex.fromBufferAttribute(position,i).applyMatrix4(object.matrixWorld);
          maxPhysicalX=Math.max(maxPhysicalX,Math.abs(vertex.x));
        }
      });
      assert.ok(meshes>=20,'full body, articulated wheels and driver are present');
      assert.ok(meshes<=75,`${meshes} draw calls exceed the per-kart budget`);
      assert.ok(vertices>1000,'model contains detailed geometry');
      assert.equal(shadows,1,'exactly one soft contact shadow');
      assert.ok(maxPhysicalX<=1.65+1e-6,`body extends ${maxPhysicalX} from center; barrier fit assumes 1.65`);

      const oldWheel=wheels[0].matrixWorld.clone();
      const oldBody=kart.userData.body.matrixWorld.clone();
      wheels[0].rotation.x+=.3;
      frontWheels[0].rotation.y+=.2;
      kart.updateMatrixWorld(true);
      assert.ok(!oldWheel.equals(wheels[0].matrixWorld),'wheel can roll independently');
      assert.ok(oldBody.equals(kart.userData.body.matrixWorld),'wheel animation does not move the body');
    } finally { release(kart); }
  });
}

test('all eight racers have distinct helmet silhouettes and race numbers', () => {
  const silhouettes=new Set(), numbers=new Set();
  for(const id of RACERS) {
    const kart=createKart('#76bad3',id);
    try {
      kart.updateMatrixWorld(true);
      const bounds=new THREE.Box3().setFromObject(kart.userData.helmet);
      // Accessories must change the visible silhouette, not just paint colors.
      const silhouette=[...bounds.min.toArray(),...bounds.max.toArray()].map(v=>v.toFixed(4)).join(',');
      assert.ok(!silhouettes.has(silhouette),`${id} must have a distinct helmet silhouette`);
      silhouettes.add(silhouette);
      assert.ok(!numbers.has(kart.userData.number),`${id} must have a distinct hood number`);
      numbers.add(kart.userData.number);
    } finally { release(kart); }
  }
  assert.equal(silhouettes.size,RACERS.length);
});

for(const method of ['clearDynamic','removeRemote']) {
  test(`${method}: kart teardown disposes its soft-shadow texture`, () => {
    const kart=createKart('#76bad3','nova');
    const game=Object.create(KartGame.prototype);
    game.dynamic=new THREE.Group();game.dynamic.add(kart);
    game.racers=[{id:'remote',local:false,mesh:kart}];
    game.sendHUD=()=>{};
    let disposed=0;
    kart.traverse(object=>object.userData.ownedTexture?.addEventListener('dispose',()=>disposed++));
    if(method==='clearDynamic')game.clearDynamic();else game.removeRemote('remote');
    assert.equal(disposed,1,'owned texture must release its GPU allocation');
    assert.equal(game.dynamic.children.length,0);
    assert.equal(game.racers.length,0);
  });
}
