import assert from 'node:assert/strict';
import test from 'node:test';
import * as THREE from 'three';
import { KartGame } from '../src/game.js';
import { createWorld, TRACKS as TRACK_INFO } from '../src/world.js';

const TRACKS = TRACK_INFO.map(track => track.id);
const POSITIONS = [.04, .17, .31, .52, .72, .89];
const STEERING_KEYS = [
  ['KeyA', -1], ['ArrowLeft', -1],
  ['KeyD', 1], ['ArrowRight', 1],
];

// Exercise the actual physics, kart placement, and chase-camera methods without
// constructing a WebGL renderer or requiring a browser. A fixed initial camera
// makes the short control displacement measurable against an identical no-steer baseline.
function simulate(world, progress, keys = [], initialSpeed = 28) {
  const game = Object.create(KartGame.prototype);
  Object.assign(game, {
    world, mode: 'race', options: { mode: 'solo' }, callbacks: {},
    dynamic: new THREE.Group(), racers: [], pickups: [], hazards: [], boostPads: [],
    keys: new Set(keys), dev: { speedMultiplier: 1 }, clock: 1, raceElapsed: 1,
    difficulty: 'rookie', cameraReady: false,
    camera: new THREE.PerspectiveCamera(57, 16 / 9, .2, 1600),
    sun: new THREE.DirectionalLight(),
  });
  const racer = {
    id: 'test', name: 'Test', local: true, ai: false,
    character: { speed: 4, handling: 4 }, mesh: new THREE.Group(),
    distance: progress, lateral: 0, heading: 0, speed: initialSpeed,
    boost: 0, shield: 0, stun: 0, padCooldown: 0, drift: 0,
    wasDrifting: false, item: null, finished: false,
  };
  game.player = racer;
  game.racers = [racer];
  game.placeKart(racer, 0);
  game.updateCamera(.02);
  game.camera.updateMatrixWorld(true);
  for (let i = 0; i < 6; i++) {
    game.clock += .02;
    game.tickRacer(racer, .02);
  }
  const result = {
    screenX: racer.mesh.position.clone().project(game.camera).x,
    speed: racer.speed, progress: racer.distance,
    lateral: racer.lateral, heading: racer.heading, drift: racer.drift,
  };
  racer.mesh.traverse(object => {
    object.geometry?.dispose();
    const materials = object.material
      ? (Array.isArray(object.material) ? object.material : [object.material]) : [];
    materials.forEach(material => material.dispose());
  });
  return result;
}

for (const track of TRACKS) {
  test(`${track}: A/Left project left and D/Right project right, including drifting`, () => {
    const world = createWorld(new THREE.Scene(), track);
    try {
      for (const progress of POSITIONS) {
        for (const drifting of [false, true]) {
          const baseKeys = ['KeyW', ...(drifting ? ['Space'] : [])];
          const baseline = simulate(world, progress, baseKeys);
          for (const [key, direction] of STEERING_KEYS) {
            const actual = simulate(world, progress, [...baseKeys, key]);
            const delta = actual.screenX - baseline.screenX;
            const context = `${track}, progress ${progress}, ${key}, drift ${drifting}`;
            assert.ok(delta * direction > .001,
              `${context}: screen displacement ${delta} must point ${direction < 0 ? 'left' : 'right'}`);
            if (drifting) assert.ok(actual.drift > 0, `${context}: the drift must be active`);
          }
        }
      }
    } finally { world.dispose(); }
  });
}

test('W/Up accelerates forward and S/Down brakes relative to coasting', () => {
  for (const track of TRACKS) {
    const world = createWorld(new THREE.Scene(), track);
    try {
      for (const progress of POSITIONS) {
        const coast = simulate(world, progress, [], 20);
        for (const key of ['KeyW', 'ArrowUp']) {
          const actual = simulate(world, progress, [key], 20);
          assert.ok(actual.speed > coast.speed, `${track} ${key}: speed must increase`);
          assert.ok(actual.progress > coast.progress, `${track} ${key}: forward progress must increase`);
        }
        for (const key of ['KeyS', 'ArrowDown']) {
          const actual = simulate(world, progress, [key], 20);
          assert.ok(actual.speed < coast.speed, `${track} ${key}: speed must decrease`);
          assert.ok(actual.progress < coast.progress, `${track} ${key}: forward progress must slow`);
          assert.ok(actual.progress >= progress, `${track} ${key}: braking must not reverse lap progress`);
        }
      }
    } finally { world.dispose(); }
  }
});

test('opposing steering inputs cancel for WASD, arrow keys, and mixed keys', () => {
  const opposing = [
    ['KeyA', 'KeyD'], ['ArrowLeft', 'ArrowRight'],
    ['KeyA', 'ArrowRight'], ['ArrowLeft', 'KeyD'],
  ];
  for (const track of TRACKS) {
    const world = createWorld(new THREE.Scene(), track);
    try {
      for (const progress of POSITIONS) {
        for (const drifting of [false, true]) {
          const baseKeys = ['KeyW', ...(drifting ? ['Space'] : [])];
          const baseline = simulate(world, progress, baseKeys);
          for (const pair of opposing) {
            const actual = simulate(world, progress, [...baseKeys, ...pair]);
            assert.deepEqual(actual, baseline,
              `${track}, progress ${progress}, drift ${drifting}: ${pair.join(' + ')} must cancel`);
          }
        }
      }
    } finally { world.dispose(); }
  }
});
