import assert from 'node:assert/strict';
import test from 'node:test';
import * as THREE from 'three';
import { KartGame } from '../src/game.js';
import { createWorld, createKart, TRACKS } from '../src/world.js';

const defaultDev = () => ({ infiniteBoost: false, invincible: false, speedMultiplier: 1, freezeAI: false, infiniteItems: false, timeScale: 1 });

function harness(world, overrides = {}) {
  const game = Object.create(KartGame.prototype);
  Object.assign(game, {
    scene: new THREE.Scene(), world, mode: 'race', trackId: 'coast',
    options: { mode: 'solo' }, callbacks: {}, dynamic: new THREE.Group(),
    racers: [], pickups: [], hazards: [], coins: [], effects: [], boostPads: [],
    keys: new Set(['KeyW']), dev: defaultDev(), clock: 1, raceElapsed: 0,
    raceAssisted: false, raceFinished: false, countdownRemaining: 0,
    difficulty: 'rookie', mapBounds: { minX: -300, maxX: 300, minZ: -300, maxZ: 300 }, trackPath: [],
  }, overrides);
  const racer = {
    id: 'local', name: 'Test', local: true, ai: false,
    character: { speed: 4, handling: 4 }, mesh: new THREE.Group(),
    distance: .17, lateral: 0, heading: 0, steering: 0, speed: 32,
    boost: 0, nitro: 0, shield: 0, stun: 0, padCooldown: 0, drift: 0,
    wasDrifting: false, item: null, itemCooldown: 0, finished: false,
    coins: 0, lapSplits: [], completedLaps: 0, lapStartedAt: 0,
  };
  game.player = racer; game.racers = [racer]; game.dynamic.add(racer.mesh);
  game.placeKart(racer, 0);
  return { game, racer, dispose: () => game.clearDynamic() };
}

function assertInside(game, racer, message = '') {
  const limit = game.barrierLimit();
  assert.ok(Math.abs(racer.lateral) <= limit + 1e-9, `${message}: physics center must remain inside rail`);
  const center = game.point(racer.distance), tangent = game.tangent(racer.distance);
  const lateralAxis = new THREE.Vector3(tangent.z, 0, -tangent.x).normalize();
  const displayedLateral = racer.mesh.position.clone().sub(center).dot(lateralAxis);
  assert.ok(Math.abs(displayedLateral) <= limit + 1e-7, `${message}: rendered center must remain inside rail`);
}

for (const { id } of TRACKS) {
  test(`${id}: rails contain steering, drifts, boosted/debug speed, AI and remote karts`, () => {
    const world = createWorld(new THREE.Scene(), id);
    try {
      const innerRail = world.barrier.center - world.barrier.width / 2;
      assert.ok(world.barrierLimit + world.barrier.kartRadius <= innerRail + 1e-8, 'kart footprint fits inside inner rail');
      for (const debug of [false, true]) for (const drifting of [false, true]) for (const side of [-1, 1]) {
        const fixture = harness(world);
        const { game, racer } = fixture;
        try {
          game.setDev({ infiniteBoost: debug, invincible: debug, speedMultiplier: debug ? 3 : 1 });
          game.keys = new Set(['KeyW', side > 0 ? 'KeyA' : 'ArrowRight', ...(drifting ? ['Space'] : [])]);
          racer.lateral = side * (world.barrierLimit - .001); racer.heading = side * 1; racer.speed = 200; racer.nitro = 10; racer.boost = 10;
          for (let frame = 0; frame < 200; frame++) {
            game.clock += .04; game.raceElapsed += .04;
            game.tickRacer(racer, .04);
            assertInside(game, racer, `debug=${debug}, drift=${drifting}, side=${side}, frame=${frame}`);
          }
        } finally { fixture.dispose(); }
      }
      for (const ai of [true, false]) for (const side of [-1, 1]) {
        const fixture = harness(world);
        const { game, racer } = fixture;
        try {
          racer.local = false; racer.ai = ai; racer.aiSkill = 1;
          racer.lateral = side * 100; racer.heading = side; racer.speed = 160;
          if (!ai) {
            game.setRemoteState(racer.id, { progress: .2, lateral: side * 1e6, speed: 80, heading: side });
            assert.ok(Math.abs(racer.targetLateral) <= world.barrierLimit);
          }
          for (let frame = 0; frame < 30; frame++) {
            game.clock += .04; game.tickRacer(racer, .04); assertInside(game, racer, `ai=${ai}`);
          }
        } finally { fixture.dispose(); }
      }
    } finally { world.dispose(); }
  });
}

test('barrier impact removes outward heading, slows an invincible kart, and recovery stays inside', () => {
  const world = createWorld(new THREE.Scene(), 'coast');
  const fixture = harness(world);
  const { game, racer } = fixture;
  try {
    game.setDev({ invincible: true, infiniteBoost: true, speedMultiplier: 3 });
    Object.assign(racer, { lateral: 100, heading: 1, speed: 160 });
    assert.equal(game.enforceBarriers(racer), true);
    assert.ok(racer.heading <= 0, 'outward heading must stop at the right-side rail');
    assert.ok(racer.speed < 100, 'a hard physical hit must slow even an invincible kart');
    assert.ok(game.cameraShake > 0 && racer.collisionSpark > 0);
    game.placeKart(racer, 0); assertInside(game, racer);
    Object.assign(racer, { lateral: -1e8, heading: -Infinity, speed: 999 });
    game.resetKart();
    assert.equal(racer.lateral, 0); assert.equal(racer.heading, 0); assert.ok(racer.speed <= 15); assertInside(game, racer);
  } finally { fixture.dispose(); world.dispose(); }
});

test('developer settings sanitize values, latch assisted status, and all gameplay commands stay offline', () => {
  const world = createWorld(new THREE.Scene(), 'coast');
  try {
    const fixture = harness(world);
    try {
      const { game } = fixture;
      assert.equal(game.setDev({ speedMultiplier: 999, timeScale: -999, infiniteBoost: true }), true);
      assert.equal(game.dev.speedMultiplier, 3); assert.equal(game.dev.timeScale, .25); assert.equal(game.raceAssisted, true);
      game.setDev(defaultDev()); assert.equal(game.raceAssisted, true, 'disabling tools must not erase an assisted race');
      game.setDev({ speedMultiplier: NaN, timeScale: Infinity });
      assert.equal(game.dev.speedMultiplier, 1); assert.equal(game.dev.timeScale, 1);
      assert.equal(game.setDev(null), false);
      assert.equal(game.devCommand('grantItem', 'constructor'), false);
      assert.equal(game.devCommand('teleportCheckpoint', 99), false);
    } finally { fixture.dispose(); }
    for (const [command, value] of [['grantItem', 'emp'], ['recover'], ['teleportCheckpoint', 3], ['skipCountdown'], ['finishRace']]) {
      const offline = harness(world);
      try {
        offline.game.countdownRemaining = 3;
        assert.equal(offline.game.devCommand(command, value), true, `${command} works offline`);
        assert.equal(offline.game.raceAssisted, true, `${command} marks race assisted`);
        assertInside(offline.game, offline.racer);
      } finally { offline.dispose(); }
      const online = harness(world, { options: { mode: 'online' } });
      try {
        online.game.countdownRemaining = 3;
        assert.equal(online.game.setDev({ infiniteBoost: true, freezeAI: true, infiniteItems: true }), false);
        assert.equal(online.game.devCommand(command, value), false, `${command} must be disabled online`);
        assert.deepEqual(online.game.dev, defaultDev());
        assert.equal(online.game.raceAssisted, false); assert.equal(online.racer.finished, false);
      } finally { online.dispose(); }
    }
  } finally { world.dispose(); }
});

test('coins are collected once per racer per race, and lap splits reach HUD/results', () => {
  const world = createWorld(new THREE.Scene(), 'coast');
  const fixture = harness(world);
  const { game, racer } = fixture;
  try {
    const mesh = new THREE.Mesh(new THREE.BoxGeometry(1, 1, 1), new THREE.MeshBasicMaterial()); game.dynamic.add(mesh);
    game.coins = [{ t: .1001, lateral: 0, collectedBy: new Set(), mesh }];
    racer.distance = .1; game.tickRacer(racer, .04);
    assert.equal(racer.coins, 1); assert.equal(mesh.visible, false);
    racer.distance = 1.1; game.tickRacer(racer, .04); assert.equal(racer.coins, 1, 'same coin must not respawn next lap');
    racer.completedLaps = 0; racer.lapSplits = []; racer.lapStartedAt = 0; racer.bestLap = null; racer.lastLap = null;
    for (const [distance, elapsed] of [[1, 30], [2, 60], [3, 92]]) { racer.distance = distance; game.raceElapsed = elapsed; game.recordLapSplits(racer); }
    let result, hud;
    game.callbacks.onFinish = data => { result = data; }; game.callbacks.onHUD = data => { hud = data; };
    game.finishRacer(racer); game.sendHUD();
    assert.deepEqual(result.lapSplits, [30, 30, 32]); assert.equal(result.bestLap, 30); assert.equal(result.lastLap, 32); assert.equal(result.coins, 1);
    assert.equal(hud.coins, 1); assert.equal(hud.bestLap, 30); assert.equal(hud.lastLap, 32);
    assert.ok(Number.isFinite(hud.telemetry.x) && Number.isFinite(hud.telemetry.heading));
  } finally { fixture.dispose(); world.dispose(); }
});

test('EMP affects nearby controlled rivals, nitro boosts longer, and infinite items remains assisted', () => {
  const world = createWorld(new THREE.Scene(), 'coast');
  const fixture = harness(world);
  const { game, racer } = fixture;
  try {
    const near = { ...racer, id: 'near', local: false, ai: true, distance: racer.distance + 20 / world.length, speed: 35 };
    const far = { ...racer, id: 'far', local: false, ai: true, distance: racer.distance + 100 / world.length, speed: 35 };
    game.racers.push(near, far);
    game.applyItem(racer, 'emp');
    assert.ok(near.speed < 35); assert.equal(far.speed, 35); assert.equal(game.effects.length, 1);
    game.applyItem(racer, 'turbo'); const turboDuration = racer.boost;
    game.applyItem(racer, 'nitro'); assert.ok(racer.boost > turboDuration); assert.ok(racer.nitro > 0);
    game.setDev({ infiniteItems: true }); racer.item = 'shield'; game.useItem();
    assert.equal(racer.item, 'shield'); assert.ok(racer.shield > 0); assert.equal(game.raceAssisted, true);
  } finally { fixture.dispose(); world.dispose(); }
});

test('a throttle press near GO grants a launch boost while an early held throttle does not', () => {
  const world = createWorld(new THREE.Scene(), 'coast');
  try {
    for (const [pressAt, shouldBoost] of [[9500, true], [8500, false]]) {
      const fixture = harness(world);
      try {
        Object.assign(fixture.game, { startAt: 10000, lastThrottleDown: pressAt, countdownRemaining: 1 });
        fixture.game.updateCountdown(10001);
        assert.equal(fixture.racer.boost > 0, shouldBoost); assert.equal(fixture.game.countdownRemaining, 0);
      } finally { fixture.dispose(); }
    }
  } finally { world.dispose(); }
});

test('real kart wheels/steering animate and its body follows the track slope', () => {
  const world = createWorld(new THREE.Scene(), 'alpine');
  const fixture = harness(world);
  const { game, racer } = fixture;
  try {
    racer.mesh = createKart('#ee654c', 'nova'); racer.flame = null; racer.sparks = null; racer.shieldMesh = null; game.dynamic.add(racer.mesh);
    racer.steering = .8; racer.distance = .32; racer.speed = 25;
    const wheel = racer.mesh.userData.wheels[0], before = wheel.rotation.x;
    game.placeKart(racer, .04);
    assert.ok(wheel.rotation.x > before);
    assert.ok(racer.mesh.userData.frontWheels[0].rotation.y > 0);
    assert.equal(racer.flame, racer.mesh.userData.flame, 'reuse model exhaust');
    const tangent = game.tangent(racer.distance);
    assert.ok(Math.abs(racer.mesh.rotation.x + Math.atan2(tangent.y, Math.hypot(tangent.x, tangent.z))) < 1e-9);
    assert.equal(game.setCamera('wide'), true); assert.equal(game.setCamera('invalid'), false);
    assert.equal(game.setQuality('low'), true); assert.equal(game.setQuality('invalid'), false);
  } finally { fixture.dispose(); world.dispose(); }
});

test('rotated physical kart geometry fits inside rails at contact, including front steering and slopes', () => {
  for (const { id } of TRACKS) {
    const world = createWorld(new THREE.Scene(), id);
    const fixture = harness(world);
    const { game, racer } = fixture;
    try {
      racer.mesh = createKart('#ee654c', 'nova'); racer.flame = null; racer.sparks = null; racer.shieldMesh = null;
      game.dynamic.add(racer.mesh);
      for (const progress of [.17, .32, .72]) for (const side of [-1, 1]) for (const relativeHeading of [-.8, .8]) {
        Object.assign(racer, { distance: progress, lateral: side * world.barrierLimit, heading: side * relativeHeading, steering: side, stun: 1.2 });
        game.placeKart(racer, .04); racer.mesh.updateMatrixWorld(true);
        const center = game.point(racer.distance), tangent = game.tangent(racer.distance);
        const axis = new THREE.Vector3(tangent.z, 0, -tangent.x).normalize();
        const vertex = new THREE.Vector3();
        let maxPhysicalLateral = 0;
        racer.mesh.traverse(object => {
          if (!object.isMesh || object.userData.ownedTexture) return;
          for (let ancestor = object; ancestor && ancestor !== racer.mesh; ancestor = ancestor.parent) {
            if ([racer.flame, racer.sparks, racer.shieldMesh].includes(ancestor)) return;
          }
          const vertices = object.geometry.getAttribute('position');
          for (let i = 0; i < vertices.count; i++) {
            vertex.fromBufferAttribute(vertices, i).applyMatrix4(object.matrixWorld).sub(center);
            maxPhysicalLateral = Math.max(maxPhysicalLateral, Math.abs(vertex.dot(axis)));
          }
        });
        const innerRail = world.barrier.center - world.barrier.width / 2;
        assert.ok(maxPhysicalLateral <= innerRail + 1e-5,
          `${id} at ${progress}, heading ${relativeHeading}: physical model reaches ${maxPhysicalLateral}, rail begins ${innerRail}`);
      }
    } finally { fixture.dispose(); world.dispose(); }
  }
});
