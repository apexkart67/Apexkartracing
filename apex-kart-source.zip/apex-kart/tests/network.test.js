import assert from 'node:assert/strict';
import { EventEmitter } from 'node:events';
import { readFile } from 'node:fs/promises';
import test from 'node:test';

const source = await readFile(new URL('../src/network.js', import.meta.url), 'utf8');
let moduleSequence = 0;

// Replace only the external PeerJS transport. Exercise the production room,
// validation, relay, rate-limit, and cleanup code without a signaling service.
async function setup(t) {
  const servers = new Map();
  const networks = [];
  let counter = 0;
  let time = 1000;
  t.mock.method(performance, 'now', () => time);
  class Connection extends EventEmitter {
    constructor(peer, metadata) { super(); this.peer = peer; this.metadata = metadata; this.open = false; this.closed = false; }
    send(data) {
      if (this.open) queueMicrotask(() => { if (this.other?.open) this.other.emit('data', structuredClone(data)); });
    }
    close() {
      if (this.closed) return;
      this.closed = true; this.open = false;
      if (this.other) { this.other.closed = true; this.other.open = false; }
      queueMicrotask(() => { this.emit('close'); this.other?.emit('close'); });
    }
  }
  class MockPeer extends EventEmitter {
    constructor(id) {
      super(); this.id = id || `guest-${++counter}`; this.destroyed = false; this.connections = [];
      servers.set(this.id, this);
      queueMicrotask(() => { if (!this.destroyed) this.emit('open', this.id); });
    }
    connect(id, options = {}) {
      const local = new Connection(id, options.metadata);
      const target = servers.get(id);
      this.connections.push(local);
      if (!target) { queueMicrotask(() => this.emit('error', { type: 'peer-unavailable' })); return local; }
      const remote = new Connection(this.id, options.metadata);
      local.other = remote; remote.other = local; target.connections.push(remote);
      queueMicrotask(() => {
        if (this.destroyed || target.destroyed || local.closed) return;
        target.emit('connection', remote); local.open = remote.open = true;
        remote.emit('open'); local.emit('open');
      });
      return local;
    }
    destroy() { this.destroyed = true; servers.delete(this.id); this.connections.forEach(c => c.close()); }
    reconnect() {}
  }
  const key = `__apexNetworkTransport${++moduleSequence}`;
  globalThis[key] = MockPeer;
  const imported = await import(`data:text/javascript;base64,${Buffer.from(source.replace("import Peer from 'peerjs';", `const Peer = globalThis.${key};`)).toString('base64')}`);
  delete globalThis[key];
  const create = () => {
    const events = [];
    const network = imported.createNetwork(event => events.push(event));
    networks.push(network);
    return { network, events };
  };
  const flush = () => new Promise(resolve => setImmediate(resolve));
  t.after(async () => { networks.forEach(n => n.leave()); for (const p of servers.values()) p.destroy(); await flush(); });
  return { create, flush, servers, MockPeer, advance: (ms = 200) => { time += ms; } };
}

test('all six tracks start with the same roster, identities, and countdown on three peers', async t => {
  const env = await setup(t);
  for (const trackId of ['coast', 'canyon', 'neon', 'alpine', 'volcano', 'forest']) {
    const host = env.create(), first = env.create(), second = env.create();
    const code = await host.network.host('Host\u0000', 'nova');
    assert.match(code, /^[A-HJ-NP-Z2-9]{6}$/);
    assert.match(host.network.id, /^apex-kart-v2-/);
    await first.network.join(code.toLowerCase(), 'First', 'milo');
    await second.network.join(code, 'Second', 'jax');
    await env.flush();
    assert.equal(host.network.peers[0].name, 'Host');
    assert.equal(first.network.peers.length, 3);
    assert.equal(env.servers.get(first.network.id).connections[0].metadata.version, 2);
    host.network.start(trackId);
    await env.flush();
    for (const racer of [host, first, second]) {
      const start = racer.events.find(e => e.type === 'start');
      assert.equal(start.trackId, trackId);
      assert.deepEqual(start.players.map(p => p.id), host.network.peers.map(p => p.id));
      assert.ok(Math.abs(start.startAt - host.events.find(e => e.type === 'start').startAt) < 100);
    }
    assert.throws(() => host.network.start(trackId), /already in progress/);
    [host, first, second].forEach(r => r.network.leave());
    await env.flush();
  }
});

test('rooms reject old versions, full rooms, invalid tracks, and late arrivals', async t => {
  const env = await setup(t);
  const host = env.create();
  const code = await host.network.host('Host', 'nova');
  assert.throws(() => host.network.start('unknown'), /valid track/);
  const old = new env.MockPeer('old-client');
  const rejected = [];
  old.connect(host.network.id, { metadata: { version: 1, name: 'Old', character: 'nova' } }).on('data', d => rejected.push(d));
  await env.flush();
  assert.match(rejected[0].message, /different game version/);
  assert.equal(host.network.peers.length, 1);
  for (let i = 0; i < 7; i++) await env.create().network.join(code, `Guest ${i}`, 'milo');
  assert.equal(host.network.peers.length, 8);
  await assert.rejects(env.create().network.join(code, 'Overflow', 'milo'), /full/);
  host.network.start('forest');
  await assert.rejects(env.create().network.join(code, 'Late', 'milo'), /already started/);
  await assert.rejects(env.create().network.join('!!!', 'Bad', 'nova'), /valid 6-character/);
});

test('six item types relay with trusted sender identity and only validated item fields', async t => {
  const env = await setup(t);
  const host = env.create(), guest = env.create(), observer = env.create();
  const code = await host.network.host('Host', 'nova');
  await guest.network.join(code, 'Guest', 'milo');
  await observer.network.join(code, 'Observer', 'jax');
  host.network.start('volcano'); await env.flush();
  for (const type of ['turbo', 'rocket', 'shield', 'banana', 'emp', 'nitro']) {
    env.advance();
    guest.network.sendItem({ type, target: host.network.id, progress: 1.25, lateral: -3, admin: true });
    await env.flush();
    const event = observer.events.filter(e => e.type === 'item').at(-1);
    assert.equal(event.id, guest.network.id);
    assert.deepEqual(event.item, { type, target: host.network.id, progress: 1.25, lateral: -3 });
  }
  const raw = env.servers.get(guest.network.id).connections[0];
  const count = observer.events.filter(e => e.type === 'item').length;
  for (const item of [
    { type: 'unknown', progress: .2, lateral: 0 },
    { type: 'nitro', progress: Infinity, lateral: 0 },
    { type: 'emp', progress: .2, lateral: NaN },
    { type: 'rocket', target: 'not-in-room', progress: .2, lateral: 0 },
    { type: 'banana', progress: 4, lateral: 0 },
    { type: 'banana', progress: .2, lateral: 1000 },
    { type: 'turbo' }, [], null,
  ]) {
    env.advance(); raw.send({ type: 'item', id: host.network.id, item }); await env.flush();
  }
  assert.equal(observer.events.filter(e => e.type === 'item').length, count);
  env.advance();
  raw.send({ type: 'item', id: host.network.id, item: { type: 'emp', progress: .4, lateral: 2 } });
  await env.flush();
  assert.equal(observer.events.filter(e => e.type === 'item').at(-1).id, guest.network.id);
});

test('host throttles direct guest spam and local traffic, while state remains bounded', async t => {
  const env = await setup(t);
  const host = env.create(), guest = env.create(), observer = env.create();
  const code = await host.network.host('Host', 'nova');
  await guest.network.join(code, 'Guest', 'milo'); await observer.network.join(code, 'Observer', 'jax');
  host.network.start('alpine'); await env.flush();
  const raw = env.servers.get(guest.network.id).connections[0];
  env.advance();
  for (let i = 0; i < 20; i++) raw.send({ type: 'state', state: { progress: .4, speed: 60, invalid: Infinity, note: 'x'.repeat(500) } });
  for (let i = 0; i < 20; i++) raw.send({ type: 'item', item: { type: 'nitro', progress: .4, lateral: 0 } });
  await env.flush();
  assert.equal(host.events.filter(e => e.type === 'state').length, 1);
  assert.equal(observer.events.filter(e => e.type === 'item').length, 1);
  const state = observer.events.find(e => e.type === 'state').state;
  assert.equal(state.invalid, null); assert.equal(state.note.length, 80);
  env.advance();
  for (let i = 0; i < 20; i++) host.network.broadcastState({ progress: .5 });
  for (let i = 0; i < 20; i++) host.network.sendItem({ type: 'emp', progress: .5, lateral: 0 });
  await env.flush();
  assert.equal(observer.events.filter(e => e.type === 'state' && e.id === host.network.id).length, 1);
  assert.equal(observer.events.filter(e => e.type === 'item' && e.id === host.network.id).length, 1);
  env.advance(20); raw.send({ type: 'state', state: { progress: .6 } }); await env.flush();
  assert.equal(host.events.filter(e => e.type === 'state').length, 2);
});

test('guest departure updates the roster and losing the host closes the room', async t => {
  const env = await setup(t);
  const host = env.create(), guest = env.create(), observer = env.create();
  const code = await host.network.host('Host', 'nova');
  await guest.network.join(code, 'Guest', 'milo'); await observer.network.join(code, 'Observer', 'jax');
  const departingId = guest.network.id;
  guest.network.leave(); await env.flush();
  assert.equal(host.network.peers.length, 2);
  assert.ok(observer.events.some(e => e.type === 'left' && e.id === departingId));
  host.network.leave(); await env.flush();
  assert.equal(observer.network.connected, false);
  assert.ok(observer.events.some(e => e.type === 'closed'));
});

test('purchased paint colors survive roster and start relay; invalid CSS colors are discarded', async t => {
  const env = await setup(t);
  const host = env.create(), guest = env.create(), observer = env.create();
  const code = await host.network.host('Host', 'nova', '#F6BE50');
  await guest.network.join(code, 'Guest', 'milo', '#39b9df');
  await observer.network.join(code, 'Observer', 'jax', 'url(https://invalid.test/color)');
  await env.flush();
  for (const racer of [host, guest, observer]) {
    assert.equal(racer.network.peers[0].color, '#f6be50');
    assert.equal(racer.network.peers[1].color, '#39b9df');
    assert.equal(racer.network.peers[2].color, undefined);
  }
  host.network.start('neon'); await env.flush();
  const start = observer.events.find(e => e.type === 'start');
  assert.equal(start.players[0].color, '#f6be50');
  assert.equal(start.players[1].color, '#39b9df');
  assert.equal(start.players[2].color, undefined);
});
