import test from 'node:test';
import assert from 'node:assert/strict';
import * as THREE from 'three';
import { BARRIER_LIMIT, TRACKS, createWorld, getTrackMap } from '../src/world.js';

const close = (actual, expected, tolerance = 1e-6, label = 'values') =>
  assert.ok(Math.abs(actual - expected) <= tolerance, `${label}: ${actual} != ${expected}`);
const orient = (a, b, c) => (b.x - a.x) * (c.z - a.z) - (b.z - a.z) * (c.x - a.x);
const intersects = (a, b, c, d) => orient(a, b, c) * orient(a, b, d) < 0 && orient(c, d, a) * orient(c, d, b) < 0;

function checkMapAndClosure(world, id) {
  assert.equal(world.curve.closed, true);
  close(world.getPoint(0).distanceTo(world.getPoint(1)), 0, 1e-10, 'closed road');
  close(world.getTangent(0).distanceTo(world.getTangent(1)), 0, 1e-10, 'closed direction');
  close(world.getPoint(-.1).distanceTo(world.getPoint(.9)), 0, 1e-10, 'wrapped progress');
  const map = getTrackMap(id);
  assert.ok(map.length >= 80, 'track map has enough detail');
  const points = map.map((_, index) => world.getPoint(index / (map.length - 1)));
  const minX = Math.min(...points.map(point => point.x)), maxX = Math.max(...points.map(point => point.x));
  const minZ = Math.min(...points.map(point => point.z)), maxZ = Math.max(...points.map(point => point.z));
  const extent = Math.max(maxX - minX, maxZ - minZ);
  map.forEach((point, index) => {
    assert.ok(point.x >= 0 && point.x <= 1 && point.y >= 0 && point.y <= 1, 'map lies in normalized bounds');
    close(point.x, .5 + (points[index].x - (minX + maxX) / 2) / extent, 1e-10, 'map follows road x');
    close(point.y, .5 + (points[index].z - (minZ + maxZ) / 2) / extent, 1e-10, 'map follows road z');
  });
  close(Math.hypot(map[0].x - map.at(-1).x, map[0].y - map.at(-1).y), 0, 1e-10, 'closed map');
}

function checkRoadLayout(world) {
  // Ignore nearby points along the same bend; compare remote sections of the loop.
  const count = 360;
  const points = Array.from({ length: count }, (_, index) => world.getPoint(index / count));
  let minimumRemoteDistance = Infinity;
  points.forEach((point, index) => {
    assert.ok(Number.isFinite(point.x + point.y + point.z), 'finite road geometry');
    assert.ok(point.y > world.terrainHeight + .5, 'flat terrain stays below the road');
    close(world.getTangent(index / count).length(), 1, 1e-7, 'unit driving direction');
    for (let other = index + 1; other < count; other++) {
      const alongTrack = Math.min(other - index, count - other + index) * world.length / count;
      if (alongTrack < 52) continue;
      minimumRemoteDistance = Math.min(minimumRemoteDistance, Math.hypot(point.x - points[other].x, point.z - points[other].z));
      assert.equal(intersects(point, points[(index + 1) % count], points[other], points[(other + 1) % count]), false, 'remote road sections do not cross');
    }
  });
  assert.ok(minimumRemoteDistance > 30, `remote road sections leave space for both barriers: ${minimumRemoteDistance}m`);
}

function checkVisibleBarriers(world) {
  const { center, width, height, kartRadius, segmentsPerSide } = world.barrier;
  close(world.barrierLimit, BARRIER_LIMIT);
  close(world.barrierLimit + kartRadius, center - width / 2, 1e-10, 'kart footprint meets inner barrier face');
  assert.ok(center - width / 2 > world.halfWidth, 'rail stays outside the asphalt');
  assert.ok(world.length / segmentsPerSide <= 3, 'barriers use continuous short segments');
  const segmentLength = world.length / segmentsPerSide;
  const rails = [];
  const matrix = new THREE.Matrix4(), position = new THREE.Vector3(), rotation = new THREE.Quaternion(), scale = new THREE.Vector3();
  world.root.traverse(object => {
    if (!object.isInstancedMesh || object.geometry.type !== 'BoxGeometry') return;
    for (let index = 0; index < object.count; index++) {
      object.getMatrixAt(index, matrix);
      matrix.decompose(position, rotation, scale);
      if (Math.abs(scale.x - width) < 1e-6 && Math.abs(scale.y - height) < 1e-6 && Math.abs(scale.z - (segmentLength + .18)) < 1e-5) {
        rails.push({ position: position.clone(), rotation: rotation.clone(), scale: scale.clone() });
      }
    }
  });
  assert.equal(rails.length, segmentsPerSide * 2, 'both sides have a physical barrier for every segment');
  rails.forEach((rail, index) => {
    const progress = (Math.floor(index / 2) + .5) / segmentsPerSide;
    const road = world.getPoint(progress), tangent = world.getTangent(progress).setY(0).normalize();
    const normal = new THREE.Vector3(-tangent.z, 0, tangent.x);
    const relative = rail.position.clone().sub(road);
    close(Math.abs(relative.dot(normal)), center, 2e-5, 'rail offset follows road normal');
    close(relative.dot(tangent), 0, 2e-5, 'rail has no longitudinal placement error');
    close(relative.y, .9, 2e-5, 'rail rises from road surface');
    const forward = new THREE.Vector3(0, 0, 1).applyQuaternion(rail.rotation);
    close(forward.dot(tangent), 1, 1e-6, 'barrier length follows the road tangent');

    // Check real inner rail corners against the nearby curve, including tight bends.
    // This catches a flipped normal or a rotated box intruding into the racing lane.
    if (index % 13 !== 0) return;
    const side = Math.sign(relative.dot(normal));
    for (const end of [-1, 1]) {
      const corner = rail.position.clone().addScaledVector(normal, -side * width / 2).addScaledVector(tangent, end * rail.scale.z / 2);
      let low = progress - segmentLength * 2 / world.length, high = progress + segmentLength * 2 / world.length;
      const distance = t => { const p = world.getPoint(t); return (corner.x - p.x) ** 2 + (corner.z - p.z) ** 2; };
      for (let iteration = 0; iteration < 24; iteration++) {
        const first = low + (high - low) / 3, second = high - (high - low) / 3;
        if (distance(first) < distance(second)) high = second; else low = first;
      }
      assert.ok(Math.sqrt(distance((low + high) / 2)) > world.halfWidth + .8, 'visible rail corner stays outside the asphalt');
    }
  });
}

test('the six circuits have unique track IDs', () => {
  assert.deepEqual(TRACKS.map(track => track.id), ['coast', 'canyon', 'neon', 'alpine', 'volcano', 'forest']);
  assert.equal(new Set(TRACKS.map(track => track.name)).size, 6);
});

for (const track of TRACKS) {
  test(`${track.name}: closed course, accurate map, clear terrain, matching barriers and safe disposal`, () => {
    const scene = new THREE.Scene();
    const light = new THREE.HemisphereLight();
    const unrelated = new THREE.Group();
    scene.add(light, unrelated);
    const world = createWorld(scene, track.id);
    try {
      checkMapAndClosure(world, track.id);
      checkRoadLayout(world);
      checkVisibleBarriers(world);
      world.update(1);
    } finally {
      world.dispose();
    }
    assert.deepEqual(scene.children, [light, unrelated], 'world cleanup preserves scene lights and unrelated objects');
    const rebuilt = createWorld(scene, track.id);
    assert.ok(Number.isFinite(rebuilt.getPoint(.37).y), 'the same track can rebuild after shared geometry cleanup');
    rebuilt.dispose();
    assert.deepEqual(scene.children, [light, unrelated]);
  });
}
