import assert from 'node:assert/strict';
import test from 'node:test';
import * as THREE from 'three';
import { KartGame } from '../src/game.js';
import { createWorld } from '../src/world.js';
import { DEFAULT_KEYBINDS, ACTION_LABELS, normalizeKeybinds, keyLabel, isAllowedKeyCode, rebindKey } from '../src/controls.js';

const CUSTOM = {
  accelerate: ['KeyI', 'KeyT'], brake: ['KeyK'], left: ['KeyJ'], right: ['KeyL'],
  drift: ['ShiftLeft'], item: ['KeyU'], recover: ['KeyO'], pause: ['KeyP'],
};
const event = (code, overrides = {}) => ({
  code, repeat: false, target: { tagName: 'CANVAS' },
  preventDefault() { this.defaultPrevented = true; }, ...overrides,
});

function fixture(world, bindings = CUSTOM) {
  const game = Object.create(KartGame.prototype);
  Object.assign(game, {
    world, mode: 'race', options: { mode: 'solo' }, callbacks: {},
    dynamic: new THREE.Group(), racers: [], pickups: [], hazards: [], coins: [], effects: [], boostPads: [],
    keys: new Set(), dev: { speedMultiplier: 1 }, clock: 1, raceElapsed: 0,
    countdownRemaining: 0, activateAudio() {},
  });
  const racer = {
    id: 'test', name: 'Test', local: true, ai: false,
    character: { speed: 4, handling: 4 }, mesh: new THREE.Group(),
    distance: .04, lateral: 0, heading: 0, steering: 0, speed: 28,
    drift: 0, item: null, finished: false,
  };
  game.player = racer; game.racers = [racer]; game.dynamic.add(racer.mesh);
  game.setKeybinds(bindings);
  return { game, racer, dispose: () => game.clearDynamic() };
}

function move(world, codes, speed = 28) {
  const f = fixture(world);
  try {
    f.racer.speed = speed;
    codes.forEach(code => f.game.handleKeyDown(event(code)));
    for (let frame = 0; frame < 6; frame++) {
      f.game.clock += .02; f.game.raceElapsed += .02; f.game.tickRacer(f.racer, .02);
    }
    return { speed: f.racer.speed, progress: f.racer.distance, lateral: f.racer.lateral, drift: f.racer.drift };
  } finally { f.dispose(); }
}

test('defaults retain every established key and labels, while reserved browser keys are rejected', () => {
  assert.deepEqual(normalizeKeybinds(null), DEFAULT_KEYBINDS);
  assert.deepEqual(DEFAULT_KEYBINDS.accelerate, ['KeyW', 'ArrowUp']);
  assert.deepEqual(DEFAULT_KEYBINDS.left, ['KeyA', 'ArrowLeft']);
  assert.equal(Object.keys(ACTION_LABELS).length, 8);
  for (const code of ['KeyI', 'Digit7', 'ArrowLeft', 'Space', 'Escape', 'ShiftLeft', 'ShiftRight', 'Enter', 'Delete', 'Backspace', 'Slash']) assert.equal(isAllowedKeyCode(code), true, code);
  for (const code of ['Tab', 'F5', 'F8', 'F11', 'ControlLeft', 'MetaRight', 'AltLeft', 'Keyaa', '', null]) assert.equal(isAllowedKeyCode(code), false, String(code));
  assert.equal(keyLabel('KeyI'), 'I'); assert.equal(keyLabel('Digit7'), '7');
  assert.equal(keyLabel('ArrowUp'), '↑'); assert.equal(keyLabel('Escape'), 'Esc'); assert.equal(keyLabel(null), 'Unbound');
});

test('normalization recovers malformed stored bindings without duplicate action claims or mutation', () => {
  const original = { accelerate: ['KeyI', 'KeyI', 'F8'], brake: ['KeyI', 'KeyK'], left: ['F5'] };
  const copy = structuredClone(original);
  const normalized = normalizeKeybinds(original);
  assert.deepEqual(original, copy);
  assert.deepEqual(normalized.accelerate, ['KeyI']); assert.deepEqual(normalized.brake, ['KeyK']);
  assert.deepEqual(normalized.left, ['KeyA', 'ArrowLeft']);
  const all = Object.values(normalized).flat(); assert.equal(new Set(all).size, all.length);
  for (const codes of Object.values(normalized)) assert.ok(codes.length >= 1 && codes.length <= 2 && codes.every(isAllowedKeyCode));
  assert.deepEqual(normalizeKeybinds(CUSTOM), CUSTOM, 'valid custom controls must survive persisted reload');
});

test('rebinding reports conflicts and reserved keys, supports two slots, and retains a final key', () => {
  const edited = rebindKey(DEFAULT_KEYBINDS, 'accelerate', 0, 'KeyI');
  assert.equal(edited.error, null); assert.deepEqual(edited.bindings.accelerate, ['KeyI', 'ArrowUp']);
  assert.deepEqual(DEFAULT_KEYBINDS.accelerate, ['KeyW', 'ArrowUp'], 'immutable defaults must not change');
  const duplicate = rebindKey(edited.bindings, 'brake', 0, 'KeyI');
  assert.ok(duplicate.error.includes('Accelerate')); assert.deepEqual(duplicate.bindings, edited.bindings);
  assert.ok(rebindKey(edited.bindings, 'accelerate', 1, 'KeyI').error);
  for (const code of ['Tab', 'F8', 'ControlLeft']) assert.ok(rebindKey(edited.bindings, 'item', 0, code).error);
  const cleared = rebindKey(edited.bindings, 'accelerate', 1, null);
  assert.equal(cleared.error, null); assert.deepEqual(cleared.bindings.accelerate, ['KeyI']);
  assert.ok(rebindKey(cleared.bindings, 'accelerate', 0, null).error);
  assert.equal(rebindKey(CUSTOM, 'pause', 0, 'Escape').error, null, 'Escape may be bound instead of canceling capture');
});

test('actual physics responds to remapped throttle, brake, steering and drift, while old keys are inactive', () => {
  const world = createWorld(new THREE.Scene(), 'coast');
  try {
    const coast = move(world, []);
    assert.ok(move(world, ['KeyI']).speed > coast.speed); assert.ok(move(world, ['KeyT']).progress > coast.progress);
    assert.ok(move(world, ['KeyK']).speed < coast.speed);
    const straight = move(world, ['KeyI']);
    assert.ok(move(world, ['KeyI', 'KeyJ']).lateral > straight.lateral, 'custom left input keeps corrected direction');
    assert.ok(move(world, ['KeyI', 'KeyL']).lateral < straight.lateral, 'custom right input keeps corrected direction');
    assert.ok(move(world, ['KeyI', 'KeyJ', 'ShiftLeft']).drift > 0);
    assert.equal(move(world, ['KeyI', 'KeyJ', 'Space']).drift, 0, 'old drift key is unbound');
    for (const oldKey of ['KeyW', 'ArrowUp', 'KeyS', 'ArrowDown', 'KeyA', 'ArrowLeft', 'KeyD', 'ArrowRight']) assert.deepEqual(move(world, [oldKey]), coast, `${oldKey} must not retain its old action`);
    assert.deepEqual(move(world, ['KeyI', 'KeyJ', 'KeyL']), straight, 'opposing remapped steering cancels');
  } finally { world.dispose(); }
});

test('remapped item, recover, and pause use the real keyboard handlers, including repeat suppression', () => {
  const world = createWorld(new THREE.Scene(), 'coast');
  const f = fixture(world);
  try {
    let pauses = 0; f.game.callbacks.onPause = () => { pauses++; };
    f.racer.item = 'nitro'; f.game.handleKeyDown(event('KeyE')); assert.equal(f.racer.item, 'nitro');
    f.game.handleKeyDown(event('KeyU')); assert.equal(f.racer.item, null); assert.ok(f.racer.nitro > 0);
    f.racer.lateral = 5; f.racer.heading = .3;
    f.game.handleKeyDown(event('KeyR')); assert.equal(f.racer.lateral, 5);
    f.game.handleKeyDown(event('KeyO')); assert.equal(f.racer.lateral, 0); assert.equal(f.racer.heading, 0);
    f.game.handleKeyDown(event('Escape')); assert.equal(pauses, 0);
    f.game.handleKeyDown(event('KeyP')); assert.equal(pauses, 1);
    f.game.handleKeyDown(event('KeyP', { repeat: true }));
    f.game.handleKeyDown(event('KeyP')); assert.equal(pauses, 1, 'held action triggers once');
    f.game.handleKeyUp(event('KeyP')); f.game.handleKeyDown(event('KeyP')); assert.equal(pauses, 2);
  } finally { f.dispose(); world.dispose(); }
});

test('custom launch key grants launch boost and rebinding clears held state', () => {
  const world = createWorld(new THREE.Scene(), 'coast');
  const f = fixture(world);
  try {
    f.racer.speed = 0; f.game.startAt = Date.now() + 500; f.game.countdownRemaining = 1;
    f.game.handleKeyDown(event('KeyI')); assert.ok(f.game.lastThrottleDown > 0);
    f.game.updateCountdown(f.game.startAt + 1); assert.ok(f.racer.boost > 0); assert.equal(f.racer.speed, 13);
    assert.equal(f.game.actionDown('accelerate'), true);
    f.game.setKeybinds(DEFAULT_KEYBINDS); assert.equal(f.game.actionDown('accelerate'), false); assert.equal(f.game.lastThrottleDown, 0);
    delete f.game.keybinds; f.game.keys.add('ArrowLeft'); assert.equal(f.game.actionDown('left'), true, 'legacy prototype harness uses defaults');
  } finally { f.dispose(); world.dispose(); }
});

test('binding capture, typing, and OS modifier chords cannot leak into racing input', () => {
  const world = createWorld(new THREE.Scene(), 'coast');
  const f = fixture(world);
  try {
    for (const extra of [{ defaultPrevented: true }, { target: { tagName: 'INPUT' } }, { target: { isContentEditable: true } }, { ctrlKey: true }, { metaKey: true }, { altKey: true }]) {
      f.game.handleKeyDown(event('KeyI', extra)); assert.equal(f.game.actionDown('accelerate'), false);
    }
    f.game.handleKeyDown(event('KeyI')); assert.equal(f.game.actionDown('accelerate'), true);
    f.game.handleKeyUp(event('KeyI', { target: { tagName: 'INPUT' } })); assert.equal(f.game.actionDown('accelerate'), false);
  } finally { f.dispose(); world.dispose(); }
});
