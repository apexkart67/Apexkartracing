# APEX KART — World Tour v2

An original PC browser kart racer built with Three.js, Vite, and PeerJS. All worlds, karts, track illustrations, and character art are generated in code. Inspired by the arcade kart racing genre; no KartBros assets or source code are used.

## What's new in World Tour

- Six detailed circuits: Sunshore Circuit, Redrock Rally, Neon Nights, Frostpeak Pass, Ember Caldera, and Wildwood Run. Their terrain, tunnels, landmarks, lighting, and scenery differ. Menu maps show the actual track layouts.
- Eight detailed, articulated kart/driver models with character-specific helmets, rolling wheels, steering, body movement, exhaust, lights, and soft shadows.
- Continuous physical road barriers. A kart is stopped at the matching guardrail, loses speed on an impact, and gets spark/audio/camera feedback. Collision also works while boosted, drifting, or invincible. Rotated vehicle clearance is included.
- Smoother handling, charged drift turbos, a timed launch boost, boost pads, inside-line AI with overtaking, gold coin pickups, lap splits, and best laps.
- Six power-ups: Turbo, Rocket, Shield, Banana, EMP pulse, and Nitro.
- Two three-round Grand Prix cups with accumulated points, trophies, and a winner bonus.
- Permanent paint purchases using race coins, two additional progression racers, graphics presets, and three camera distances.
- Expanded developer practice tools and protocol-v2 friend rooms.

## Controls

- **WASD / arrow keys:** accelerate, brake, and steer.
- **Space + steering:** hold a drift at speed, then release for a charged turbo.
- **E:** use a collected power-up.
- **R:** recover to the center of the track.
- **Escape:** pause solo races. Online races continue while the menu is open.

Press the accelerator during the final 0.65 seconds before GO for a launch turbo. Finish three-lap quick races to earn XP and unlock Jax (2 finishes), Rio (5), Pixel (10), Phantom (20), Ember (30), and Aurora (40). Nova and Milo start unlocked. Time trials run alone and record best times. Collect gold coins on the track to buy permanent paint colors in the garage. Profiles and preferences are stored in the same browser, retaining v1 progression.

## Grand Prix

The Horizon Cup races coast → canyon → forest. The Afterglow Cup races city → alpine → volcano. Each has three rounds and eight racers. Points by place: 15, 12, 10, 8, 6, 4, 2, 1. The highest total wins; ties favor the local player. A cup victory earns a saved trophy and 300 bonus XP. Individual unassisted rounds still earn normal progression. Leaving a cup abandons its in-memory standings. Developer assistance on any round prevents that cup from awarding a trophy.

## Online rooms

Select **Play with friends**, create a room, and share its six-character code and the site URL. Up to eight racers can connect; the host chooses any of the six tracks. The host must keep their tab open until everyone finishes. Create a new room for the next race. Everyone must use World Tour v2: it deliberately uses a different protocol namespace from v1. Paint colors are included in the lobby roster. See [NETWORK.md](NETWORK.md) for connection details.

## Run locally

Requires Node.js 22 or newer.

```sh
npm ci
npm run dev
```

For verification and a static production build:

```sh
npm test
npm run check
npm run build
```

The output is `dist/`. Asset URLs are relative, so GitHub repository subpaths work.

## Publish on GitHub Pages

Upload the source project (including `.github/workflows/deploy.yml`, `package.json`, and `package-lock.json`) to a public repository, with `package.json` directly at its root. In **Settings → Pages → Source**, choose **GitHub Actions**. Push to `main`, or use **Actions → Deploy to GitHub Pages → Run workflow**. The included source workflow installs dependencies, runs regression tests, builds, and publishes `dist/`.

### Update an existing ZIP-based deployment from iPhone

Replace your repository's existing **`apex-kart-source.zip`** with the latest downloaded ZIP, keeping that exact filename. Keep it zipped and commit it to `main`. Keep the repository's current **Deploy game** workflow: it unpacks the ZIP and publishes the new build. Keep **Settings → Pages → Source** set to **GitHub Actions**. Do not upload another outer directory or rename the ZIP to include `(1)`.

## Developer pit lane

Set the player name to **APEXDEV** and save. The developer menu opens, and a **DEV MENU** button appears beside the name. Reopen it with that button, the Settings or solo pause menu, **F8**, or **Ctrl + Shift + D**. Press Escape or Close to resume.

Practice tools include infinite boost, item invincibility, speed multipliers, slow/fast simulation, frozen AI, reusable power-ups, a choice of all six items, recovery, checkpoint jumps, skipping the countdown, and finishing a practice race. The garage section can preview every racer while using the developer name and unlock all paint colors. A circuit loader returns to the grid; telemetry shows the current kart state. Reset Tools restores normal gameplay settings without erasing progress.

All gameplay commands mark the current race assisted. Assisted races award no XP, coins, racer progression, best times, or cup trophies; disabling a tool later does not remove that flag. Physical barriers remain on. Commands are blocked online. Developer-name access is a local Easter egg, not an authentication or anti-cheat boundary.

## Verification and limits

Node regression tests use real Three.js geometry, physics methods, and camera matrices to check steering direction across six tracks, accelerating/braking, barrier boundaries and rotated-kart clearance, collision at boosted/debug speeds, developer restrictions, pickups, lap/result logic, model articulation/footprints/disposal, world terrain/layout/barriers, and the room protocol using simulated peers. Menu and progression integration is checked with a separate DOM harness during development.

Browser rendering, control feel, and live cross-network WebRTC still need desktop playtesting because this environment has no callable browser-control tool. This game has no public matchmaking, account server, cloud save, host migration, authoritative server, anti-cheat, or global leaderboard. Free public signaling/STUN services have no availability guarantee; some networks need a separately operated TURN relay. A keyboard and WebGL-capable desktop browser are required; touch racing controls are not included. The separate Sites deployment uses `.openai/hosting.json`, which GitHub Pages ignores.
